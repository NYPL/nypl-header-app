import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/Header/components/HeaderSitewideAlerts.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSitewideAlerts.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Box, chakra, useStyleConfig } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@chakra-ui_react.js?v=2c813617";
import { List, Notification } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@nypl_design-system-react-components.js?v=f372bde6";
import __vite__cjsImport5_react from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/react.js?v=f7bb76b7"; const useState = __vite__cjsImport5_react["useState"]; const useEffect = __vite__cjsImport5_react["useEffect"];
import { alertsApiUrl, parseAlertsData } from "/components/Header/utils/headerUtils.ts";
export const HeaderSitewideAlerts = _s(chakra(_c = _s(() => {
  _s();
  const [alerts, setAlerts] = useState([]);
  const styles = useStyleConfig("HeaderSitewideAlerts");
  const fetchErrorMessage = "NYPL Reservoir HeaderSitewideAlerts: There was an error fetching NYPL sitewide alerts.";
  useEffect(() => {
    fetch(alertsApiUrl).then((response) => {
      if (response.status >= 200 && response.status < 300) {
        return response.json();
      } else {
        throw new Error(fetchErrorMessage);
      }
    }).then((data) => {
      const parsedData = parseAlertsData(data);
      setAlerts(parsedData);
    }).catch((_error) => {
      console.warn(fetchErrorMessage);
    });
  }, []);
  const getAlertsElems = (data) => {
    return /* @__PURE__ */ jsxDEV(List, { noStyling: true, type: "ul", children: data.map((alert) => /* @__PURE__ */ jsxDEV(Box, { as: "li", dangerouslySetInnerHTML: {
      __html: alert.description
    }, marginBottom: "0 !important" }, alert.id, false, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSitewideAlerts.tsx",
      lineNumber: 41,
      columnNumber: 37
    }, this)) }, void 0, false, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSitewideAlerts.tsx",
      lineNumber: 40,
      columnNumber: 12
    }, this);
  };
  return alerts.length > 0 ? /* @__PURE__ */ jsxDEV(Notification, { "aria-label": "Sitewide alerts", id: "sitewideAlerts-notification", isCentered: true, noMargin: true, notificationContent: getAlertsElems(alerts), showIcon: false, __css: styles }, void 0, false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSitewideAlerts.tsx",
    lineNumber: 46,
    columnNumber: 30
  }, this) : null;
}, "s8Hwk0p4KI9D0ffp7sqgxNPymhg=", false, function() {
  return [useStyleConfig];
})), "s8Hwk0p4KI9D0ffp7sqgxNPymhg=", false, function() {
  return [useStyleConfig];
});
_c2 = HeaderSitewideAlerts;
export default HeaderSitewideAlerts;
var _c, _c2;
$RefreshReg$(_c, "HeaderSitewideAlerts$chakra");
$RefreshReg$(_c2, "HeaderSitewideAlerts");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSitewideAlerts.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkNVOzs7Ozs7Ozs7Ozs7Ozs7O0FBN0NWLFNBQVNBLEtBQUtDLFFBQVFDLHNCQUFzQjtBQUM1QyxTQUFTQyxNQUFNQyxvQkFBb0I7QUFDbkMsU0FBZ0JDLFVBQVVDLGlCQUFpQjtBQUUzQyxTQUFnQkMsY0FBY0MsdUJBQXVCO0FBTzlDLGFBQU1DLHVCQUFvQkMsR0FBR1QsT0FBTVUsS0FBQUQsR0FBQyxNQUFNO0FBQUFBLEtBQUE7QUFDL0MsUUFBTSxDQUFDRSxRQUFRQyxTQUFTLElBQUlSLFNBQWtCLEVBQUU7QUFDaEQsUUFBTVMsU0FBU1osZUFBZSxzQkFBc0I7QUFDcEQsUUFBTWEsb0JBQ0o7QUFJRlQsWUFBVSxNQUFNO0FBQ2RVLFVBQU1ULFlBQVksRUFDZlUsS0FBTUMsY0FBYTtBQUNsQixVQUFJQSxTQUFTQyxVQUFVLE9BQU9ELFNBQVNDLFNBQVMsS0FBSztBQUNuRCxlQUFPRCxTQUFTRSxLQUFLO0FBQUEsTUFDdkIsT0FBTztBQUNMLGNBQU0sSUFBSUMsTUFBTU4saUJBQWlCO0FBQUEsTUFDbkM7QUFBQSxJQUNGLENBQUMsRUFDQUUsS0FBTUssVUFBUztBQUNkLFlBQU1DLGFBQXNCZixnQkFBZ0JjLElBQUk7QUFDaERULGdCQUFVVSxVQUFVO0FBQUEsSUFDdEIsQ0FBQyxFQUNBQyxNQUFPQyxZQUFXO0FBRWpCQyxjQUFRQyxLQUFLWixpQkFBaUI7QUFBQSxJQUNoQyxDQUFDO0FBQUEsRUFDTCxHQUFHLEVBQUU7QUFLTCxRQUFNYSxpQkFBaUJBLENBQUNOLFNBQWtCO0FBQ3hDLFdBQ0UsdUJBQUMsUUFBSyxXQUFTLE1BQUMsTUFBSyxNQUNsQkEsZUFBS08sSUFBSSxDQUFDQyxVQUNULHVCQUFDLE9BQ0MsSUFBRyxNQUVILHlCQUF5QjtBQUFBLE1BQUVDLFFBQVFELE1BQU1FO0FBQUFBLElBQVksR0FDckQsY0FBYSxrQkFGUkYsTUFBTUcsSUFGYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSTZCLENBRTlCLEtBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsRUFFSjtBQUVBLFNBQU9yQixPQUFPc0IsU0FBUyxJQUNyQix1QkFBQyxnQkFDQyxjQUFXLG1CQUNYLElBQUcsK0JBQ0gsWUFBVSxNQUNWLFVBQVEsTUFDUixxQkFBcUJOLGVBQWVoQixNQUFNLEdBQzFDLFVBQVUsT0FDVixPQUFPRSxVQVBUO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FPZ0IsSUFFZDtBQUNOLEdBQUM7QUFBQSxVQXREZ0JaLGNBQWM7QUFBQSxFQXNEOUIsR0FBQztBQUFBLFVBdERlQSxjQUFjO0FBQUE7QUFzRDVCaUMsTUF4RFUxQjtBQTBEYixlQUFlQTtBQUFxQixJQUFBRSxJQUFBd0I7QUFBQUMsYUFBQXpCLElBQUE7QUFBQXlCLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJCb3giLCJjaGFrcmEiLCJ1c2VTdHlsZUNvbmZpZyIsIkxpc3QiLCJOb3RpZmljYXRpb24iLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsImFsZXJ0c0FwaVVybCIsInBhcnNlQWxlcnRzRGF0YSIsIkhlYWRlclNpdGV3aWRlQWxlcnRzIiwiX3MiLCJfYyIsImFsZXJ0cyIsInNldEFsZXJ0cyIsInN0eWxlcyIsImZldGNoRXJyb3JNZXNzYWdlIiwiZmV0Y2giLCJ0aGVuIiwicmVzcG9uc2UiLCJzdGF0dXMiLCJqc29uIiwiRXJyb3IiLCJkYXRhIiwicGFyc2VkRGF0YSIsImNhdGNoIiwiX2Vycm9yIiwiY29uc29sZSIsIndhcm4iLCJnZXRBbGVydHNFbGVtcyIsIm1hcCIsImFsZXJ0IiwiX19odG1sIiwiZGVzY3JpcHRpb24iLCJpZCIsImxlbmd0aCIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkhlYWRlclNpdGV3aWRlQWxlcnRzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCb3gsIGNoYWtyYSwgdXNlU3R5bGVDb25maWcgfSBmcm9tIFwiQGNoYWtyYS11aS9yZWFjdFwiO1xuaW1wb3J0IHsgTGlzdCwgTm90aWZpY2F0aW9uIH0gZnJvbSBcIkBueXBsL2Rlc2lnbi1zeXN0ZW0tcmVhY3QtY29tcG9uZW50c1wiO1xuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcblxuaW1wb3J0IHsgQWxlcnQsIGFsZXJ0c0FwaVVybCwgcGFyc2VBbGVydHNEYXRhIH0gZnJvbSBcIi4uL3V0aWxzL2hlYWRlclV0aWxzXCI7XG5cbi8qKlxuICogVGhlIEhlYWRlclNpdGV3aWRlQWxlcnRzIGNvbXBvbmVudCBtYWtlcyBhbiBBUEkgcmVxdWVzdCB0byBhbiBOWVBMIEFQSVxuICogZW5kcG9pbnQgdG8gZmV0Y2ggTllQTCBzaXRld2lkZSBhbGVydHMuIFdoaWxlIHRoaXMgY29tcG9uZW50IGNhbiBiZSB1c2VkIGluXG4gKiBpc29sYXRpb24sIGl0IGlzIGFscmVhZHkgcmVuZGVyZWQgaW4gdGhlIERTIEhlYWRlciBjb21wb25lbnQuXG4gKi9cbmV4cG9ydCBjb25zdCBIZWFkZXJTaXRld2lkZUFsZXJ0cyA9IGNoYWtyYSgoKSA9PiB7XG4gIGNvbnN0IFthbGVydHMsIHNldEFsZXJ0c10gPSB1c2VTdGF0ZTxBbGVydFtdPihbXSk7XG4gIGNvbnN0IHN0eWxlcyA9IHVzZVN0eWxlQ29uZmlnKFwiSGVhZGVyU2l0ZXdpZGVBbGVydHNcIik7XG4gIGNvbnN0IGZldGNoRXJyb3JNZXNzYWdlID1cbiAgICBcIk5ZUEwgUmVzZXJ2b2lyIEhlYWRlclNpdGV3aWRlQWxlcnRzOiBUaGVyZSB3YXMgYW4gZXJyb3IgZmV0Y2hpbmcgTllQTCBzaXRld2lkZSBhbGVydHMuXCI7XG5cbiAgLy8gTWFrZSBhIHJlcXVlc3QgdG8gdGhlIE5ZUEwgQVBJIGVuZHBvaW50IGZvciBzaXRld2lkZSBhbGVydHMsIHBhcnNlXG4gIC8vIHRoZSBkYXRhLCBhbmQgc2V0IGl0IHRvIHRoZSBsb2NhbCBzdGF0ZS5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBmZXRjaChhbGVydHNBcGlVcmwpXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA+PSAyMDAgJiYgcmVzcG9uc2Uuc3RhdHVzIDwgMzAwKSB7XG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoZmV0Y2hFcnJvck1lc3NhZ2UpO1xuICAgICAgICB9XG4gICAgICB9KVxuICAgICAgLnRoZW4oKGRhdGEpID0+IHtcbiAgICAgICAgY29uc3QgcGFyc2VkRGF0YTogQWxlcnRbXSA9IHBhcnNlQWxlcnRzRGF0YShkYXRhKTtcbiAgICAgICAgc2V0QWxlcnRzKHBhcnNlZERhdGEpO1xuICAgICAgfSlcbiAgICAgIC5jYXRjaCgoX2Vycm9yKSA9PiB7XG4gICAgICAgIC8vIE92ZXJyaWRlIGFueSBlcnJvciBtZXNzYWdlIHdpdGggb3VyIG93bi5cbiAgICAgICAgY29uc29sZS53YXJuKGZldGNoRXJyb3JNZXNzYWdlKTtcbiAgICAgIH0pO1xuICB9LCBbXSk7XG5cbiAgLy8gR3JlYXQsIHdlIGhhdmUgTllQTCBhbGVydHMgZGF0YS4gRWFjaCBhbGVydCBpcyByZW5kZXJlZCBhcyBhIGxpc3RcbiAgLy8gaXRlbSBpbiBhbiB1bm9yZGVyZWQgbGlzdC4gTm90ZSB0aGF0IHRoZSBhbGVydCBkZXNjcmlwdGlvbiBtYXlcbiAgLy8gY29udGFpbiBIVE1MIHdoaWNoIGlzIHJlbmRlcmVkIGFzLWlzLlxuICBjb25zdCBnZXRBbGVydHNFbGVtcyA9IChkYXRhOiBBbGVydFtdKSA9PiB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxMaXN0IG5vU3R5bGluZyB0eXBlPVwidWxcIj5cbiAgICAgICAge2RhdGEubWFwKChhbGVydDogQWxlcnQpID0+IChcbiAgICAgICAgICA8Qm94XG4gICAgICAgICAgICBhcz1cImxpXCJcbiAgICAgICAgICAgIGtleT17YWxlcnQuaWR9XG4gICAgICAgICAgICBkYW5nZXJvdXNseVNldElubmVySFRNTD17eyBfX2h0bWw6IGFsZXJ0LmRlc2NyaXB0aW9uIH19XG4gICAgICAgICAgICBtYXJnaW5Cb3R0b209XCIwICFpbXBvcnRhbnRcIlxuICAgICAgICAgIC8+XG4gICAgICAgICkpfVxuICAgICAgPC9MaXN0PlxuICAgICk7XG4gIH07XG5cbiAgcmV0dXJuIGFsZXJ0cy5sZW5ndGggPiAwID8gKFxuICAgIDxOb3RpZmljYXRpb25cbiAgICAgIGFyaWEtbGFiZWw9XCJTaXRld2lkZSBhbGVydHNcIlxuICAgICAgaWQ9XCJzaXRld2lkZUFsZXJ0cy1ub3RpZmljYXRpb25cIlxuICAgICAgaXNDZW50ZXJlZFxuICAgICAgbm9NYXJnaW5cbiAgICAgIG5vdGlmaWNhdGlvbkNvbnRlbnQ9e2dldEFsZXJ0c0VsZW1zKGFsZXJ0cyl9XG4gICAgICBzaG93SWNvbj17ZmFsc2V9XG4gICAgICBfX2Nzcz17c3R5bGVzfVxuICAgIC8+XG4gICkgOiBudWxsO1xufSk7XG5cbmV4cG9ydCBkZWZhdWx0IEhlYWRlclNpdGV3aWRlQWxlcnRzO1xuIl0sImZpbGUiOiIvVXNlcnMvY2hyaXNtdWxob2xsYW5kL1NpdGVzL3Rlc3RzL255cGwtaGVhZGVyLWFwcC9zcmMvY29tcG9uZW50cy9IZWFkZXIvY29tcG9uZW50cy9IZWFkZXJTaXRld2lkZUFsZXJ0cy50c3gifQ==