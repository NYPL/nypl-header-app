import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/Header/components/HeaderSearchForm.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchForm.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Box, chakra, useMultiStyleConfig } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@chakra-ui_react.js?v=2c813617";
import __vite__cjsImport4_react from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/react.js?v=f7bb76b7"; const useState = __vite__cjsImport4_react["useState"];
import { getCatalogURL, getNYPLSearchURL, getResearchCatalogURL } from "/components/Header/utils/headerUtils.ts";
import { Form, FormRow, FormField, Fieldset, TextInput, ButtonGroup, Button, Icon, RadioGroup, Radio } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@nypl_design-system-react-components.js?v=f372bde6";
const HeaderSearchForm = _s(chakra(_c = _s(({
  isMobile = false
}) => {
  _s();
  const defaultSearchRadioValue = "circulatingCatalog";
  const [placeholder, setPlaceholder] = useState("What would you like to find?");
  const [searchInput, setSearchInput] = useState("");
  const [searchOption, setSearchOption] = useState(defaultSearchRadioValue);
  const styles = useMultiStyleConfig("HeaderSearchForm", {
    isMobile
  });
  const onSubmit = (e) => {
    e.preventDefault();
    let requestUrl;
    if (searchInput) {
      if (searchOption === "circulatingCatalog") {
        requestUrl = getCatalogURL(searchInput);
      }
      if (searchOption === "researchCatalog") {
        requestUrl = getResearchCatalogURL(searchInput);
      }
      if (searchOption === "website") {
        requestUrl = getNYPLSearchURL(searchInput);
      }
      window.location.assign(requestUrl);
      return true;
    }
    setPlaceholder("Please enter a search term.");
    return false;
  };
  return /* @__PURE__ */ jsxDEV(Box, { __css: styles, children: /* @__PURE__ */ jsxDEV(Form, { id: "search-header", gap: "grid.m", onSubmit, __css: styles.form, children: [
    /* @__PURE__ */ jsxDEV(FormRow, { children: [
      /* @__PURE__ */ jsxDEV(FormField, { gridColumn: "1 / 3", children: /* @__PURE__ */ jsxDEV(Fieldset, { id: "fieldset-search", isLegendHidden: true, legendText: "Enter a keyword, then choose to search either the catalog or the website", children: /* @__PURE__ */ jsxDEV(TextInput, { id: "searchInput", isRequired: true, labelText: "Enter Search Keyword", onChange: (e) => setSearchInput(e.target.value), placeholder, showRequiredLabel: false, value: searchInput, __css: {
        ...styles.textInput,
        label: {
          ...styles.textInput?.label,
          marginBottom: {
            base: "s"
          }
        },
        input: {
          ...styles.textInput?.input,
          _placeholder: {
            fontSize: {
              base: "18px",
              mh: "20px"
            },
            fontStyle: "normal"
          }
        }
      } }, void 0, false, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchForm.tsx",
        lineNumber: 53,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchForm.tsx",
        lineNumber: 52,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchForm.tsx",
        lineNumber: 51,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(FormField, { gridColumn: {
        base: "3",
        mh: "4"
      }, children: /* @__PURE__ */ jsxDEV(ButtonGroup, { children: /* @__PURE__ */ jsxDEV(Button, { "aria-label": "Search", buttonType: "pill", id: "search-btn", onClick: onSubmit, __css: {
        ...styles.searchBtn,
        padding: "1px 6px !important"
      }, children: /* @__PURE__ */ jsxDEV(Icon, { name: "search", size: "large" }, void 0, false, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchForm.tsx",
        lineNumber: 83,
        columnNumber: 19
      }, this) }, void 0, false, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchForm.tsx",
        lineNumber: 79,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchForm.tsx",
        lineNumber: 78,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchForm.tsx",
        lineNumber: 74,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchForm.tsx",
      lineNumber: 50,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(FormRow, { children: /* @__PURE__ */ jsxDEV(FormField, { children: /* @__PURE__ */ jsxDEV(RadioGroup, { defaultValue: "circulatingCatalog", id: "search-type", labelText: "Type of search", layout: isMobile ? "column" : "row", name: "catalogWebsiteSearch", onChange: (val) => setSearchOption(val), showLabel: false, __css: {
      label: {
        marginBottom: "0"
      }
    }, children: [
      /* @__PURE__ */ jsxDEV(Radio, { id: "circulatingCatalogSearch", labelText: "Search books, music, and movies", value: "circulatingCatalog", __css: styles.radio }, void 0, false, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchForm.tsx",
        lineNumber: 95,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(Radio, { id: "researchcatalogSearch", labelText: "Search the Research Catalog", value: "researchCatalog", __css: styles.radio }, void 0, false, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchForm.tsx",
        lineNumber: 96,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(Radio, { id: "websiteSearch", labelText: "Search the library website", value: "website", __css: styles.radio }, void 0, false, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchForm.tsx",
        lineNumber: 97,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchForm.tsx",
      lineNumber: 90,
      columnNumber: 15
    }, this) }, void 0, false, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchForm.tsx",
      lineNumber: 89,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchForm.tsx",
      lineNumber: 88,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchForm.tsx",
    lineNumber: 49,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchForm.tsx",
    lineNumber: 48,
    columnNumber: 10
  }, this);
}, "b5jYRnm6wFB6FZzwTANLuAt+lVg=", false, function() {
  return [useMultiStyleConfig];
})), "b5jYRnm6wFB6FZzwTANLuAt+lVg=", false, function() {
  return [useMultiStyleConfig];
});
_c2 = HeaderSearchForm;
export default HeaderSearchForm;
var _c, _c2;
$RefreshReg$(_c, "HeaderSearchForm$chakra");
$RefreshReg$(_c2, "HeaderSearchForm");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUZnQjs7Ozs7Ozs7Ozs7Ozs7OztBQXJGaEIsU0FBU0EsS0FBS0MsUUFBUUMsMkJBQTJCO0FBQ2pELFNBQVNDLGdCQUFnQjtBQUV6QixTQUNFQyxlQUNBQyxrQkFDQUMsNkJBQ0s7QUFDUCxTQUNFQyxNQUNBQyxTQUNBQyxXQUNBQyxVQUNBQyxXQUNBQyxhQUNBQyxRQUNBQyxNQUNBQyxZQUNBQyxhQUNLO0FBZVAsTUFBTUMsbUJBQWdCQyxHQUFHakIsT0FBTWtCLEtBQUFELEdBQzdCLENBQUM7QUFBQSxFQUFFRSxXQUFXO0FBQTZCLE1BQU07QUFBQUYsS0FBQTtBQUMvQyxRQUFNRywwQkFBNEM7QUFDbEQsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUlwQixTQUNwQyw4QkFDRjtBQUNBLFFBQU0sQ0FBQ3FCLGFBQWFDLGNBQWMsSUFBSXRCLFNBQWlCLEVBQUU7QUFDekQsUUFBTSxDQUFDdUIsY0FBY0MsZUFBZSxJQUFJeEIsU0FDdENrQix1QkFDRjtBQUNBLFFBQU1PLFNBQVMxQixvQkFBb0Isb0JBQW9CO0FBQUEsSUFBRWtCO0FBQUFBLEVBQVMsQ0FBQztBQUVuRSxRQUFNUyxXQUFXQSxDQUFDQyxNQUFXO0FBQzNCQSxNQUFFQyxlQUFlO0FBQ2pCLFFBQUlDO0FBR0osUUFBSVIsYUFBYTtBQUNmLFVBQUlFLGlCQUFpQixzQkFBc0I7QUFDekNNLHFCQUFhNUIsY0FBY29CLFdBQVc7QUFBQSxNQUN4QztBQUNBLFVBQUlFLGlCQUFpQixtQkFBbUI7QUFDdENNLHFCQUFhMUIsc0JBQXNCa0IsV0FBVztBQUFBLE1BQ2hEO0FBQ0EsVUFBSUUsaUJBQWlCLFdBQVc7QUFDOUJNLHFCQUFhM0IsaUJBQWlCbUIsV0FBVztBQUFBLE1BQzNDO0FBRUFTLGFBQU9DLFNBQVNDLE9BQU9ILFVBQVU7QUFDakMsYUFBTztBQUFBLElBQ1Q7QUFFQVQsbUJBQWUsNkJBQTZCO0FBQzVDLFdBQU87QUFBQSxFQUNUO0FBRUEsU0FDRSx1QkFBQyxPQUFJLE9BQU9LLFFBQ1YsaUNBQUMsUUFDQyxJQUFHLGlCQUNILEtBQUksVUFDSixVQUNBLE9BQU9BLE9BQU9RLE1BRWQ7QUFBQSwyQkFBQyxXQUNDO0FBQUEsNkJBQUMsYUFBVSxZQUFXLFNBQ3BCLGlDQUFDLFlBQ0MsSUFBRyxtQkFDSCxnQkFBYyxNQUNkLFlBQVcsNEVBRVgsaUNBQUMsYUFDQyxJQUFHLGVBQ0gsWUFBVSxNQUNWLFdBQVUsd0JBQ1YsVUFBV04sT0FBTUwsZUFBZUssRUFBRU8sT0FBT0MsS0FBSyxHQUM5QyxhQUNBLG1CQUFtQixPQUNuQixPQUFPZCxhQUNQLE9BQU87QUFBQSxRQUNMLEdBQUdJLE9BQU9XO0FBQUFBLFFBQ1ZDLE9BQU87QUFBQSxVQUNMLEdBQUlaLE9BQU9XLFdBQW1CQztBQUFBQSxVQUM5QkMsY0FBYztBQUFBLFlBQUVDLE1BQU07QUFBQSxVQUFJO0FBQUEsUUFDNUI7QUFBQSxRQUNBQyxPQUFPO0FBQUEsVUFDTCxHQUFJZixPQUFPVyxXQUFtQkk7QUFBQUEsVUFDOUJDLGNBQWM7QUFBQSxZQUNaQyxVQUFVO0FBQUEsY0FBRUgsTUFBTTtBQUFBLGNBQVFJLElBQUk7QUFBQSxZQUFPO0FBQUEsWUFDckNDLFdBQVc7QUFBQSxVQUNiO0FBQUEsUUFDRjtBQUFBLE1BQ0YsS0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFCSSxLQTFCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNEJBLEtBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4QkE7QUFBQSxNQUNBLHVCQUFDLGFBQVUsWUFBWTtBQUFBLFFBQUVMLE1BQU07QUFBQSxRQUFLSSxJQUFJO0FBQUEsTUFBSSxHQUMxQyxpQ0FBQyxlQUNDLGlDQUFDLFVBQ0MsY0FBVyxVQUNYLFlBQVcsUUFDWCxJQUFHLGNBQ0gsU0FBU2pCLFVBQ1QsT0FBTztBQUFBLFFBQUUsR0FBR0QsT0FBT29CO0FBQUFBLFFBQVdDLFNBQVM7QUFBQSxNQUFxQixHQUU1RCxpQ0FBQyxRQUFLLE1BQUssVUFBUyxNQUFLLFdBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0MsS0FQbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsU0E1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZDQTtBQUFBLElBQ0EsdUJBQUMsV0FDQyxpQ0FBQyxhQUNDLGlDQUFDLGNBQ0MsY0FBYSxzQkFDYixJQUFHLGVBQ0gsV0FBVSxrQkFDVixRQUFRN0IsV0FBVyxXQUFXLE9BQzlCLE1BQUssd0JBQ0wsVUFBVSxDQUFDOEIsUUFBMEJ2QixnQkFBZ0J1QixHQUFHLEdBQ3hELFdBQVcsT0FDWCxPQUFPO0FBQUEsTUFDTFYsT0FBTztBQUFBLFFBQ0xDLGNBQWM7QUFBQSxNQUNoQjtBQUFBLElBQ0YsR0FFQTtBQUFBLDZCQUFDLFNBQ0MsSUFBRyw0QkFDSCxXQUFVLG1DQUNWLE9BQU0sc0JBQ04sT0FBT2IsT0FBT3VCLFNBSmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJc0I7QUFBQSxNQUV0Qix1QkFBQyxTQUNDLElBQUcseUJBQ0gsV0FBVSwrQkFDVixPQUFNLG1CQUNOLE9BQU92QixPQUFPdUIsU0FKaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlzQjtBQUFBLE1BRXRCLHVCQUFDLFNBQ0MsSUFBRyxpQkFDSCxXQUFVLDhCQUNWLE9BQU0sV0FDTixPQUFPdkIsT0FBT3VCLFNBSmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJc0I7QUFBQSxTQTlCeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdDQSxLQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0NBLEtBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQ0E7QUFBQSxPQXhGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUZBLEtBMUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyRkE7QUFFSixHQUFDO0FBQUEsVUF4SGdCakQsbUJBQW1CO0FBQUEsRUF5SHRDLEdBQUM7QUFBQSxVQXpIa0JBLG1CQUFtQjtBQUFBO0FBeUhwQ2tELE1BbklJbkM7QUFxSU4sZUFBZUE7QUFBaUIsSUFBQUUsSUFBQWlDO0FBQUFDLGFBQUFsQyxJQUFBO0FBQUFrQyxhQUFBRCxLQUFBIiwibmFtZXMiOlsiQm94IiwiY2hha3JhIiwidXNlTXVsdGlTdHlsZUNvbmZpZyIsInVzZVN0YXRlIiwiZ2V0Q2F0YWxvZ1VSTCIsImdldE5ZUExTZWFyY2hVUkwiLCJnZXRSZXNlYXJjaENhdGFsb2dVUkwiLCJGb3JtIiwiRm9ybVJvdyIsIkZvcm1GaWVsZCIsIkZpZWxkc2V0IiwiVGV4dElucHV0IiwiQnV0dG9uR3JvdXAiLCJCdXR0b24iLCJJY29uIiwiUmFkaW9Hcm91cCIsIlJhZGlvIiwiSGVhZGVyU2VhcmNoRm9ybSIsIl9zIiwiX2MiLCJpc01vYmlsZSIsImRlZmF1bHRTZWFyY2hSYWRpb1ZhbHVlIiwicGxhY2Vob2xkZXIiLCJzZXRQbGFjZWhvbGRlciIsInNlYXJjaElucHV0Iiwic2V0U2VhcmNoSW5wdXQiLCJzZWFyY2hPcHRpb24iLCJzZXRTZWFyY2hPcHRpb24iLCJzdHlsZXMiLCJvblN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInJlcXVlc3RVcmwiLCJ3aW5kb3ciLCJsb2NhdGlvbiIsImFzc2lnbiIsImZvcm0iLCJ0YXJnZXQiLCJ2YWx1ZSIsInRleHRJbnB1dCIsImxhYmVsIiwibWFyZ2luQm90dG9tIiwiYmFzZSIsImlucHV0IiwiX3BsYWNlaG9sZGVyIiwiZm9udFNpemUiLCJtaCIsImZvbnRTdHlsZSIsInNlYXJjaEJ0biIsInBhZGRpbmciLCJ2YWwiLCJyYWRpbyIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkhlYWRlclNlYXJjaEZvcm0udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJveCwgY2hha3JhLCB1c2VNdWx0aVN0eWxlQ29uZmlnIH0gZnJvbSBcIkBjaGFrcmEtdWkvcmVhY3RcIjtcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5cbmltcG9ydCB7XG4gIGdldENhdGFsb2dVUkwsXG4gIGdldE5ZUExTZWFyY2hVUkwsXG4gIGdldFJlc2VhcmNoQ2F0YWxvZ1VSTCxcbn0gZnJvbSBcIi4uL3V0aWxzL2hlYWRlclV0aWxzXCI7XG5pbXBvcnQge1xuICBGb3JtLFxuICBGb3JtUm93LFxuICBGb3JtRmllbGQsXG4gIEZpZWxkc2V0LFxuICBUZXh0SW5wdXQsXG4gIEJ1dHRvbkdyb3VwLFxuICBCdXR0b24sXG4gIEljb24sXG4gIFJhZGlvR3JvdXAsXG4gIFJhZGlvLFxufSBmcm9tIFwiQG55cGwvZGVzaWduLXN5c3RlbS1yZWFjdC1jb21wb25lbnRzXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgSGVhZGVyU2VhcmNoRm9ybVByb3BzIHtcbiAgaXNNb2JpbGU/OiBib29sZWFuO1xufVxuXG5leHBvcnQgdHlwZSBTZWFyY2hPcHRpb25UeXBlID1cbiAgfCBcImNpcmN1bGF0aW5nQ2F0YWxvZ1wiXG4gIHwgXCJyZXNlYXJjaENhdGFsb2dcIlxuICB8IFwid2Vic2l0ZVwiO1xuXG4vKipcbiAqIERpc3BsYXlzIHRoZSBzZWFyY2ggZm9ybSBmb3IgdGhlIEhlYWRlcidzIHNlYXJjaCBpbnRlcmZhY2UuIE9uIG1vYmlsZSwgdHdvXG4gKiBidXR0b25zIGFyZSBkaXNwbGF5ZWQgYW5kIG9uIGRlc2t0b3AsIHR3byByYWRpbyBpbnB1dHMgYXJlIGRpc3BsYXllZC5cbiAqL1xuY29uc3QgSGVhZGVyU2VhcmNoRm9ybSA9IGNoYWtyYShcbiAgKHsgaXNNb2JpbGUgPSBmYWxzZSB9OiBIZWFkZXJTZWFyY2hGb3JtUHJvcHMpID0+IHtcbiAgICBjb25zdCBkZWZhdWx0U2VhcmNoUmFkaW9WYWx1ZTogU2VhcmNoT3B0aW9uVHlwZSA9IFwiY2lyY3VsYXRpbmdDYXRhbG9nXCI7XG4gICAgY29uc3QgW3BsYWNlaG9sZGVyLCBzZXRQbGFjZWhvbGRlcl0gPSB1c2VTdGF0ZTxzdHJpbmc+KFxuICAgICAgXCJXaGF0IHdvdWxkIHlvdSBsaWtlIHRvIGZpbmQ/XCJcbiAgICApO1xuICAgIGNvbnN0IFtzZWFyY2hJbnB1dCwgc2V0U2VhcmNoSW5wdXRdID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcbiAgICBjb25zdCBbc2VhcmNoT3B0aW9uLCBzZXRTZWFyY2hPcHRpb25dID0gdXNlU3RhdGU8U2VhcmNoT3B0aW9uVHlwZT4oXG4gICAgICBkZWZhdWx0U2VhcmNoUmFkaW9WYWx1ZVxuICAgICk7XG4gICAgY29uc3Qgc3R5bGVzID0gdXNlTXVsdGlTdHlsZUNvbmZpZyhcIkhlYWRlclNlYXJjaEZvcm1cIiwgeyBpc01vYmlsZSB9KTtcblxuICAgIGNvbnN0IG9uU3VibWl0ID0gKGU6IGFueSkgPT4ge1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgbGV0IHJlcXVlc3RVcmw7XG5cbiAgICAgIC8vIElmIHRoZXJlIGlzIGEgc2VhcmNoIGlucHV0LCBtYWtlIHRoZSByZXF1ZXN0LlxuICAgICAgaWYgKHNlYXJjaElucHV0KSB7XG4gICAgICAgIGlmIChzZWFyY2hPcHRpb24gPT09IFwiY2lyY3VsYXRpbmdDYXRhbG9nXCIpIHtcbiAgICAgICAgICByZXF1ZXN0VXJsID0gZ2V0Q2F0YWxvZ1VSTChzZWFyY2hJbnB1dCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHNlYXJjaE9wdGlvbiA9PT0gXCJyZXNlYXJjaENhdGFsb2dcIikge1xuICAgICAgICAgIHJlcXVlc3RVcmwgPSBnZXRSZXNlYXJjaENhdGFsb2dVUkwoc2VhcmNoSW5wdXQpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzZWFyY2hPcHRpb24gPT09IFwid2Vic2l0ZVwiKSB7XG4gICAgICAgICAgcmVxdWVzdFVybCA9IGdldE5ZUExTZWFyY2hVUkwoc2VhcmNoSW5wdXQpO1xuICAgICAgICB9XG5cbiAgICAgICAgd2luZG93LmxvY2F0aW9uLmFzc2lnbihyZXF1ZXN0VXJsKTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICAvLyBPdGhlcndpc2UsIGRvbid0IGRvIGFueXRoaW5nIGFuZCB1cGRhdGUgdGhlIHBsYWNlaG9sZGVyIG1lc3NhZ2UuXG4gICAgICBzZXRQbGFjZWhvbGRlcihcIlBsZWFzZSBlbnRlciBhIHNlYXJjaCB0ZXJtLlwiKTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgIDxCb3ggX19jc3M9e3N0eWxlc30+XG4gICAgICAgIDxGb3JtXG4gICAgICAgICAgaWQ9XCJzZWFyY2gtaGVhZGVyXCJcbiAgICAgICAgICBnYXA9XCJncmlkLm1cIlxuICAgICAgICAgIG9uU3VibWl0PXtvblN1Ym1pdH1cbiAgICAgICAgICBfX2Nzcz17c3R5bGVzLmZvcm19XG4gICAgICAgID5cbiAgICAgICAgICA8Rm9ybVJvdz5cbiAgICAgICAgICAgIDxGb3JtRmllbGQgZ3JpZENvbHVtbj1cIjEgLyAzXCI+XG4gICAgICAgICAgICAgIDxGaWVsZHNldFxuICAgICAgICAgICAgICAgIGlkPVwiZmllbGRzZXQtc2VhcmNoXCJcbiAgICAgICAgICAgICAgICBpc0xlZ2VuZEhpZGRlblxuICAgICAgICAgICAgICAgIGxlZ2VuZFRleHQ9XCJFbnRlciBhIGtleXdvcmQsIHRoZW4gY2hvb3NlIHRvIHNlYXJjaCBlaXRoZXIgdGhlIGNhdGFsb2cgb3IgdGhlIHdlYnNpdGVcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFRleHRJbnB1dFxuICAgICAgICAgICAgICAgICAgaWQ9XCJzZWFyY2hJbnB1dFwiXG4gICAgICAgICAgICAgICAgICBpc1JlcXVpcmVkXG4gICAgICAgICAgICAgICAgICBsYWJlbFRleHQ9XCJFbnRlciBTZWFyY2ggS2V5d29yZFwiXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaElucHV0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtwbGFjZWhvbGRlcn1cbiAgICAgICAgICAgICAgICAgIHNob3dSZXF1aXJlZExhYmVsPXtmYWxzZX1cbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hJbnB1dH1cbiAgICAgICAgICAgICAgICAgIF9fY3NzPXt7XG4gICAgICAgICAgICAgICAgICAgIC4uLnN0eWxlcy50ZXh0SW5wdXQsXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsOiB7XG4gICAgICAgICAgICAgICAgICAgICAgLi4uKHN0eWxlcy50ZXh0SW5wdXQgYXMgYW55KT8ubGFiZWwsXG4gICAgICAgICAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiB7IGJhc2U6IFwic1wiIH0sXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIGlucHV0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgLi4uKHN0eWxlcy50ZXh0SW5wdXQgYXMgYW55KT8uaW5wdXQsXG4gICAgICAgICAgICAgICAgICAgICAgX3BsYWNlaG9sZGVyOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogeyBiYXNlOiBcIjE4cHhcIiwgbWg6IFwiMjBweFwiIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U3R5bGU6IFwibm9ybWFsXCIsXG4gICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9GaWVsZHNldD5cbiAgICAgICAgICAgIDwvRm9ybUZpZWxkPlxuICAgICAgICAgICAgPEZvcm1GaWVsZCBncmlkQ29sdW1uPXt7IGJhc2U6IFwiM1wiLCBtaDogXCI0XCIgfX0+XG4gICAgICAgICAgICAgIDxCdXR0b25Hcm91cD5cbiAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiU2VhcmNoXCJcbiAgICAgICAgICAgICAgICAgIGJ1dHRvblR5cGU9XCJwaWxsXCJcbiAgICAgICAgICAgICAgICAgIGlkPVwic2VhcmNoLWJ0blwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvblN1Ym1pdH1cbiAgICAgICAgICAgICAgICAgIF9fY3NzPXt7IC4uLnN0eWxlcy5zZWFyY2hCdG4sIHBhZGRpbmc6IFwiMXB4IDZweCAhaW1wb3J0YW50XCIgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwic2VhcmNoXCIgc2l6ZT1cImxhcmdlXCIgLz5cbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPC9CdXR0b25Hcm91cD5cbiAgICAgICAgICAgIDwvRm9ybUZpZWxkPlxuICAgICAgICAgIDwvRm9ybVJvdz5cbiAgICAgICAgICA8Rm9ybVJvdz5cbiAgICAgICAgICAgIDxGb3JtRmllbGQ+XG4gICAgICAgICAgICAgIDxSYWRpb0dyb3VwXG4gICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlPVwiY2lyY3VsYXRpbmdDYXRhbG9nXCJcbiAgICAgICAgICAgICAgICBpZD1cInNlYXJjaC10eXBlXCJcbiAgICAgICAgICAgICAgICBsYWJlbFRleHQ9XCJUeXBlIG9mIHNlYXJjaFwiXG4gICAgICAgICAgICAgICAgbGF5b3V0PXtpc01vYmlsZSA/IFwiY29sdW1uXCIgOiBcInJvd1wifVxuICAgICAgICAgICAgICAgIG5hbWU9XCJjYXRhbG9nV2Vic2l0ZVNlYXJjaFwiXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWw6IFNlYXJjaE9wdGlvblR5cGUpID0+IHNldFNlYXJjaE9wdGlvbih2YWwpfVxuICAgICAgICAgICAgICAgIHNob3dMYWJlbD17ZmFsc2V9XG4gICAgICAgICAgICAgICAgX19jc3M9e3tcbiAgICAgICAgICAgICAgICAgIGxhYmVsOiB7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogXCIwXCIsXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8UmFkaW9cbiAgICAgICAgICAgICAgICAgIGlkPVwiY2lyY3VsYXRpbmdDYXRhbG9nU2VhcmNoXCJcbiAgICAgICAgICAgICAgICAgIGxhYmVsVGV4dD1cIlNlYXJjaCBib29rcywgbXVzaWMsIGFuZCBtb3ZpZXNcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9XCJjaXJjdWxhdGluZ0NhdGFsb2dcIlxuICAgICAgICAgICAgICAgICAgX19jc3M9e3N0eWxlcy5yYWRpb31cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxSYWRpb1xuICAgICAgICAgICAgICAgICAgaWQ9XCJyZXNlYXJjaGNhdGFsb2dTZWFyY2hcIlxuICAgICAgICAgICAgICAgICAgbGFiZWxUZXh0PVwiU2VhcmNoIHRoZSBSZXNlYXJjaCBDYXRhbG9nXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPVwicmVzZWFyY2hDYXRhbG9nXCJcbiAgICAgICAgICAgICAgICAgIF9fY3NzPXtzdHlsZXMucmFkaW99XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8UmFkaW9cbiAgICAgICAgICAgICAgICAgIGlkPVwid2Vic2l0ZVNlYXJjaFwiXG4gICAgICAgICAgICAgICAgICBsYWJlbFRleHQ9XCJTZWFyY2ggdGhlIGxpYnJhcnkgd2Vic2l0ZVwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT1cIndlYnNpdGVcIlxuICAgICAgICAgICAgICAgICAgX19jc3M9e3N0eWxlcy5yYWRpb31cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L1JhZGlvR3JvdXA+XG4gICAgICAgICAgICA8L0Zvcm1GaWVsZD5cbiAgICAgICAgICA8L0Zvcm1Sb3c+XG4gICAgICAgIDwvRm9ybT5cbiAgICAgIDwvQm94PlxuICAgICk7XG4gIH1cbik7XG5cbmV4cG9ydCBkZWZhdWx0IEhlYWRlclNlYXJjaEZvcm07XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaHJpc211bGhvbGxhbmQvU2l0ZXMvdGVzdHMvbnlwbC1oZWFkZXItYXBwL3NyYy9jb21wb25lbnRzL0hlYWRlci9jb21wb25lbnRzL0hlYWRlclNlYXJjaEZvcm0udHN4In0=