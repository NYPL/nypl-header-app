import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/Header/components/HeaderLoginButton.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLoginButton.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/react.js?v=f7bb76b7"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import { Box, chakra, useStyleConfig } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@chakra-ui_react.js?v=2c813617";
import FocusLock from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@chakra-ui_focus-lock.js?v=92ee0591";
import { Button, Icon, useCloseDropDown } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@nypl_design-system-react-components.js?v=f372bde6";
import HeaderLogin from "/components/Header/components/HeaderLogin.tsx";
const HeaderLoginButton = _s(chakra(_c = _s(({
  isMobile = false
}) => {
  _s();
  const [isOpen, setIsOpen] = useState(false);
  const catalogRef = useRef(null);
  const wrapperRef = useRef(null);
  const styles = useStyleConfig("HeaderLoginButton", {
    isOpen
  });
  const desktopIcon = isOpen ? "close" : "arrow";
  const mobileIcon = isOpen ? "close" : "actionIdentityFilled";
  const desktopButtonLabel = isOpen ? "Close" : "My Account";
  useCloseDropDown(setIsOpen, wrapperRef);
  useEffect(() => {
    if (isOpen) {
      catalogRef.current.focus();
    }
  }, [isOpen]);
  return /* @__PURE__ */ jsxDEV(Box, { ref: wrapperRef, position: {
    mh: "relative"
  }, children: /* @__PURE__ */ jsxDEV(FocusLock, { isDisabled: !isOpen, children: [
    /* @__PURE__ */ jsxDEV(Button, { "aria-label": desktopButtonLabel, buttonType: "text", id: "loginButton", onClick: () => {
      setIsOpen(!isOpen);
    }, __css: {
      ...styles,
      border: "none !important",
      letterSpacing: 0,
      px: "xs",
      py: "0"
    }, children: [
      isMobile ? null : desktopButtonLabel,
      /* @__PURE__ */ jsxDEV(Icon, { align: "right", name: isMobile ? mobileIcon : desktopIcon, size: isMobile ? "large" : "small", title: "Log in to your account" }, void 0, false, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLoginButton.tsx",
        lineNumber: 49,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLoginButton.tsx",
      lineNumber: 39,
      columnNumber: 11
    }, this),
    isOpen && /* @__PURE__ */ jsxDEV(HeaderLogin, { catalogRef, isMobile }, void 0, false, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLoginButton.tsx",
      lineNumber: 51,
      columnNumber: 22
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLoginButton.tsx",
    lineNumber: 38,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLoginButton.tsx",
    lineNumber: 35,
    columnNumber: 10
  }, this);
}, "y5d2NYiRDLBJpCaYE6D2n/R3Aks=", false, function() {
  return [useStyleConfig, useCloseDropDown];
})), "y5d2NYiRDLBJpCaYE6D2n/R3Aks=", false, function() {
  return [useStyleConfig, useCloseDropDown];
});
_c2 = HeaderLoginButton;
export default HeaderLoginButton;
var _c, _c2;
$RefreshReg$(_c, "HeaderLoginButton$chakra");
$RefreshReg$(_c2, "HeaderLoginButton");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLoginButton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkRZOzs7Ozs7Ozs7Ozs7Ozs7O0FBM0RaLFNBQWdCQSxXQUFXQyxRQUFRQyxnQkFBZ0I7QUFDbkQsU0FBU0MsS0FBS0MsUUFBUUMsc0JBQXNCO0FBQzVDLE9BQU9DLGVBQWU7QUFFdEIsU0FDRUMsUUFDQUMsTUFDQUMsd0JBQ0s7QUFDUCxPQUFPQyxpQkFBaUI7QUFXeEIsTUFBTUMsb0JBQWlCQyxHQUFHUixPQUFNUyxLQUFBRCxHQUM5QixDQUFDO0FBQUEsRUFBRUUsV0FBVztBQUE4QixNQUFNO0FBQUFGLEtBQUE7QUFDaEQsUUFBTSxDQUFDRyxRQUFRQyxTQUFTLElBQUlkLFNBQWtCLEtBQUs7QUFDbkQsUUFBTWUsYUFBYWhCLE9BQTJDLElBQUk7QUFDbEUsUUFBTWlCLGFBQWFqQixPQUF1QixJQUFJO0FBQzlDLFFBQU1rQixTQUFTZCxlQUFlLHFCQUFxQjtBQUFBLElBQ2pEVTtBQUFBQSxFQUNGLENBQUM7QUFDRCxRQUFNSyxjQUFjTCxTQUFTLFVBQVU7QUFDdkMsUUFBTU0sYUFBYU4sU0FBUyxVQUFVO0FBQ3RDLFFBQU1PLHFCQUFxQlAsU0FBUyxVQUFVO0FBRTlDTixtQkFBaUJPLFdBQVdFLFVBQVU7QUFFdENsQixZQUFVLE1BQU07QUFDZCxRQUFJZSxRQUFRO0FBQ1ZFLGlCQUFXTSxRQUFRQyxNQUFNO0FBQUEsSUFDM0I7QUFBQSxFQUNGLEdBQUcsQ0FBQ1QsTUFBTSxDQUFDO0FBRVgsU0FDRSx1QkFBQyxPQUFJLEtBQUtHLFlBQVksVUFBVTtBQUFBLElBQUVPLElBQUk7QUFBQSxFQUFXLEdBQy9DLGlDQUFDLGFBQVUsWUFBWSxDQUFDVixRQUN0QjtBQUFBLDJCQUFDLFVBQ0MsY0FBWU8sb0JBQ1osWUFBVyxRQUNYLElBQUcsZUFDSCxTQUFTLE1BQU07QUFDYk4sZ0JBQVUsQ0FBQ0QsTUFBTTtBQUFBLElBQ25CLEdBQ0EsT0FBTztBQUFBLE1BQ0wsR0FBR0k7QUFBQUEsTUFDSE8sUUFBUTtBQUFBLE1BQ1JDLGVBQWU7QUFBQSxNQUNmQyxJQUFJO0FBQUEsTUFDSkMsSUFBSTtBQUFBLElBQ04sR0FFQ2Y7QUFBQUEsaUJBQVcsT0FBT1E7QUFBQUEsTUFDbkIsdUJBQUMsUUFDQyxPQUFNLFNBQ04sTUFBTVIsV0FBV08sYUFBYUQsYUFDOUIsTUFBTU4sV0FBVyxVQUFVLFNBQzNCLE9BQU0sNEJBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlnQztBQUFBLFNBcEJsQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0JBO0FBQUEsSUFDQ0MsVUFDQyx1QkFBQyxlQUFZLFlBQXdCLFlBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0Q7QUFBQSxPQXpCNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJCQSxLQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkJBO0FBRUosR0FBQztBQUFBLFVBL0NnQlYsZ0JBT2ZJLGdCQUFnQjtBQUFBLEVBeUNwQixHQUFDO0FBQUEsVUFoRGtCSixnQkFPZkksZ0JBQWdCO0FBQUE7QUF5Q2xCcUIsTUFyREluQjtBQXVETixlQUFlQTtBQUFrQixJQUFBRSxJQUFBaUI7QUFBQUMsYUFBQWxCLElBQUE7QUFBQWtCLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJ1c2VTdGF0ZSIsIkJveCIsImNoYWtyYSIsInVzZVN0eWxlQ29uZmlnIiwiRm9jdXNMb2NrIiwiQnV0dG9uIiwiSWNvbiIsInVzZUNsb3NlRHJvcERvd24iLCJIZWFkZXJMb2dpbiIsIkhlYWRlckxvZ2luQnV0dG9uIiwiX3MiLCJfYyIsImlzTW9iaWxlIiwiaXNPcGVuIiwic2V0SXNPcGVuIiwiY2F0YWxvZ1JlZiIsIndyYXBwZXJSZWYiLCJzdHlsZXMiLCJkZXNrdG9wSWNvbiIsIm1vYmlsZUljb24iLCJkZXNrdG9wQnV0dG9uTGFiZWwiLCJjdXJyZW50IiwiZm9jdXMiLCJtaCIsImJvcmRlciIsImxldHRlclNwYWNpbmciLCJweCIsInB5IiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiSGVhZGVyTG9naW5CdXR0b24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEJveCwgY2hha3JhLCB1c2VTdHlsZUNvbmZpZyB9IGZyb20gXCJAY2hha3JhLXVpL3JlYWN0XCI7XG5pbXBvcnQgRm9jdXNMb2NrIGZyb20gXCJAY2hha3JhLXVpL2ZvY3VzLWxvY2tcIjtcblxuaW1wb3J0IHtcbiAgQnV0dG9uLFxuICBJY29uLFxuICB1c2VDbG9zZURyb3BEb3duLFxufSBmcm9tIFwiQG55cGwvZGVzaWduLXN5c3RlbS1yZWFjdC1jb21wb25lbnRzXCI7XG5pbXBvcnQgSGVhZGVyTG9naW4gZnJvbSBcIi4vSGVhZGVyTG9naW5cIjtcblxuZXhwb3J0IGludGVyZmFjZSBIZWFkZXJMb2dpbkJ1dHRvblByb3BzIHtcbiAgaXNNb2JpbGU/OiBib29sZWFuO1xufVxuXG4vKipcbiAqIFRoaXMgaXMgdGhlIGJ1dHRvbiB0aGF0IHdpbGwgcmVuZGVyIHRoZSBsb2dpbiBtZW51IHdoZW4gaXQgaXMgY2xpY2tlZFxuICogYW5kIGtlZXAgZm9jdXMgdHJhcHBlZCB3aXRoaW4gdGhlIG1lbnUuIEl0cyBkaXNwbGF5IHRleHQgd2lsbCBiZSBcIkxvZyBJblwiXG4gKiB3aGVuIHRoZSB1c2VyIGlzIG5vdCBsb2dnZWQgaW4gYW5kIFwiTXkgQWNjb3VudFwiIHdoZW4gdGhlIHVzZXIgaXMgbG9nZ2VkIGluLlxuICovXG5jb25zdCBIZWFkZXJMb2dpbkJ1dHRvbiA9IGNoYWtyYShcbiAgKHsgaXNNb2JpbGUgPSBmYWxzZSB9OiBIZWFkZXJMb2dpbkJ1dHRvblByb3BzKSA9PiB7XG4gICAgY29uc3QgW2lzT3Blbiwgc2V0SXNPcGVuXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgICBjb25zdCBjYXRhbG9nUmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50ICYgSFRNTEFuY2hvckVsZW1lbnQ+KG51bGwpO1xuICAgIGNvbnN0IHdyYXBwZXJSZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xuICAgIGNvbnN0IHN0eWxlcyA9IHVzZVN0eWxlQ29uZmlnKFwiSGVhZGVyTG9naW5CdXR0b25cIiwge1xuICAgICAgaXNPcGVuLFxuICAgIH0pO1xuICAgIGNvbnN0IGRlc2t0b3BJY29uID0gaXNPcGVuID8gXCJjbG9zZVwiIDogXCJhcnJvd1wiO1xuICAgIGNvbnN0IG1vYmlsZUljb24gPSBpc09wZW4gPyBcImNsb3NlXCIgOiBcImFjdGlvbklkZW50aXR5RmlsbGVkXCI7XG4gICAgY29uc3QgZGVza3RvcEJ1dHRvbkxhYmVsID0gaXNPcGVuID8gXCJDbG9zZVwiIDogXCJNeSBBY2NvdW50XCI7XG5cbiAgICB1c2VDbG9zZURyb3BEb3duKHNldElzT3Blbiwgd3JhcHBlclJlZik7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgaWYgKGlzT3Blbikge1xuICAgICAgICBjYXRhbG9nUmVmLmN1cnJlbnQuZm9jdXMoKTtcbiAgICAgIH1cbiAgICB9LCBbaXNPcGVuXSk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgPEJveCByZWY9e3dyYXBwZXJSZWZ9IHBvc2l0aW9uPXt7IG1oOiBcInJlbGF0aXZlXCIgfX0+XG4gICAgICAgIDxGb2N1c0xvY2sgaXNEaXNhYmxlZD17IWlzT3Blbn0+XG4gICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgYXJpYS1sYWJlbD17ZGVza3RvcEJ1dHRvbkxhYmVsfVxuICAgICAgICAgICAgYnV0dG9uVHlwZT1cInRleHRcIlxuICAgICAgICAgICAgaWQ9XCJsb2dpbkJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgIHNldElzT3BlbighaXNPcGVuKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBfX2Nzcz17e1xuICAgICAgICAgICAgICAuLi5zdHlsZXMsXG4gICAgICAgICAgICAgIGJvcmRlcjogXCJub25lICFpbXBvcnRhbnRcIixcbiAgICAgICAgICAgICAgbGV0dGVyU3BhY2luZzogMCxcbiAgICAgICAgICAgICAgcHg6IFwieHNcIixcbiAgICAgICAgICAgICAgcHk6IFwiMFwiLFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7aXNNb2JpbGUgPyBudWxsIDogZGVza3RvcEJ1dHRvbkxhYmVsfVxuICAgICAgICAgICAgPEljb25cbiAgICAgICAgICAgICAgYWxpZ249XCJyaWdodFwiXG4gICAgICAgICAgICAgIG5hbWU9e2lzTW9iaWxlID8gbW9iaWxlSWNvbiA6IGRlc2t0b3BJY29ufVxuICAgICAgICAgICAgICBzaXplPXtpc01vYmlsZSA/IFwibGFyZ2VcIiA6IFwic21hbGxcIn1cbiAgICAgICAgICAgICAgdGl0bGU9XCJMb2cgaW4gdG8geW91ciBhY2NvdW50XCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAge2lzT3BlbiAmJiAoXG4gICAgICAgICAgICA8SGVhZGVyTG9naW4gY2F0YWxvZ1JlZj17Y2F0YWxvZ1JlZn0gaXNNb2JpbGU9e2lzTW9iaWxlfSAvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvRm9jdXNMb2NrPlxuICAgICAgPC9Cb3g+XG4gICAgKTtcbiAgfVxuKTtcblxuZXhwb3J0IGRlZmF1bHQgSGVhZGVyTG9naW5CdXR0b247XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaHJpc211bGhvbGxhbmQvU2l0ZXMvdGVzdHMvbnlwbC1oZWFkZXItYXBwL3NyYy9jb21wb25lbnRzL0hlYWRlci9jb21wb25lbnRzL0hlYWRlckxvZ2luQnV0dG9uLnRzeCJ9