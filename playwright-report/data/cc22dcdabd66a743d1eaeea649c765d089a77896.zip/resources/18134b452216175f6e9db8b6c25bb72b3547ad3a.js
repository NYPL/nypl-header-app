import { headerBlue, headerFocus } from "/theme/header.ts";
const HeaderSearchButton = {
  baseStyle: ({ isOpen }) => ({
    alignItems: "center",
    borderRadius: "0",
    backgroundColor: isOpen ? headerBlue : "transparent",
    color: isOpen ? "ui.white" : "ui.link.primary",
    display: "flex",
    fontFamily: "body",
    fontSize: "inherit !important",
    fontWeight: "medium",
    justifyContent: "center",
    minHeight: { mh: "30px" },
    minWidth: { mh: "80px" },
    textDecoration: "none",
    _dark: {
      bgColor: isOpen ? "section.research.secondary" : "transparent",
      color: isOpen ? "ui.white" : "dark.ui.link.primary"
    },
    span: {
      alignItems: "center",
      borderBottom: { mh: "1px solid var(--nypl-colors-ui-link-primary)" },
      display: "inline-flex",
      _dark: {
        borderBottom: isOpen ? "0" : { mh: "3px solid" },
        borderColor: { mh: "dark.ui.link.primary" }
      }
    },
    svg: {
      marginLeft: { base: "0", mh: "xxs" },
      fill: {
        base: isOpen ? "ui.white" : "ui.black",
        mh: isOpen ? "ui.white" : "ui.link.primary"
      },
      _dark: {
        fill: {
          base: isOpen ? "ui.white" : "dark.ui.typography.heading",
          mh: isOpen ? "ui.white" : "dark.ui.link.primary"
        }
      }
    },
    _hover: {
      backgroundColor: isOpen ? headerBlue : "transparent",
      color: isOpen ? "ui.white" : "ui.link.primary",
      textDecoration: "none",
      svg: {
        fill: {
          base: isOpen ? "ui.white" : "ui.black",
          mh: isOpen ? "ui.white" : "ui.link.primary"
        }
      },
      _dark: {
        color: isOpen ? "ui.white" : "dark.ui.link.primary",
        svg: {
          fill: {
            base: isOpen ? "ui.white" : "dark.ui.typography.heading",
            mh: isOpen ? "ui.white" : "dark.ui.link.primary"
          }
        }
      }
    },
    _focus: headerFocus
  })
};
export default HeaderSearchButton;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlclNlYXJjaEJ1dHRvbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBoZWFkZXJCbHVlLCBoZWFkZXJGb2N1cyB9IGZyb20gXCIuL2hlYWRlclwiO1xuXG5jb25zdCBIZWFkZXJTZWFyY2hCdXR0b24gPSB7XG4gIGJhc2VTdHlsZTogKHsgaXNPcGVuIH0pID0+ICh7XG4gICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcbiAgICBib3JkZXJSYWRpdXM6IFwiMFwiLFxuICAgIGJhY2tncm91bmRDb2xvcjogaXNPcGVuID8gaGVhZGVyQmx1ZSA6IFwidHJhbnNwYXJlbnRcIixcbiAgICBjb2xvcjogaXNPcGVuID8gXCJ1aS53aGl0ZVwiIDogXCJ1aS5saW5rLnByaW1hcnlcIixcbiAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICBmb250RmFtaWx5OiBcImJvZHlcIixcbiAgICBmb250U2l6ZTogXCJpbmhlcml0ICFpbXBvcnRhbnRcIixcbiAgICBmb250V2VpZ2h0OiBcIm1lZGl1bVwiLFxuICAgIGp1c3RpZnlDb250ZW50OiBcImNlbnRlclwiLFxuICAgIG1pbkhlaWdodDogeyBtaDogXCIzMHB4XCIgfSxcbiAgICBtaW5XaWR0aDogeyBtaDogXCI4MHB4XCIgfSxcbiAgICB0ZXh0RGVjb3JhdGlvbjogXCJub25lXCIsXG4gICAgX2Rhcms6IHtcbiAgICAgIGJnQ29sb3I6IGlzT3BlbiA/IFwic2VjdGlvbi5yZXNlYXJjaC5zZWNvbmRhcnlcIiA6IFwidHJhbnNwYXJlbnRcIixcbiAgICAgIGNvbG9yOiBpc09wZW4gPyBcInVpLndoaXRlXCIgOiBcImRhcmsudWkubGluay5wcmltYXJ5XCIsXG4gICAgfSxcbiAgICBzcGFuOiB7XG4gICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgICAgYm9yZGVyQm90dG9tOiB7IG1oOiBcIjFweCBzb2xpZCB2YXIoLS1ueXBsLWNvbG9ycy11aS1saW5rLXByaW1hcnkpXCIgfSxcbiAgICAgIGRpc3BsYXk6IFwiaW5saW5lLWZsZXhcIixcbiAgICAgIF9kYXJrOiB7XG4gICAgICAgIGJvcmRlckJvdHRvbTogaXNPcGVuID8gXCIwXCIgOiB7IG1oOiBcIjNweCBzb2xpZFwiIH0sXG4gICAgICAgIGJvcmRlckNvbG9yOiB7IG1oOiBcImRhcmsudWkubGluay5wcmltYXJ5XCIgfSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBzdmc6IHtcbiAgICAgIG1hcmdpbkxlZnQ6IHsgYmFzZTogXCIwXCIsIG1oOiBcInh4c1wiIH0sXG4gICAgICBmaWxsOiB7XG4gICAgICAgIGJhc2U6IGlzT3BlbiA/IFwidWkud2hpdGVcIiA6IFwidWkuYmxhY2tcIixcbiAgICAgICAgbWg6IGlzT3BlbiA/IFwidWkud2hpdGVcIiA6IFwidWkubGluay5wcmltYXJ5XCIsXG4gICAgICB9LFxuICAgICAgX2Rhcms6IHtcbiAgICAgICAgZmlsbDoge1xuICAgICAgICAgIGJhc2U6IGlzT3BlbiA/IFwidWkud2hpdGVcIiA6IFwiZGFyay51aS50eXBvZ3JhcGh5LmhlYWRpbmdcIixcbiAgICAgICAgICBtaDogaXNPcGVuID8gXCJ1aS53aGl0ZVwiIDogXCJkYXJrLnVpLmxpbmsucHJpbWFyeVwiLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9LFxuICAgIF9ob3Zlcjoge1xuICAgICAgYmFja2dyb3VuZENvbG9yOiBpc09wZW4gPyBoZWFkZXJCbHVlIDogXCJ0cmFuc3BhcmVudFwiLFxuICAgICAgY29sb3I6IGlzT3BlbiA/IFwidWkud2hpdGVcIiA6IFwidWkubGluay5wcmltYXJ5XCIsXG4gICAgICB0ZXh0RGVjb3JhdGlvbjogXCJub25lXCIsXG4gICAgICBzdmc6IHtcbiAgICAgICAgZmlsbDoge1xuICAgICAgICAgIGJhc2U6IGlzT3BlbiA/IFwidWkud2hpdGVcIiA6IFwidWkuYmxhY2tcIixcbiAgICAgICAgICBtaDogaXNPcGVuID8gXCJ1aS53aGl0ZVwiIDogXCJ1aS5saW5rLnByaW1hcnlcIixcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICBfZGFyazoge1xuICAgICAgICBjb2xvcjogaXNPcGVuID8gXCJ1aS53aGl0ZVwiIDogXCJkYXJrLnVpLmxpbmsucHJpbWFyeVwiLFxuICAgICAgICBzdmc6IHtcbiAgICAgICAgICBmaWxsOiB7XG4gICAgICAgICAgICBiYXNlOiBpc09wZW4gPyBcInVpLndoaXRlXCIgOiBcImRhcmsudWkudHlwb2dyYXBoeS5oZWFkaW5nXCIsXG4gICAgICAgICAgICBtaDogaXNPcGVuID8gXCJ1aS53aGl0ZVwiIDogXCJkYXJrLnVpLmxpbmsucHJpbWFyeVwiLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0sXG4gICAgX2ZvY3VzOiBoZWFkZXJGb2N1cyxcbiAgfSksXG59O1xuXG5leHBvcnQgZGVmYXVsdCBIZWFkZXJTZWFyY2hCdXR0b247XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsWUFBWSxtQkFBbUI7QUFFeEMsTUFBTSxxQkFBcUI7QUFBQSxFQUN6QixXQUFXLENBQUMsRUFBRSxPQUFPLE9BQU87QUFBQSxJQUMxQixZQUFZO0FBQUEsSUFDWixjQUFjO0FBQUEsSUFDZCxpQkFBaUIsU0FBUyxhQUFhO0FBQUEsSUFDdkMsT0FBTyxTQUFTLGFBQWE7QUFBQSxJQUM3QixTQUFTO0FBQUEsSUFDVCxZQUFZO0FBQUEsSUFDWixVQUFVO0FBQUEsSUFDVixZQUFZO0FBQUEsSUFDWixnQkFBZ0I7QUFBQSxJQUNoQixXQUFXLEVBQUUsSUFBSSxPQUFPO0FBQUEsSUFDeEIsVUFBVSxFQUFFLElBQUksT0FBTztBQUFBLElBQ3ZCLGdCQUFnQjtBQUFBLElBQ2hCLE9BQU87QUFBQSxNQUNMLFNBQVMsU0FBUywrQkFBK0I7QUFBQSxNQUNqRCxPQUFPLFNBQVMsYUFBYTtBQUFBLElBQy9CO0FBQUEsSUFDQSxNQUFNO0FBQUEsTUFDSixZQUFZO0FBQUEsTUFDWixjQUFjLEVBQUUsSUFBSSwrQ0FBK0M7QUFBQSxNQUNuRSxTQUFTO0FBQUEsTUFDVCxPQUFPO0FBQUEsUUFDTCxjQUFjLFNBQVMsTUFBTSxFQUFFLElBQUksWUFBWTtBQUFBLFFBQy9DLGFBQWEsRUFBRSxJQUFJLHVCQUF1QjtBQUFBLE1BQzVDO0FBQUEsSUFDRjtBQUFBLElBQ0EsS0FBSztBQUFBLE1BQ0gsWUFBWSxFQUFFLE1BQU0sS0FBSyxJQUFJLE1BQU07QUFBQSxNQUNuQyxNQUFNO0FBQUEsUUFDSixNQUFNLFNBQVMsYUFBYTtBQUFBLFFBQzVCLElBQUksU0FBUyxhQUFhO0FBQUEsTUFDNUI7QUFBQSxNQUNBLE9BQU87QUFBQSxRQUNMLE1BQU07QUFBQSxVQUNKLE1BQU0sU0FBUyxhQUFhO0FBQUEsVUFDNUIsSUFBSSxTQUFTLGFBQWE7QUFBQSxRQUM1QjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxRQUFRO0FBQUEsTUFDTixpQkFBaUIsU0FBUyxhQUFhO0FBQUEsTUFDdkMsT0FBTyxTQUFTLGFBQWE7QUFBQSxNQUM3QixnQkFBZ0I7QUFBQSxNQUNoQixLQUFLO0FBQUEsUUFDSCxNQUFNO0FBQUEsVUFDSixNQUFNLFNBQVMsYUFBYTtBQUFBLFVBQzVCLElBQUksU0FBUyxhQUFhO0FBQUEsUUFDNUI7QUFBQSxNQUNGO0FBQUEsTUFDQSxPQUFPO0FBQUEsUUFDTCxPQUFPLFNBQVMsYUFBYTtBQUFBLFFBQzdCLEtBQUs7QUFBQSxVQUNILE1BQU07QUFBQSxZQUNKLE1BQU0sU0FBUyxhQUFhO0FBQUEsWUFDNUIsSUFBSSxTQUFTLGFBQWE7QUFBQSxVQUM1QjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLElBQ0EsUUFBUTtBQUFBLEVBQ1Y7QUFDRjtBQUVBLGVBQWU7IiwibmFtZXMiOltdfQ==