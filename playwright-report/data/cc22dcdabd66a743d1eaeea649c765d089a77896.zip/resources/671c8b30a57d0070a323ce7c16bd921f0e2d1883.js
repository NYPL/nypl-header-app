import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/Header/components/HeaderMobileNavButton.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNavButton.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import FocusLock from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@chakra-ui_focus-lock.js?v=92ee0591";
import { Box, chakra, useStyleConfig } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@chakra-ui_react.js?v=2c813617";
import { Button, Icon, useCloseDropDown } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@nypl_design-system-react-components.js?v=f372bde6";
import __vite__cjsImport6_react from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/react.js?v=f7bb76b7"; const useState = __vite__cjsImport6_react["useState"]; const useRef = __vite__cjsImport6_react["useRef"];
import HeaderMobileNav from "/components/Header/components/HeaderMobileNav.tsx";
const HeaderMobileNavButton = _s(chakra(_c = _s(() => {
  _s();
  const [isOpen, setIsOpen] = useState(false);
  const styles = useStyleConfig("HeaderMobileNavButton", {
    isOpen
  });
  const ref = useRef(null);
  useCloseDropDown(setIsOpen, ref);
  return /* @__PURE__ */ jsxDEV(Box, { ref, children: /* @__PURE__ */ jsxDEV(FocusLock, { isDisabled: !isOpen, children: [
    /* @__PURE__ */ jsxDEV(Button, { "aria-haspopup": "true", "aria-label": isOpen ? "Close Navigation" : "Open Navigation", "aria-expanded": isOpen ? true : null, buttonType: "text", id: "mobileNav-btn", onClick: () => {
      setIsOpen(!isOpen);
    }, __css: {
      ...styles,
      padding: "1px 6px !important"
    }, children: /* @__PURE__ */ jsxDEV(Icon, { name: isOpen ? "close" : "utilityHamburger", size: "large" }, void 0, false, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNavButton.tsx",
      lineNumber: 28,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNavButton.tsx",
      lineNumber: 22,
      columnNumber: 9
    }, this),
    isOpen && /* @__PURE__ */ jsxDEV(HeaderMobileNav, {}, void 0, false, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNavButton.tsx",
      lineNumber: 30,
      columnNumber: 20
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNavButton.tsx",
    lineNumber: 21,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNavButton.tsx",
    lineNumber: 20,
    columnNumber: 10
  }, this);
}, "uORRuor8gDIiyCmi/w925c+/YhQ=", false, function() {
  return [useStyleConfig, useCloseDropDown];
})), "uORRuor8gDIiyCmi/w925c+/YhQ=", false, function() {
  return [useStyleConfig, useCloseDropDown];
});
_c2 = HeaderMobileNavButton;
export default HeaderMobileNavButton;
var _c, _c2;
$RefreshReg$(_c, "HeaderMobileNavButton$chakra");
$RefreshReg$(_c2, "HeaderMobileNavButton");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNavButton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0NVOzs7Ozs7Ozs7Ozs7Ozs7O0FBcENWLE9BQU9BLGVBQWU7QUFDdEIsU0FBU0MsS0FBS0MsUUFBUUMsc0JBQXNCO0FBQzVDLFNBQ0VDLFFBQ0FDLE1BQ0FDLHdCQUNLO0FBQ1AsU0FBU0MsVUFBVUMsY0FBYztBQUVqQyxPQUFPQyxxQkFBcUI7QUFNNUIsTUFBTUMsd0JBQXFCQyxHQUFHVCxPQUFNVSxLQUFBRCxHQUFDLE1BQU07QUFBQUEsS0FBQTtBQUN6QyxRQUFNLENBQUNFLFFBQVFDLFNBQVMsSUFBSVAsU0FBa0IsS0FBSztBQUNuRCxRQUFNUSxTQUFTWixlQUFlLHlCQUF5QjtBQUFBLElBQUVVO0FBQUFBLEVBQU8sQ0FBQztBQUNqRSxRQUFNRyxNQUFNUixPQUF1QixJQUFJO0FBRXZDRixtQkFBaUJRLFdBQVdFLEdBQUc7QUFFL0IsU0FDRSx1QkFBQyxPQUFJLEtBQ0gsaUNBQUMsYUFBVSxZQUFZLENBQUNILFFBQ3RCO0FBQUEsMkJBQUMsVUFDQyxpQkFBYyxRQUNkLGNBQVlBLFNBQVMscUJBQXFCLG1CQUMxQyxpQkFBZUEsU0FBUyxPQUFPLE1BQy9CLFlBQVcsUUFDWCxJQUFHLGlCQUNILFNBQVMsTUFBTTtBQUNiQyxnQkFBVSxDQUFDRCxNQUFNO0FBQUEsSUFDbkIsR0FDQSxPQUFPO0FBQUEsTUFBRSxHQUFHRTtBQUFBQSxNQUFRRSxTQUFTO0FBQUEsSUFBcUIsR0FFbEQsaUNBQUMsUUFBSyxNQUFNSixTQUFTLFVBQVUsb0JBQW9CLE1BQUssV0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErRCxLQVhqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxJQUNDQSxVQUFVLHVCQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0I7QUFBQSxPQWQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZUEsS0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlCQTtBQUVKLEdBQUM7QUFBQSxVQXpCZ0JWLGdCQUdmRyxnQkFBZ0I7QUFBQSxFQXNCakIsR0FBQztBQUFBLFVBekJlSCxnQkFHZkcsZ0JBQWdCO0FBQUE7QUFzQmZZLE1BM0JHUjtBQTZCTixlQUFlQTtBQUFzQixJQUFBRSxJQUFBTTtBQUFBQyxhQUFBUCxJQUFBO0FBQUFPLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJGb2N1c0xvY2siLCJCb3giLCJjaGFrcmEiLCJ1c2VTdHlsZUNvbmZpZyIsIkJ1dHRvbiIsIkljb24iLCJ1c2VDbG9zZURyb3BEb3duIiwidXNlU3RhdGUiLCJ1c2VSZWYiLCJIZWFkZXJNb2JpbGVOYXYiLCJIZWFkZXJNb2JpbGVOYXZCdXR0b24iLCJfcyIsIl9jIiwiaXNPcGVuIiwic2V0SXNPcGVuIiwic3R5bGVzIiwicmVmIiwicGFkZGluZyIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkhlYWRlck1vYmlsZU5hdkJ1dHRvbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEZvY3VzTG9jayBmcm9tIFwiQGNoYWtyYS11aS9mb2N1cy1sb2NrXCI7XG5pbXBvcnQgeyBCb3gsIGNoYWtyYSwgdXNlU3R5bGVDb25maWcgfSBmcm9tIFwiQGNoYWtyYS11aS9yZWFjdFwiO1xuaW1wb3J0IHtcbiAgQnV0dG9uLFxuICBJY29uLFxuICB1c2VDbG9zZURyb3BEb3duLFxufSBmcm9tIFwiQG55cGwvZGVzaWduLXN5c3RlbS1yZWFjdC1jb21wb25lbnRzXCI7XG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlUmVmIH0gZnJvbSBcInJlYWN0XCI7XG5cbmltcG9ydCBIZWFkZXJNb2JpbGVOYXYgZnJvbSBcIi4vSGVhZGVyTW9iaWxlTmF2XCI7XG5cbi8qKlxuICogVGhpcyBpcyB0aGUgYnV0dG9uIHRoYXQgd2lsbCByZW5kZXIgdGhlIG5hdmlnYXRpb25hbCBsaXN0IG9mIGxpbmtzXG4gKiB3aGVuIGl0IGlzIGNsaWNrZWQgYW5kIGtlZXAgZm9jdXMgdHJhcHBlZCB3aXRoaW4gdGhlIG1lbnUuXG4gKi9cbmNvbnN0IEhlYWRlck1vYmlsZU5hdkJ1dHRvbiA9IGNoYWtyYSgoKSA9PiB7XG4gIGNvbnN0IFtpc09wZW4sIHNldElzT3Blbl0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG4gIGNvbnN0IHN0eWxlcyA9IHVzZVN0eWxlQ29uZmlnKFwiSGVhZGVyTW9iaWxlTmF2QnV0dG9uXCIsIHsgaXNPcGVuIH0pO1xuICBjb25zdCByZWYgPSB1c2VSZWY8SFRNTERpdkVsZW1lbnQ+KG51bGwpO1xuXG4gIHVzZUNsb3NlRHJvcERvd24oc2V0SXNPcGVuLCByZWYpO1xuXG4gIHJldHVybiAoXG4gICAgPEJveCByZWY9e3JlZn0+XG4gICAgICA8Rm9jdXNMb2NrIGlzRGlzYWJsZWQ9eyFpc09wZW59PlxuICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgYXJpYS1oYXNwb3B1cD1cInRydWVcIlxuICAgICAgICAgIGFyaWEtbGFiZWw9e2lzT3BlbiA/IFwiQ2xvc2UgTmF2aWdhdGlvblwiIDogXCJPcGVuIE5hdmlnYXRpb25cIn1cbiAgICAgICAgICBhcmlhLWV4cGFuZGVkPXtpc09wZW4gPyB0cnVlIDogbnVsbH1cbiAgICAgICAgICBidXR0b25UeXBlPVwidGV4dFwiXG4gICAgICAgICAgaWQ9XCJtb2JpbGVOYXYtYnRuXCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICBzZXRJc09wZW4oIWlzT3Blbik7XG4gICAgICAgICAgfX1cbiAgICAgICAgICBfX2Nzcz17eyAuLi5zdHlsZXMsIHBhZGRpbmc6IFwiMXB4IDZweCAhaW1wb3J0YW50XCIgfX1cbiAgICAgICAgPlxuICAgICAgICAgIDxJY29uIG5hbWU9e2lzT3BlbiA/IFwiY2xvc2VcIiA6IFwidXRpbGl0eUhhbWJ1cmdlclwifSBzaXplPVwibGFyZ2VcIiAvPlxuICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAge2lzT3BlbiAmJiA8SGVhZGVyTW9iaWxlTmF2IC8+fVxuICAgICAgPC9Gb2N1c0xvY2s+XG4gICAgPC9Cb3g+XG4gICk7XG59KTtcblxuZXhwb3J0IGRlZmF1bHQgSGVhZGVyTW9iaWxlTmF2QnV0dG9uO1xuIl0sImZpbGUiOiIvVXNlcnMvY2hyaXNtdWxob2xsYW5kL1NpdGVzL3Rlc3RzL255cGwtaGVhZGVyLWFwcC9zcmMvY29tcG9uZW50cy9IZWFkZXIvY29tcG9uZW50cy9IZWFkZXJNb2JpbGVOYXZCdXR0b24udHN4In0=