import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/Header/components/HeaderMobileNav.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNav.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Box, chakra, Flex, Spacer, useMultiStyleConfig } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@chakra-ui_react.js?v=2c813617";
import { Link, Logo, List, SimpleGrid, Icon } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@nypl_design-system-react-components.js?v=f372bde6";
import { siteNavLinks, upperNavLinks } from "/components/Header/utils/headerUtils.ts";
const HeaderMobileNav = _s(chakra(_c = _s(() => {
  _s();
  const styles = useMultiStyleConfig("HeaderMobileNav", {});
  const listItems = siteNavLinks.map(({
    href,
    text
  }) => /* @__PURE__ */ jsxDEV(Link, { href, children: text }, text, false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNav.tsx",
    lineNumber: 16,
    columnNumber: 9
  }, this));
  return /* @__PURE__ */ jsxDEV(Box, { __css: styles, children: [
    /* @__PURE__ */ jsxDEV(Flex, { children: [
      /* @__PURE__ */ jsxDEV(Box, { children: /* @__PURE__ */ jsxDEV(Logo, { "aria-label": "NYPL Header Logo", decorative: false, name: "nyplTextWhite", size: "xsmall", title: "NYPL Header Logo", __css: styles.logo }, void 0, false, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNav.tsx",
        lineNumber: 22,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNav.tsx",
        lineNumber: 21,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Spacer, {}, void 0, false, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNav.tsx",
        lineNumber: 24,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("nav", { "aria-label": "Header mobile links", children: /* @__PURE__ */ jsxDEV(List, { id: "header-mobile-nav", listItems, noStyling: true, type: "ul", __css: {
        ...styles.sideNav,
        li: {
          marginBottom: "unset !important"
        }
      } }, void 0, false, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNav.tsx",
        lineNumber: 26,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNav.tsx",
        lineNumber: 25,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNav.tsx",
      lineNumber: 20,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(SimpleGrid, { gap: "0", "data-testid": "bottomLinks", __css: styles.bottomLinks, children: [
      /* @__PURE__ */ jsxDEV(Link, { href: upperNavLinks.libraryCard.href, borderTop: "1px solid rgb(54, 54, 54)", borderRight: "1px solid rgb(54, 54, 54)", gridColumn: "1 / span 1", children: [
        /* @__PURE__ */ jsxDEV(Icon, { align: "left", color: "ui.white", name: "decorativeLibraryCard", size: "large" }, void 0, false, {
          fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNav.tsx",
          lineNumber: 36,
          columnNumber: 11
        }, this),
        upperNavLinks.libraryCard.text
      ] }, void 0, true, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNav.tsx",
        lineNumber: 35,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { href: upperNavLinks.emailUpdates.href, borderTop: "1px solid rgb(54, 54, 54)", gridColumn: "2 / span 1", children: [
        /* @__PURE__ */ jsxDEV(Icon, { align: "left", color: "ui.white", name: "decorativeEnvelope", size: "large" }, void 0, false, {
          fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNav.tsx",
          lineNumber: 40,
          columnNumber: 11
        }, this),
        upperNavLinks.emailUpdates.text
      ] }, void 0, true, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNav.tsx",
        lineNumber: 39,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { href: upperNavLinks.shop.href, borderTop: "1px solid rgb(54, 54, 54)", gridColumn: "1 / span 2", children: [
        /* @__PURE__ */ jsxDEV(Icon, { align: "left", color: "ui.white", name: "decorativeShoppingBag", size: "large" }, void 0, false, {
          fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNav.tsx",
          lineNumber: 44,
          columnNumber: 11
        }, this),
        upperNavLinks.shop.text,
        " NYPL"
      ] }, void 0, true, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNav.tsx",
        lineNumber: 43,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { href: upperNavLinks.donate.href, gridColumn: "1 / span 2", children: upperNavLinks.donate.text.toUpperCase() }, void 0, false, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNav.tsx",
        lineNumber: 47,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNav.tsx",
      lineNumber: 34,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNav.tsx",
    lineNumber: 19,
    columnNumber: 10
  }, this);
}, "4weJZXnSi/kojZCmc0wy6twR2LQ=", false, function() {
  return [useMultiStyleConfig];
})), "4weJZXnSi/kojZCmc0wy6twR2LQ=", false, function() {
  return [useMultiStyleConfig];
});
_c2 = HeaderMobileNav;
export default HeaderMobileNav;
var _c, _c2;
$RefreshReg$(_c, "HeaderMobileNav$chakra");
$RefreshReg$(_c2, "HeaderMobileNav");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderMobileNav.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JJOzs7Ozs7Ozs7Ozs7Ozs7O0FBeEJKLFNBQ0VBLEtBQ0FDLFFBQ0FDLE1BQ0FDLFFBQ0FDLDJCQUNLO0FBQ1AsU0FDRUMsTUFDQUMsTUFDQUMsTUFDQUMsWUFDQUMsWUFDSztBQUVQLFNBQVNDLGNBQWNDLHFCQUFxQjtBQU01QyxNQUFNQyxrQkFBZUMsR0FBR1osT0FBTWEsS0FBQUQsR0FBQyxNQUFNO0FBQUFBLEtBQUE7QUFDbkMsUUFBTUUsU0FBU1gsb0JBQW9CLG1CQUFtQixDQUFDLENBQUM7QUFDeEQsUUFBTVksWUFBWU4sYUFBYU8sSUFBSSxDQUFDO0FBQUEsSUFBRUM7QUFBQUEsSUFBTUM7QUFBQUEsRUFBSyxNQUMvQyx1QkFBQyxRQUFLLE1BQ0hBLGtCQURvQkEsTUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBLENBQ0Q7QUFFRCxTQUNFLHVCQUFDLE9BQUksT0FBT0osUUFDVjtBQUFBLDJCQUFDLFFBQ0M7QUFBQSw2QkFBQyxPQUNDLGlDQUFDLFFBQ0MsY0FBVyxvQkFDWCxZQUFZLE9BQ1osTUFBSyxpQkFDTCxNQUFLLFVBQ0wsT0FBTSxvQkFDTixPQUFPQSxPQUFPSyxRQU5oQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTXFCLEtBUHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BQ0EsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQU87QUFBQSxNQUNQLHVCQUFDLFNBQUksY0FBVyx1QkFDZCxpQ0FBQyxRQUNDLElBQUcscUJBQ0gsV0FDQSxXQUFTLE1BQ1QsTUFBSyxNQUNMLE9BQU87QUFBQSxRQUNMLEdBQUdMLE9BQU9NO0FBQUFBLFFBQ1ZDLElBQUk7QUFBQSxVQUFFQyxjQUFjO0FBQUEsUUFBbUI7QUFBQSxNQUN6QyxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRSSxLQVROO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLFNBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3QkE7QUFBQSxJQUNBLHVCQUFDLGNBQVcsS0FBSSxLQUFJLGVBQVksZUFBYyxPQUFPUixPQUFPUyxhQUMxRDtBQUFBLDZCQUFDLFFBQ0MsTUFBTWIsY0FBY2MsWUFBWVAsTUFDaEMsV0FBVSw2QkFDVixhQUFZLDZCQUNaLFlBQVcsY0FFWDtBQUFBLCtCQUFDLFFBQ0MsT0FBTSxRQUNOLE9BQU0sWUFDTixNQUFLLHlCQUNMLE1BQUssV0FKUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSWM7QUFBQSxRQUViUCxjQUFjYyxZQUFZTjtBQUFBQSxXQVo3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxNQUNBLHVCQUFDLFFBQ0MsTUFBTVIsY0FBY2UsYUFBYVIsTUFDakMsV0FBVSw2QkFDVixZQUFXLGNBRVg7QUFBQSwrQkFBQyxRQUNDLE9BQU0sUUFDTixPQUFNLFlBQ04sTUFBSyxzQkFDTCxNQUFLLFdBSlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUljO0FBQUEsUUFFYlAsY0FBY2UsYUFBYVA7QUFBQUEsV0FYOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFDQSx1QkFBQyxRQUNDLE1BQU1SLGNBQWNnQixLQUFLVCxNQUN6QixXQUFVLDZCQUNWLFlBQVcsY0FFWDtBQUFBLCtCQUFDLFFBQ0MsT0FBTSxRQUNOLE9BQU0sWUFDTixNQUFLLHlCQUNMLE1BQUssV0FKUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSWM7QUFBQSxRQUViUCxjQUFjZ0IsS0FBS1I7QUFBQUEsUUFBSztBQUFBLFdBWDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLE1BQ0EsdUJBQUMsUUFBSyxNQUFNUixjQUFjaUIsT0FBT1YsTUFBTSxZQUFXLGNBQy9DUCx3QkFBY2lCLE9BQU9ULEtBQUtVLFlBQVksS0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0EzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRDQTtBQUFBLE9BdEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1RUE7QUFFSixHQUFDO0FBQUEsVUFqRmdCekIsbUJBQW1CO0FBQUEsRUFpRm5DLEdBQUM7QUFBQSxVQWpGZUEsbUJBQW1CO0FBQUE7QUFpRmpDMEIsTUFsRkdsQjtBQW9GTixlQUFlQTtBQUFnQixJQUFBRSxJQUFBZ0I7QUFBQUMsYUFBQWpCLElBQUE7QUFBQWlCLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJCb3giLCJjaGFrcmEiLCJGbGV4IiwiU3BhY2VyIiwidXNlTXVsdGlTdHlsZUNvbmZpZyIsIkxpbmsiLCJMb2dvIiwiTGlzdCIsIlNpbXBsZUdyaWQiLCJJY29uIiwic2l0ZU5hdkxpbmtzIiwidXBwZXJOYXZMaW5rcyIsIkhlYWRlck1vYmlsZU5hdiIsIl9zIiwiX2MiLCJzdHlsZXMiLCJsaXN0SXRlbXMiLCJtYXAiLCJocmVmIiwidGV4dCIsImxvZ28iLCJzaWRlTmF2IiwibGkiLCJtYXJnaW5Cb3R0b20iLCJib3R0b21MaW5rcyIsImxpYnJhcnlDYXJkIiwiZW1haWxVcGRhdGVzIiwic2hvcCIsImRvbmF0ZSIsInRvVXBwZXJDYXNlIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiSGVhZGVyTW9iaWxlTmF2LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBCb3gsXG4gIGNoYWtyYSxcbiAgRmxleCxcbiAgU3BhY2VyLFxuICB1c2VNdWx0aVN0eWxlQ29uZmlnLFxufSBmcm9tIFwiQGNoYWtyYS11aS9yZWFjdFwiO1xuaW1wb3J0IHtcbiAgTGluayxcbiAgTG9nbyxcbiAgTGlzdCxcbiAgU2ltcGxlR3JpZCxcbiAgSWNvbixcbn0gZnJvbSBcIkBueXBsL2Rlc2lnbi1zeXN0ZW0tcmVhY3QtY29tcG9uZW50c1wiO1xuXG5pbXBvcnQgeyBzaXRlTmF2TGlua3MsIHVwcGVyTmF2TGlua3MgfSBmcm9tIFwiLi4vdXRpbHMvaGVhZGVyVXRpbHNcIjtcblxuLyoqXG4gKiBUaGlzIGNvbXBvbmVudCByZW5kZXJzIHRoZSBuYXZpZ2F0aW9uYWwgbGlzdCBvZiBsaW5rcyB1c2VkIHRvIG5hdmlnYXRlXG4gKiBOWVBMLm9yZyBmb3IgbW9iaWxlIGRldmljZXMuXG4gKi9cbmNvbnN0IEhlYWRlck1vYmlsZU5hdiA9IGNoYWtyYSgoKSA9PiB7XG4gIGNvbnN0IHN0eWxlcyA9IHVzZU11bHRpU3R5bGVDb25maWcoXCJIZWFkZXJNb2JpbGVOYXZcIiwge30pO1xuICBjb25zdCBsaXN0SXRlbXMgPSBzaXRlTmF2TGlua3MubWFwKCh7IGhyZWYsIHRleHQgfSkgPT4gKFxuICAgIDxMaW5rIGhyZWY9e2hyZWZ9IGtleT17dGV4dH0+XG4gICAgICB7dGV4dH1cbiAgICA8L0xpbms+XG4gICkpO1xuXG4gIHJldHVybiAoXG4gICAgPEJveCBfX2Nzcz17c3R5bGVzfT5cbiAgICAgIDxGbGV4PlxuICAgICAgICA8Qm94PlxuICAgICAgICAgIDxMb2dvXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwiTllQTCBIZWFkZXIgTG9nb1wiXG4gICAgICAgICAgICBkZWNvcmF0aXZlPXtmYWxzZX1cbiAgICAgICAgICAgIG5hbWU9XCJueXBsVGV4dFdoaXRlXCJcbiAgICAgICAgICAgIHNpemU9XCJ4c21hbGxcIlxuICAgICAgICAgICAgdGl0bGU9XCJOWVBMIEhlYWRlciBMb2dvXCJcbiAgICAgICAgICAgIF9fY3NzPXtzdHlsZXMubG9nb31cbiAgICAgICAgICAvPlxuICAgICAgICA8L0JveD5cbiAgICAgICAgPFNwYWNlciAvPlxuICAgICAgICA8bmF2IGFyaWEtbGFiZWw9XCJIZWFkZXIgbW9iaWxlIGxpbmtzXCI+XG4gICAgICAgICAgPExpc3RcbiAgICAgICAgICAgIGlkPVwiaGVhZGVyLW1vYmlsZS1uYXZcIlxuICAgICAgICAgICAgbGlzdEl0ZW1zPXtsaXN0SXRlbXN9XG4gICAgICAgICAgICBub1N0eWxpbmdcbiAgICAgICAgICAgIHR5cGU9XCJ1bFwiXG4gICAgICAgICAgICBfX2Nzcz17e1xuICAgICAgICAgICAgICAuLi5zdHlsZXMuc2lkZU5hdixcbiAgICAgICAgICAgICAgbGk6IHsgbWFyZ2luQm90dG9tOiBcInVuc2V0ICFpbXBvcnRhbnRcIiB9LFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L25hdj5cbiAgICAgIDwvRmxleD5cbiAgICAgIDxTaW1wbGVHcmlkIGdhcD1cIjBcIiBkYXRhLXRlc3RpZD1cImJvdHRvbUxpbmtzXCIgX19jc3M9e3N0eWxlcy5ib3R0b21MaW5rc30+XG4gICAgICAgIDxMaW5rXG4gICAgICAgICAgaHJlZj17dXBwZXJOYXZMaW5rcy5saWJyYXJ5Q2FyZC5ocmVmfVxuICAgICAgICAgIGJvcmRlclRvcD1cIjFweCBzb2xpZCByZ2IoNTQsIDU0LCA1NClcIlxuICAgICAgICAgIGJvcmRlclJpZ2h0PVwiMXB4IHNvbGlkIHJnYig1NCwgNTQsIDU0KVwiXG4gICAgICAgICAgZ3JpZENvbHVtbj1cIjEgLyBzcGFuIDFcIlxuICAgICAgICA+XG4gICAgICAgICAgPEljb25cbiAgICAgICAgICAgIGFsaWduPVwibGVmdFwiXG4gICAgICAgICAgICBjb2xvcj1cInVpLndoaXRlXCJcbiAgICAgICAgICAgIG5hbWU9XCJkZWNvcmF0aXZlTGlicmFyeUNhcmRcIlxuICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcbiAgICAgICAgICAvPlxuICAgICAgICAgIHt1cHBlck5hdkxpbmtzLmxpYnJhcnlDYXJkLnRleHR9XG4gICAgICAgIDwvTGluaz5cbiAgICAgICAgPExpbmtcbiAgICAgICAgICBocmVmPXt1cHBlck5hdkxpbmtzLmVtYWlsVXBkYXRlcy5ocmVmfVxuICAgICAgICAgIGJvcmRlclRvcD1cIjFweCBzb2xpZCByZ2IoNTQsIDU0LCA1NClcIlxuICAgICAgICAgIGdyaWRDb2x1bW49XCIyIC8gc3BhbiAxXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxJY29uXG4gICAgICAgICAgICBhbGlnbj1cImxlZnRcIlxuICAgICAgICAgICAgY29sb3I9XCJ1aS53aGl0ZVwiXG4gICAgICAgICAgICBuYW1lPVwiZGVjb3JhdGl2ZUVudmVsb3BlXCJcbiAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXG4gICAgICAgICAgLz5cbiAgICAgICAgICB7dXBwZXJOYXZMaW5rcy5lbWFpbFVwZGF0ZXMudGV4dH1cbiAgICAgICAgPC9MaW5rPlxuICAgICAgICA8TGlua1xuICAgICAgICAgIGhyZWY9e3VwcGVyTmF2TGlua3Muc2hvcC5ocmVmfVxuICAgICAgICAgIGJvcmRlclRvcD1cIjFweCBzb2xpZCByZ2IoNTQsIDU0LCA1NClcIlxuICAgICAgICAgIGdyaWRDb2x1bW49XCIxIC8gc3BhbiAyXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxJY29uXG4gICAgICAgICAgICBhbGlnbj1cImxlZnRcIlxuICAgICAgICAgICAgY29sb3I9XCJ1aS53aGl0ZVwiXG4gICAgICAgICAgICBuYW1lPVwiZGVjb3JhdGl2ZVNob3BwaW5nQmFnXCJcbiAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXG4gICAgICAgICAgLz5cbiAgICAgICAgICB7dXBwZXJOYXZMaW5rcy5zaG9wLnRleHR9IE5ZUExcbiAgICAgICAgPC9MaW5rPlxuICAgICAgICA8TGluayBocmVmPXt1cHBlck5hdkxpbmtzLmRvbmF0ZS5ocmVmfSBncmlkQ29sdW1uPVwiMSAvIHNwYW4gMlwiPlxuICAgICAgICAgIHt1cHBlck5hdkxpbmtzLmRvbmF0ZS50ZXh0LnRvVXBwZXJDYXNlKCl9XG4gICAgICAgIDwvTGluaz5cbiAgICAgIDwvU2ltcGxlR3JpZD5cbiAgICA8L0JveD5cbiAgKTtcbn0pO1xuXG5leHBvcnQgZGVmYXVsdCBIZWFkZXJNb2JpbGVOYXY7XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaHJpc211bGhvbGxhbmQvU2l0ZXMvdGVzdHMvbnlwbC1oZWFkZXItYXBwL3NyYy9jb21wb25lbnRzL0hlYWRlci9jb21wb25lbnRzL0hlYWRlck1vYmlsZU5hdi50c3gifQ==