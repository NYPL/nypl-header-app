import { headerBlack, headerFocus, headerRedDonate } from "/theme/header.ts";
const mobileLinkFocus = {
  ...headerFocus,
  outlineColor: "var(--nypl-colors-ui-white) !important"
};
const HeaderMobileNav = {
  parts: ["bottomLinks", "sideNav"],
  baseStyle: () => ({
    backgroundColor: headerBlack,
    color: "ui.white",
    left: "0px",
    minHeight: "540px",
    position: "absolute",
    whiteSpace: "initial",
    width: "100%",
    zIndex: "99999",
    logo: {
      marginTop: "25px",
      marginLeft: "15px"
    },
    sideNav: {
      lineHeight: "1.7",
      marginBottom: "0",
      padding: "15px",
      textAlign: "right",
      "li:not(:first-child)": {
        marginTop: "10px"
      },
      a: {
        color: "ui.white",
        fontSize: "18px",
        fontWeight: "medium",
        textDecoration: "none",
        _hover: {
          color: "ui.white",
          textDecoration: "none"
        },
        _focus: mobileLinkFocus,
        _visited: {
          color: "ui.white"
        }
      }
    },
    bottomLinks: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      a: {
        alignItems: "center",
        color: "ui.white",
        display: "flex",
        fontWeight: "medium",
        justifyContent: "center",
        textDecoration: "none",
        paddingY: "27px",
        paddingLeft: "15px",
        svg: {
          marginRight: "xs"
        },
        _hover: {
          color: "ui.white",
          backgroundColor: "ui.black",
          textDecoration: "none"
        },
        _focus: mobileLinkFocus,
        _visited: {
          color: "ui.white"
        },
        _last: {
          backgroundColor: headerRedDonate,
          _hover: {
            backgroundColor: headerRedDonate
          },
          _dark: {
            bgColor: "brand.secondary",
            color: "ui.white",
            _hover: {
              bgColor: "brand.primary"
            }
          }
        }
      }
    }
  })
};
export default HeaderMobileNav;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlck1vYmlsZU5hdi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBoZWFkZXJCbGFjaywgaGVhZGVyRm9jdXMsIGhlYWRlclJlZERvbmF0ZSB9IGZyb20gXCIuL2hlYWRlclwiO1xuXG5jb25zdCBtb2JpbGVMaW5rRm9jdXMgPSB7XG4gIC4uLmhlYWRlckZvY3VzLFxuICBvdXRsaW5lQ29sb3I6IFwidmFyKC0tbnlwbC1jb2xvcnMtdWktd2hpdGUpICFpbXBvcnRhbnRcIixcbn07XG5cbmNvbnN0IEhlYWRlck1vYmlsZU5hdiA9IHtcbiAgcGFydHM6IFtcImJvdHRvbUxpbmtzXCIsIFwic2lkZU5hdlwiXSxcbiAgYmFzZVN0eWxlOiAoKSA9PiAoe1xuICAgIGJhY2tncm91bmRDb2xvcjogaGVhZGVyQmxhY2ssXG4gICAgY29sb3I6IFwidWkud2hpdGVcIixcbiAgICBsZWZ0OiBcIjBweFwiLFxuICAgIG1pbkhlaWdodDogXCI1NDBweFwiLFxuICAgIHBvc2l0aW9uOiBcImFic29sdXRlXCIsXG4gICAgd2hpdGVTcGFjZTogXCJpbml0aWFsXCIsXG4gICAgd2lkdGg6IFwiMTAwJVwiLFxuICAgIHpJbmRleDogXCI5OTk5OVwiLFxuICAgIGxvZ286IHtcbiAgICAgIG1hcmdpblRvcDogXCIyNXB4XCIsXG4gICAgICBtYXJnaW5MZWZ0OiBcIjE1cHhcIixcbiAgICB9LFxuICAgIHNpZGVOYXY6IHtcbiAgICAgIGxpbmVIZWlnaHQ6IFwiMS43XCIsXG4gICAgICBtYXJnaW5Cb3R0b206IFwiMFwiLFxuICAgICAgcGFkZGluZzogXCIxNXB4XCIsXG4gICAgICB0ZXh0QWxpZ246IFwicmlnaHRcIixcbiAgICAgIFwibGk6bm90KDpmaXJzdC1jaGlsZClcIjoge1xuICAgICAgICBtYXJnaW5Ub3A6IFwiMTBweFwiLFxuICAgICAgfSxcbiAgICAgIGE6IHtcbiAgICAgICAgY29sb3I6IFwidWkud2hpdGVcIixcbiAgICAgICAgZm9udFNpemU6IFwiMThweFwiLFxuICAgICAgICBmb250V2VpZ2h0OiBcIm1lZGl1bVwiLFxuICAgICAgICB0ZXh0RGVjb3JhdGlvbjogXCJub25lXCIsXG4gICAgICAgIF9ob3Zlcjoge1xuICAgICAgICAgIGNvbG9yOiBcInVpLndoaXRlXCIsXG4gICAgICAgICAgdGV4dERlY29yYXRpb246IFwibm9uZVwiLFxuICAgICAgICB9LFxuICAgICAgICBfZm9jdXM6IG1vYmlsZUxpbmtGb2N1cyxcbiAgICAgICAgX3Zpc2l0ZWQ6IHtcbiAgICAgICAgICBjb2xvcjogXCJ1aS53aGl0ZVwiLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9LFxuICAgIGJvdHRvbUxpbmtzOiB7XG4gICAgICBkaXNwbGF5OiBcImdyaWRcIixcbiAgICAgIGdyaWRUZW1wbGF0ZUNvbHVtbnM6IFwiMWZyIDFmclwiLFxuICAgICAgYToge1xuICAgICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgICAgICBjb2xvcjogXCJ1aS53aGl0ZVwiLFxuICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgZm9udFdlaWdodDogXCJtZWRpdW1cIixcbiAgICAgICAganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIsXG4gICAgICAgIHRleHREZWNvcmF0aW9uOiBcIm5vbmVcIixcbiAgICAgICAgcGFkZGluZ1k6IFwiMjdweFwiLFxuICAgICAgICBwYWRkaW5nTGVmdDogXCIxNXB4XCIsXG4gICAgICAgIHN2Zzoge1xuICAgICAgICAgIG1hcmdpblJpZ2h0OiBcInhzXCIsXG4gICAgICAgIH0sXG4gICAgICAgIF9ob3Zlcjoge1xuICAgICAgICAgIGNvbG9yOiBcInVpLndoaXRlXCIsXG4gICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBcInVpLmJsYWNrXCIsXG4gICAgICAgICAgdGV4dERlY29yYXRpb246IFwibm9uZVwiLFxuICAgICAgICB9LFxuICAgICAgICBfZm9jdXM6IG1vYmlsZUxpbmtGb2N1cyxcbiAgICAgICAgX3Zpc2l0ZWQ6IHtcbiAgICAgICAgICBjb2xvcjogXCJ1aS53aGl0ZVwiLFxuICAgICAgICB9LFxuICAgICAgICBfbGFzdDoge1xuICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogaGVhZGVyUmVkRG9uYXRlLFxuICAgICAgICAgIF9ob3Zlcjoge1xuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBoZWFkZXJSZWREb25hdGUsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBfZGFyazoge1xuICAgICAgICAgICAgYmdDb2xvcjogXCJicmFuZC5zZWNvbmRhcnlcIixcbiAgICAgICAgICAgIGNvbG9yOiBcInVpLndoaXRlXCIsXG4gICAgICAgICAgICBfaG92ZXI6IHtcbiAgICAgICAgICAgICAgYmdDb2xvcjogXCJicmFuZC5wcmltYXJ5XCIsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0sXG4gIH0pLFxufTtcblxuZXhwb3J0IGRlZmF1bHQgSGVhZGVyTW9iaWxlTmF2O1xuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLGFBQWEsYUFBYSx1QkFBdUI7QUFFMUQsTUFBTSxrQkFBa0I7QUFBQSxFQUN0QixHQUFHO0FBQUEsRUFDSCxjQUFjO0FBQ2hCO0FBRUEsTUFBTSxrQkFBa0I7QUFBQSxFQUN0QixPQUFPLENBQUMsZUFBZSxTQUFTO0FBQUEsRUFDaEMsV0FBVyxPQUFPO0FBQUEsSUFDaEIsaUJBQWlCO0FBQUEsSUFDakIsT0FBTztBQUFBLElBQ1AsTUFBTTtBQUFBLElBQ04sV0FBVztBQUFBLElBQ1gsVUFBVTtBQUFBLElBQ1YsWUFBWTtBQUFBLElBQ1osT0FBTztBQUFBLElBQ1AsUUFBUTtBQUFBLElBQ1IsTUFBTTtBQUFBLE1BQ0osV0FBVztBQUFBLE1BQ1gsWUFBWTtBQUFBLElBQ2Q7QUFBQSxJQUNBLFNBQVM7QUFBQSxNQUNQLFlBQVk7QUFBQSxNQUNaLGNBQWM7QUFBQSxNQUNkLFNBQVM7QUFBQSxNQUNULFdBQVc7QUFBQSxNQUNYLHdCQUF3QjtBQUFBLFFBQ3RCLFdBQVc7QUFBQSxNQUNiO0FBQUEsTUFDQSxHQUFHO0FBQUEsUUFDRCxPQUFPO0FBQUEsUUFDUCxVQUFVO0FBQUEsUUFDVixZQUFZO0FBQUEsUUFDWixnQkFBZ0I7QUFBQSxRQUNoQixRQUFRO0FBQUEsVUFDTixPQUFPO0FBQUEsVUFDUCxnQkFBZ0I7QUFBQSxRQUNsQjtBQUFBLFFBQ0EsUUFBUTtBQUFBLFFBQ1IsVUFBVTtBQUFBLFVBQ1IsT0FBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLElBQ0EsYUFBYTtBQUFBLE1BQ1gsU0FBUztBQUFBLE1BQ1QscUJBQXFCO0FBQUEsTUFDckIsR0FBRztBQUFBLFFBQ0QsWUFBWTtBQUFBLFFBQ1osT0FBTztBQUFBLFFBQ1AsU0FBUztBQUFBLFFBQ1QsWUFBWTtBQUFBLFFBQ1osZ0JBQWdCO0FBQUEsUUFDaEIsZ0JBQWdCO0FBQUEsUUFDaEIsVUFBVTtBQUFBLFFBQ1YsYUFBYTtBQUFBLFFBQ2IsS0FBSztBQUFBLFVBQ0gsYUFBYTtBQUFBLFFBQ2Y7QUFBQSxRQUNBLFFBQVE7QUFBQSxVQUNOLE9BQU87QUFBQSxVQUNQLGlCQUFpQjtBQUFBLFVBQ2pCLGdCQUFnQjtBQUFBLFFBQ2xCO0FBQUEsUUFDQSxRQUFRO0FBQUEsUUFDUixVQUFVO0FBQUEsVUFDUixPQUFPO0FBQUEsUUFDVDtBQUFBLFFBQ0EsT0FBTztBQUFBLFVBQ0wsaUJBQWlCO0FBQUEsVUFDakIsUUFBUTtBQUFBLFlBQ04saUJBQWlCO0FBQUEsVUFDbkI7QUFBQSxVQUNBLE9BQU87QUFBQSxZQUNMLFNBQVM7QUFBQSxZQUNULE9BQU87QUFBQSxZQUNQLFFBQVE7QUFBQSxjQUNOLFNBQVM7QUFBQSxZQUNYO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLGVBQWU7IiwibmFtZXMiOltdfQ==