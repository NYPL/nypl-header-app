import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/Header/context/headerContext.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/context/headerContext.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/react.js?v=f7bb76b7"; const React = __vite__cjsImport3_react;
export const HeaderContext = React.createContext(null);
export const HeaderProvider = ({
  children,
  isProduction = true,
  patronName = ""
}) => {
  return /* @__PURE__ */ jsxDEV(HeaderContext.Provider, { value: {
    isProduction,
    patronName
  }, children }, void 0, false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/context/headerContext.tsx",
    lineNumber: 16,
    columnNumber: 10
  }, this);
};
_c = HeaderProvider;
var _c;
$RefreshReg$(_c, "HeaderProvider");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/context/headerContext.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JJO0FBaEJKLE9BQU8sb0JBQWdCO0FBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUt2QixhQUFNQSxnQkFBZ0JDLE1BQU1DLGNBQWMsSUFBSTtBQUs5QyxhQUFNQyxpQkFBaUJBLENBQUM7QUFBQSxFQUM3QkM7QUFBQUEsRUFDQUMsZUFBZTtBQUFBLEVBQ2ZDLGFBQWE7QUFDZixNQUFNO0FBQ0osU0FDRSx1QkFBQyxjQUFjLFVBQWQsRUFBdUIsT0FBTztBQUFBLElBQUVEO0FBQUFBLElBQWNDO0FBQUFBLEVBQVcsR0FDdkRGLFlBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRUo7QUFBRUcsS0FWV0o7QUFBYyxJQUFBSTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiSGVhZGVyQ29udGV4dCIsIlJlYWN0IiwiY3JlYXRlQ29udGV4dCIsIkhlYWRlclByb3ZpZGVyIiwiY2hpbGRyZW4iLCJpc1Byb2R1Y3Rpb24iLCJwYXRyb25OYW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJoZWFkZXJDb250ZXh0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuLyoqXG4gKiBDb250ZXh0IHVzZWQgZm9yIHBhdHJvbiBhbmQgcHJvZHVjdGlvbiBzdGF0dXMgZGF0YS5cbiAqL1xuZXhwb3J0IGNvbnN0IEhlYWRlckNvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KG51bGwpO1xuXG4vKipcbiAqIENvbnRleHQgUHJvdmlkZXIgdXNlZCBvbmx5IGluIHRoZSBIZWFkZXIgY29tcG9uZW50LlxuICovXG5leHBvcnQgY29uc3QgSGVhZGVyUHJvdmlkZXIgPSAoe1xuICBjaGlsZHJlbixcbiAgaXNQcm9kdWN0aW9uID0gdHJ1ZSxcbiAgcGF0cm9uTmFtZSA9IFwiXCIsXG59KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPEhlYWRlckNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3sgaXNQcm9kdWN0aW9uLCBwYXRyb25OYW1lIH19PlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvSGVhZGVyQ29udGV4dC5Qcm92aWRlcj5cbiAgKTtcbn07XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaHJpc211bGhvbGxhbmQvU2l0ZXMvdGVzdHMvbnlwbC1oZWFkZXItYXBwL3NyYy9jb21wb25lbnRzL0hlYWRlci9jb250ZXh0L2hlYWRlckNvbnRleHQudHN4In0=