import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/Header/Header.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/Header.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { chakra, Box, HStack, useColorModeValue, useMultiStyleConfig, Spacer, VStack } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@chakra-ui_react.js?v=2c813617";
import { useNYPLBreakpoints, SkipNavigation, Link, Logo, HorizontalRule } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@nypl_design-system-react-components.js?v=f372bde6";
import { useMediaQuery } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@chakra-ui_react.js?v=2c813617";
import __vite__cjsImport6_react from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/react.js?v=f7bb76b7"; const useEffect = __vite__cjsImport6_react["useEffect"];
import HeaderLowerNav from "/components/Header/components/HeaderLowerNav.tsx";
import HeaderMobileIconNav from "/components/Header/components/HeaderMobileIconNav.tsx";
import HeaderSitewideAlerts from "/components/Header/components/HeaderSitewideAlerts.tsx";
import HeaderUpperNav from "/components/Header/components/HeaderUpperNav.tsx";
import { HeaderProvider } from "/components/Header/context/headerContext.tsx";
import EncoreCatalogLogOutTimer from "/components/Header/utils/encoreCatalogLogOutTimer.ts";
import { headerBreakpoints } from "/theme/foundation/breakpoints.ts";
import { getEnvVar } from "/utils.ts";
export const Header = _s(chakra(_c = _s(({
  fetchSitewideAlerts = true,
  isProduction = true
}) => {
  _s();
  const envPrefix = getEnvVar("VITE_APP_ENV") === "qa" ? "qa-" : "";
  const {
    isLargerThanLarge
  } = useNYPLBreakpoints();
  const [isLargerThanMobile] = useMediaQuery([`(min-width: ${headerBreakpoints.mh})`]);
  const styles = useMultiStyleConfig("Header", {});
  const encoreCatalogLogOutTimer = new EncoreCatalogLogOutTimer(Date.now(), false);
  useEffect(() => {
    encoreCatalogLogOutTimer.setEncoreLoggedInTimer(window.location.host);
  });
  useEffect(() => {
    const interval = setInterval(() => {
      encoreCatalogLogOutTimer.removeLoggedInCookie();
    }, 3e3);
    return () => clearInterval(interval);
  });
  return /* @__PURE__ */ jsxDEV(HeaderProvider, { isProduction, children: /* @__PURE__ */ jsxDEV(Box, { __css: {
    ...styles,
    // For Vega override, this is the browser's default.
    "& > nav li": {
      marginBottom: "0 !important"
    },
    "& svg": {
      verticalAlign: "baseline !important"
    },
    "& fieldset": {
      marginBottom: "0px !important"
    },
    "& input": {
      marginBottom: "0px !important"
    }
  }, children: [
    /* @__PURE__ */ jsxDEV(SkipNavigation, {}, void 0, false, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/Header.tsx",
      lineNumber: 79,
      columnNumber: 11
    }, this),
    fetchSitewideAlerts ? /* @__PURE__ */ jsxDEV(HeaderSitewideAlerts, {}, void 0, false, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/Header.tsx",
      lineNumber: 80,
      columnNumber: 34
    }, this) : null,
    /* @__PURE__ */ jsxDEV("header", { children: [
      /* @__PURE__ */ jsxDEV(HStack, { __css: styles.container, children: [
        /* @__PURE__ */ jsxDEV(Link, { "aria-label": "The New York Public Library", href: `//${envPrefix}www.nypl.org`, __css: styles.logo, children: /* @__PURE__ */ jsxDEV(Logo, { "aria-label": "NYPL Header Logo", name: isLargerThanLarge ? useColorModeValue("nyplFullBlack", "nyplFullWhite") : useColorModeValue("nyplLionBlack", "nyplLionWhite"), size: isLargerThanMobile ? "large" : "small", title: "NYPL Header Logo" }, void 0, false, {
          fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/Header.tsx",
          lineNumber: 84,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/Header.tsx",
          lineNumber: 83,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Spacer, {}, void 0, false, {
          fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/Header.tsx",
          lineNumber: 86,
          columnNumber: 15
        }, this),
        isLargerThanMobile ? /* @__PURE__ */ jsxDEV(VStack, { alignItems: "end", __css: styles.navContainer, children: [
          /* @__PURE__ */ jsxDEV(HeaderUpperNav, {}, void 0, false, {
            fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/Header.tsx",
            lineNumber: 88,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(HeaderLowerNav, {}, void 0, false, {
            fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/Header.tsx",
            lineNumber: 89,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/Header.tsx",
          lineNumber: 87,
          columnNumber: 37
        }, this) : /* @__PURE__ */ jsxDEV(HeaderMobileIconNav, { envPrefix }, void 0, false, {
          fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/Header.tsx",
          lineNumber: 90,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/Header.tsx",
        lineNumber: 82,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(HorizontalRule, { __css: styles.horizontalRule }, void 0, false, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/Header.tsx",
        lineNumber: 92,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/Header.tsx",
      lineNumber: 81,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/Header.tsx",
    lineNumber: 63,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/Header.tsx",
    lineNumber: 62,
    columnNumber: 10
  }, this);
}, "eqcpwmpuLQADvoe8n66lmX8hNBk=", false, function() {
  return [useNYPLBreakpoints, useMediaQuery, useMultiStyleConfig, useColorModeValue, useColorModeValue];
})), "eqcpwmpuLQADvoe8n66lmX8hNBk=", false, function() {
  return [useNYPLBreakpoints, useMediaQuery, useMultiStyleConfig, useColorModeValue, useColorModeValue];
});
_c2 = Header;
export default Header;
var _c, _c2;
$RefreshReg$(_c, "Header$chakra");
$RefreshReg$(_c2, "Header");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/Header.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkZVOzs7Ozs7Ozs7Ozs7Ozs7O0FBN0ZWLFNBQ0VBLFFBQ0FDLEtBQ0FDLFFBQ0FDLG1CQUNBQyxxQkFDQUMsUUFDQUMsY0FDSztBQUNQLFNBQ0VDLG9CQUNBQyxnQkFDQUMsTUFDQUMsTUFDQUMsc0JBQ0s7QUFDUCxTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsaUJBQWlCO0FBRzFCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyx5QkFBeUI7QUFDaEMsT0FBT0MsMEJBQTBCO0FBQ2pDLE9BQU9DLG9CQUFvQjtBQUUzQixTQUFTQyxzQkFBc0I7QUFDL0IsT0FBT0MsOEJBQThCO0FBQ3JDLFNBQVNDLHlCQUF5QjtBQUNsQyxTQUFTQyxpQkFBaUI7QUFjbkIsYUFBTUMsU0FBTUMsR0FBR3ZCLE9BQU13QixLQUFBRCxHQUMxQixDQUFDO0FBQUEsRUFBRUUsc0JBQXNCO0FBQUEsRUFBTUMsZUFBZTtBQUFrQixNQUFNO0FBQUFILEtBQUE7QUFDcEUsUUFBTUksWUFBWU4sVUFBVSxjQUFjLE1BQU0sT0FBTyxRQUFRO0FBRS9ELFFBQU07QUFBQSxJQUFFTztBQUFBQSxFQUFrQixJQUFJckIsbUJBQW1CO0FBRWpELFFBQU0sQ0FBQ3NCLGtCQUFrQixJQUFJakIsY0FBYyxDQUN6QyxlQUFlUSxrQkFBa0JVLEVBQUUsR0FBRyxDQUN2QztBQUVELFFBQU1DLFNBQVMzQixvQkFBb0IsVUFBVSxDQUFDLENBQUM7QUFLL0MsUUFBTTRCLDJCQUEyQixJQUFJYix5QkFDbkNjLEtBQUtDLElBQUksR0FDVCxLQUNGO0FBSUFyQixZQUFVLE1BQU07QUFDZG1CLDZCQUF5QkcsdUJBQXVCQyxPQUFPQyxTQUFTQyxJQUFJO0FBQUEsRUFDdEUsQ0FBQztBQUlEekIsWUFBVSxNQUFNO0FBQ2QsVUFBTTBCLFdBQVdDLFlBQVksTUFBTTtBQUNqQ1IsK0JBQXlCUyxxQkFBcUI7QUFBQSxJQUNoRCxHQUFHLEdBQUk7QUFDUCxXQUFPLE1BQU1DLGNBQWNILFFBQVE7QUFBQSxFQUNyQyxDQUFDO0FBRUQsU0FDRSx1QkFBQyxrQkFBZSxjQUNkLGlDQUFDLE9BQ0MsT0FBTztBQUFBLElBQ0wsR0FBR1I7QUFBQUE7QUFBQUEsSUFFSCxjQUFjO0FBQUEsTUFBRVksY0FBYztBQUFBLElBQWU7QUFBQSxJQUM3QyxTQUFTO0FBQUEsTUFBRUMsZUFBZTtBQUFBLElBQXNCO0FBQUEsSUFDaEQsY0FBYztBQUFBLE1BQ1pELGNBQWM7QUFBQSxJQUNoQjtBQUFBLElBQ0EsV0FBVztBQUFBLE1BQ1RBLGNBQWM7QUFBQSxJQUNoQjtBQUFBLEVBQ0YsR0FFQTtBQUFBLDJCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZTtBQUFBLElBQ2RsQixzQkFBc0IsdUJBQUMsMEJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQixJQUFNO0FBQUEsSUFDbEQsdUJBQUMsWUFDQztBQUFBLDZCQUFDLFVBQU8sT0FBT00sT0FBT2MsV0FDcEI7QUFBQSwrQkFBQyxRQUNDLGNBQVcsK0JBQ1gsTUFBTSxLQUFLbEIsU0FBUyxnQkFDcEIsT0FBT0ksT0FBT2UsTUFFZCxpQ0FBQyxRQUNDLGNBQVcsb0JBQ1gsTUFDRWxCLG9CQUNJekIsa0JBQWtCLGlCQUFpQixlQUFlLElBQ2xEQSxrQkFBa0IsaUJBQWlCLGVBQWUsR0FFeEQsTUFBTTBCLHFCQUFxQixVQUFVLFNBQ3JDLE9BQU0sc0JBUlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVEwQixLQWI1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUNBLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFPO0FBQUEsUUFDTkEscUJBQ0MsdUJBQUMsVUFBTyxZQUFXLE9BQU0sT0FBT0UsT0FBT2dCLGNBQ3JDO0FBQUEsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZTtBQUFBLFVBQ2YsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZTtBQUFBLGFBRmpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQSxJQUVBLHVCQUFDLHVCQUFvQixhQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBDO0FBQUEsV0F4QjlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwQkE7QUFBQSxNQUNBLHVCQUFDLGtCQUFlLE9BQU9oQixPQUFPaUIsa0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkM7QUFBQSxTQTVCL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZCQTtBQUFBLE9BN0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4Q0EsS0EvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdEQTtBQUVKLEdBQUM7QUFBQSxVQWxGK0J6QyxvQkFFREssZUFJZFIscUJBc0RLRCxtQkFDQUEsaUJBQWlCO0FBQUEsRUFzQnpDLEdBQUM7QUFBQSxVQW5GaUNJLG9CQUVESyxlQUlkUixxQkFzREtELG1CQUNBQSxpQkFBaUI7QUFBQTtBQXNCdkM4QyxNQXZGVzNCO0FBeUZiLGVBQWVBO0FBQU8sSUFBQUUsSUFBQXlCO0FBQUFDLGFBQUExQixJQUFBO0FBQUEwQixhQUFBRCxLQUFBIiwibmFtZXMiOlsiY2hha3JhIiwiQm94IiwiSFN0YWNrIiwidXNlQ29sb3JNb2RlVmFsdWUiLCJ1c2VNdWx0aVN0eWxlQ29uZmlnIiwiU3BhY2VyIiwiVlN0YWNrIiwidXNlTllQTEJyZWFrcG9pbnRzIiwiU2tpcE5hdmlnYXRpb24iLCJMaW5rIiwiTG9nbyIsIkhvcml6b250YWxSdWxlIiwidXNlTWVkaWFRdWVyeSIsInVzZUVmZmVjdCIsIkhlYWRlckxvd2VyTmF2IiwiSGVhZGVyTW9iaWxlSWNvbk5hdiIsIkhlYWRlclNpdGV3aWRlQWxlcnRzIiwiSGVhZGVyVXBwZXJOYXYiLCJIZWFkZXJQcm92aWRlciIsIkVuY29yZUNhdGFsb2dMb2dPdXRUaW1lciIsImhlYWRlckJyZWFrcG9pbnRzIiwiZ2V0RW52VmFyIiwiSGVhZGVyIiwiX3MiLCJfYyIsImZldGNoU2l0ZXdpZGVBbGVydHMiLCJpc1Byb2R1Y3Rpb24iLCJlbnZQcmVmaXgiLCJpc0xhcmdlclRoYW5MYXJnZSIsImlzTGFyZ2VyVGhhbk1vYmlsZSIsIm1oIiwic3R5bGVzIiwiZW5jb3JlQ2F0YWxvZ0xvZ091dFRpbWVyIiwiRGF0ZSIsIm5vdyIsInNldEVuY29yZUxvZ2dlZEluVGltZXIiLCJ3aW5kb3ciLCJsb2NhdGlvbiIsImhvc3QiLCJpbnRlcnZhbCIsInNldEludGVydmFsIiwicmVtb3ZlTG9nZ2VkSW5Db29raWUiLCJjbGVhckludGVydmFsIiwibWFyZ2luQm90dG9tIiwidmVydGljYWxBbGlnbiIsImNvbnRhaW5lciIsImxvZ28iLCJuYXZDb250YWluZXIiLCJob3Jpem9udGFsUnVsZSIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkhlYWRlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgY2hha3JhLFxuICBCb3gsXG4gIEhTdGFjayxcbiAgdXNlQ29sb3JNb2RlVmFsdWUsXG4gIHVzZU11bHRpU3R5bGVDb25maWcsXG4gIFNwYWNlcixcbiAgVlN0YWNrLFxufSBmcm9tIFwiQGNoYWtyYS11aS9yZWFjdFwiO1xuaW1wb3J0IHtcbiAgdXNlTllQTEJyZWFrcG9pbnRzLFxuICBTa2lwTmF2aWdhdGlvbixcbiAgTGluayxcbiAgTG9nbyxcbiAgSG9yaXpvbnRhbFJ1bGUsXG59IGZyb20gXCJAbnlwbC9kZXNpZ24tc3lzdGVtLXJlYWN0LWNvbXBvbmVudHNcIjtcbmltcG9ydCB7IHVzZU1lZGlhUXVlcnkgfSBmcm9tIFwiQGNoYWtyYS11aS9yZWFjdFwiO1xuaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XG5cbi8qKiBJbnRlcm5hbCBIZWFkZXItb25seSBjb21wb25lbnRzICovXG5pbXBvcnQgSGVhZGVyTG93ZXJOYXYgZnJvbSBcIi4vY29tcG9uZW50cy9IZWFkZXJMb3dlck5hdlwiO1xuaW1wb3J0IEhlYWRlck1vYmlsZUljb25OYXYgZnJvbSBcIi4vY29tcG9uZW50cy9IZWFkZXJNb2JpbGVJY29uTmF2XCI7XG5pbXBvcnQgSGVhZGVyU2l0ZXdpZGVBbGVydHMgZnJvbSBcIi4vY29tcG9uZW50cy9IZWFkZXJTaXRld2lkZUFsZXJ0c1wiO1xuaW1wb3J0IEhlYWRlclVwcGVyTmF2IGZyb20gXCIuL2NvbXBvbmVudHMvSGVhZGVyVXBwZXJOYXZcIjtcbi8qKiBJbnRlcm5hbCBIZWFkZXItb25seSB1dGlscyAqL1xuaW1wb3J0IHsgSGVhZGVyUHJvdmlkZXIgfSBmcm9tIFwiLi9jb250ZXh0L2hlYWRlckNvbnRleHRcIjtcbmltcG9ydCBFbmNvcmVDYXRhbG9nTG9nT3V0VGltZXIgZnJvbSBcIi4vdXRpbHMvZW5jb3JlQ2F0YWxvZ0xvZ091dFRpbWVyXCI7XG5pbXBvcnQgeyBoZWFkZXJCcmVha3BvaW50cyB9IGZyb20gXCIuLi8uLi90aGVtZS9mb3VuZGF0aW9uL2JyZWFrcG9pbnRzXCI7XG5pbXBvcnQgeyBnZXRFbnZWYXIgfSBmcm9tIFwiLi4vLi4vdXRpbHNcIjtcblxuZXhwb3J0IGludGVyZmFjZSBIZWFkZXJQcm9wcyB7XG4gIC8qKiBXaGV0aGVyIHRvIHJlbmRlciBzaXRld2lkZSBhbGVydHMgb3Igbm90LiBUcnVlIGJ5IGRlZmF1bHQuICovXG4gIGZldGNoU2l0ZXdpZGVBbGVydHM/OiBib29sZWFuO1xuICAvKiogV2hldGhlciBvciBub3QgdGhlIGBIZWFkZXJgIGlzIGluIHByb2R1Y3Rpb24gbW9kZS4gVHJ1ZSBieSBkZWZhdWx0LiAqL1xuICBpc1Byb2R1Y3Rpb24/OiBib29sZWFuO1xufVxuXG4vKipcbiAqIFRoZSBOWVBMIGBIZWFkZXJgIGNvbXBvbmVudCBpcyB0aGUgdG9wLWxldmVsIGNvbXBvbmVudCBvZiB0aGUgc2l0ZS4gSXRcbiAqIGNvbnRhaW5zIGZlYXR1cmVzIGZvciBsb2dnaW5nIGluLCBsb2dnaW5nIG91dCwgc2VhcmNoaW5nLCBhbmQgbmF2aWdhdGluZ1xuICogdGhlIE5ZUEwub3JnIHNpdGUuXG4gKi9cbmV4cG9ydCBjb25zdCBIZWFkZXIgPSBjaGFrcmEoXG4gICh7IGZldGNoU2l0ZXdpZGVBbGVydHMgPSB0cnVlLCBpc1Byb2R1Y3Rpb24gPSB0cnVlIH06IEhlYWRlclByb3BzKSA9PiB7XG4gICAgY29uc3QgZW52UHJlZml4ID0gZ2V0RW52VmFyKFwiVklURV9BUFBfRU5WXCIpID09PSBcInFhXCIgPyBcInFhLVwiIDogXCJcIjtcbiAgICAvLyBpc0xhcmdlclRoYW5MYXJnZSBpcyBncmVhdGVyIHRoYW4gOTYwcHhcbiAgICBjb25zdCB7IGlzTGFyZ2VyVGhhbkxhcmdlIH0gPSB1c2VOWVBMQnJlYWtwb2ludHMoKTtcbiAgICAvLyBUaGUgSGVhZGVyJ3MgXCJtb2JpbGVcIiBpcyA4MzJweCBhbmQgYmVsb3cuXG4gICAgY29uc3QgW2lzTGFyZ2VyVGhhbk1vYmlsZV0gPSB1c2VNZWRpYVF1ZXJ5KFtcbiAgICAgIGAobWluLXdpZHRoOiAke2hlYWRlckJyZWFrcG9pbnRzLm1ofSlgLFxuICAgIF0pO1xuXG4gICAgY29uc3Qgc3R5bGVzID0gdXNlTXVsdGlTdHlsZUNvbmZpZyhcIkhlYWRlclwiLCB7fSk7XG4gICAgLy8gQ3JlYXRlIGEgbmV3IGluc3RhbmNlIG9mIHRoZSBFbmNvcmVDYXRhbG9nTG9nT3V0VGltZXIuIFRoZSB0aW1lciB3aWxsXG4gICAgLy8gc3RhcnQgd2hlbiB0aGUgY29tcG9uZW50IGlzIG1vdW50ZWQuIEV2ZW4gdGhvdWdoIHRoZSBwYXRyb24ncyBpbmZvcm1hdGlvblxuICAgIC8vIGlzIG5vIGxvbmdlciBkaXNwbGF5ZWQgaW4gdGhlIGhlYWRlciwgd2Ugc3RpbGwgd2FudCB0byBtYWtlIHN1cmUgdGhhdFxuICAgIC8vIHRoZXkgYXJlIGxvZ2dlZCBvdXQgaW4gdmFyaW91cyBOWVBMIHNpdGVzLlxuICAgIGNvbnN0IGVuY29yZUNhdGFsb2dMb2dPdXRUaW1lciA9IG5ldyBFbmNvcmVDYXRhbG9nTG9nT3V0VGltZXIoXG4gICAgICBEYXRlLm5vdygpLFxuICAgICAgZmFsc2VcbiAgICApO1xuXG4gICAgLy8gT25jZSB0aGUgYEhlYWRlcmAgY29tcG9uZW50IGlzIG1vdW50ZWQsIHN0YXJ0IGEgdGltZXIgdGhhdCB3aWxsXG4gICAgLy8gbG9nIHRoZSB1c2VyIG91dCBvZiBWZWdhIGFuZCB0aGUgTllQTCBDYXRhbG9nIGFmdGVyIDMwIG1pbnV0ZXMuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgIGVuY29yZUNhdGFsb2dMb2dPdXRUaW1lci5zZXRFbmNvcmVMb2dnZWRJblRpbWVyKHdpbmRvdy5sb2NhdGlvbi5ob3N0KTtcbiAgICB9KTtcblxuICAgIC8vIFdlIGFsc28gd2FudCB0byBkZWxldGUgYSBjZXJ0YWluIGxvZyBpbi1yZWxhdGVkIGNvb2tpZSBidXQgc2hvdWxkXG4gICAgLy8gYWN0aXZlbHkgY2hlY2sgYW5kIGRlbGV0ZSBpdCBldmVyeSAzIHNlY29uZHMuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgIGNvbnN0IGludGVydmFsID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgICBlbmNvcmVDYXRhbG9nTG9nT3V0VGltZXIucmVtb3ZlTG9nZ2VkSW5Db29raWUoKTtcbiAgICAgIH0sIDMwMDApO1xuICAgICAgcmV0dXJuICgpID0+IGNsZWFySW50ZXJ2YWwoaW50ZXJ2YWwpO1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIChcbiAgICAgIDxIZWFkZXJQcm92aWRlciBpc1Byb2R1Y3Rpb249e2lzUHJvZHVjdGlvbn0+XG4gICAgICAgIDxCb3hcbiAgICAgICAgICBfX2Nzcz17e1xuICAgICAgICAgICAgLi4uc3R5bGVzLFxuICAgICAgICAgICAgLy8gRm9yIFZlZ2Egb3ZlcnJpZGUsIHRoaXMgaXMgdGhlIGJyb3dzZXIncyBkZWZhdWx0LlxuICAgICAgICAgICAgXCImID4gbmF2IGxpXCI6IHsgbWFyZ2luQm90dG9tOiBcIjAgIWltcG9ydGFudFwiIH0sXG4gICAgICAgICAgICBcIiYgc3ZnXCI6IHsgdmVydGljYWxBbGlnbjogXCJiYXNlbGluZSAhaW1wb3J0YW50XCIgfSxcbiAgICAgICAgICAgIFwiJiBmaWVsZHNldFwiOiB7XG4gICAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogXCIwcHggIWltcG9ydGFudFwiLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwiJiBpbnB1dFwiOiB7XG4gICAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogXCIwcHggIWltcG9ydGFudFwiLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgPFNraXBOYXZpZ2F0aW9uIC8+XG4gICAgICAgICAge2ZldGNoU2l0ZXdpZGVBbGVydHMgPyA8SGVhZGVyU2l0ZXdpZGVBbGVydHMgLz4gOiBudWxsfVxuICAgICAgICAgIDxoZWFkZXI+XG4gICAgICAgICAgICA8SFN0YWNrIF9fY3NzPXtzdHlsZXMuY29udGFpbmVyfT5cbiAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiVGhlIE5ldyBZb3JrIFB1YmxpYyBMaWJyYXJ5XCJcbiAgICAgICAgICAgICAgICBocmVmPXtgLy8ke2VudlByZWZpeH13d3cubnlwbC5vcmdgfVxuICAgICAgICAgICAgICAgIF9fY3NzPXtzdHlsZXMubG9nb31cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxMb2dvXG4gICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiTllQTCBIZWFkZXIgTG9nb1wiXG4gICAgICAgICAgICAgICAgICBuYW1lPXtcbiAgICAgICAgICAgICAgICAgICAgaXNMYXJnZXJUaGFuTGFyZ2VcbiAgICAgICAgICAgICAgICAgICAgICA/IHVzZUNvbG9yTW9kZVZhbHVlKFwibnlwbEZ1bGxCbGFja1wiLCBcIm55cGxGdWxsV2hpdGVcIilcbiAgICAgICAgICAgICAgICAgICAgICA6IHVzZUNvbG9yTW9kZVZhbHVlKFwibnlwbExpb25CbGFja1wiLCBcIm55cGxMaW9uV2hpdGVcIilcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIHNpemU9e2lzTGFyZ2VyVGhhbk1vYmlsZSA/IFwibGFyZ2VcIiA6IFwic21hbGxcIn1cbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiTllQTCBIZWFkZXIgTG9nb1wiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICA8U3BhY2VyIC8+XG4gICAgICAgICAgICAgIHtpc0xhcmdlclRoYW5Nb2JpbGUgPyAoXG4gICAgICAgICAgICAgICAgPFZTdGFjayBhbGlnbkl0ZW1zPVwiZW5kXCIgX19jc3M9e3N0eWxlcy5uYXZDb250YWluZXJ9PlxuICAgICAgICAgICAgICAgICAgPEhlYWRlclVwcGVyTmF2IC8+XG4gICAgICAgICAgICAgICAgICA8SGVhZGVyTG93ZXJOYXYgLz5cbiAgICAgICAgICAgICAgICA8L1ZTdGFjaz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8SGVhZGVyTW9iaWxlSWNvbk5hdiBlbnZQcmVmaXg9e2VudlByZWZpeH0gLz5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvSFN0YWNrPlxuICAgICAgICAgICAgPEhvcml6b250YWxSdWxlIF9fY3NzPXtzdHlsZXMuaG9yaXpvbnRhbFJ1bGV9IC8+XG4gICAgICAgICAgPC9oZWFkZXI+XG4gICAgICAgIDwvQm94PlxuICAgICAgPC9IZWFkZXJQcm92aWRlcj5cbiAgICApO1xuICB9XG4pO1xuXG5leHBvcnQgZGVmYXVsdCBIZWFkZXI7XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaHJpc211bGhvbGxhbmQvU2l0ZXMvdGVzdHMvbnlwbC1oZWFkZXItYXBwL3NyYy9jb21wb25lbnRzL0hlYWRlci9IZWFkZXIudHN4In0=