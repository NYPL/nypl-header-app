import { headerFocus } from "/theme/header.ts";
const HeaderUpperNav = {
  parts: ["donateLink"],
  baseStyle: {
    height: "37px",
    ul: {
      alignItems: "center",
      display: "flex",
      margin: "0",
      whiteSpace: "nowrap"
    },
    li: {
      fontSize: "var(--nypl-fontSizes-desktop-body-body2) !important",
      fontWeight: "medium",
      marginRight: "s",
      _last: {
        marginRight: "0"
      }
    },
    a: {
      color: "ui.black",
      position: "relative",
      textDecoration: "none",
      _hover: {
        color: "ui.black",
        textDecoration: "none"
      },
      _focus: headerFocus,
      _dark: {
        color: "dark.ui.typography.heading",
        _hover: {
          color: "dark.ui.typography.heading"
        }
      }
    },
    svg: {
      _dark: {
        fill: "white"
      }
    },
    donateLink: {
      color: "var(--nypl-colors-ui-white) !important",
      _hover: {
        color: "var(--nypl-colors-ui-white) !important"
      },
      _dark: {
        bgColor: "brand.secondary",
        _hover: {
          bgColor: "brand.primary"
        }
      }
    }
  }
};
export default HeaderUpperNav;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlclVwcGVyTmF2LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGhlYWRlckZvY3VzIH0gZnJvbSBcIi4vaGVhZGVyXCI7XG5cbmNvbnN0IEhlYWRlclVwcGVyTmF2ID0ge1xuICBwYXJ0czogW1wiZG9uYXRlTGlua1wiXSxcbiAgYmFzZVN0eWxlOiB7XG4gICAgaGVpZ2h0OiBcIjM3cHhcIixcbiAgICB1bDoge1xuICAgICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcbiAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgbWFyZ2luOiBcIjBcIixcbiAgICAgIHdoaXRlU3BhY2U6IFwibm93cmFwXCIsXG4gICAgfSxcbiAgICBsaToge1xuICAgICAgZm9udFNpemU6IFwidmFyKC0tbnlwbC1mb250U2l6ZXMtZGVza3RvcC1ib2R5LWJvZHkyKSAhaW1wb3J0YW50XCIsXG4gICAgICBmb250V2VpZ2h0OiBcIm1lZGl1bVwiLFxuICAgICAgbWFyZ2luUmlnaHQ6IFwic1wiLFxuICAgICAgX2xhc3Q6IHtcbiAgICAgICAgbWFyZ2luUmlnaHQ6IFwiMFwiLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGE6IHtcbiAgICAgIGNvbG9yOiBcInVpLmJsYWNrXCIsXG4gICAgICBwb3NpdGlvbjogXCJyZWxhdGl2ZVwiLFxuICAgICAgdGV4dERlY29yYXRpb246IFwibm9uZVwiLFxuICAgICAgX2hvdmVyOiB7XG4gICAgICAgIGNvbG9yOiBcInVpLmJsYWNrXCIsXG4gICAgICAgIHRleHREZWNvcmF0aW9uOiBcIm5vbmVcIixcbiAgICAgIH0sXG4gICAgICBfZm9jdXM6IGhlYWRlckZvY3VzLFxuICAgICAgX2Rhcms6IHtcbiAgICAgICAgY29sb3I6IFwiZGFyay51aS50eXBvZ3JhcGh5LmhlYWRpbmdcIixcbiAgICAgICAgX2hvdmVyOiB7XG4gICAgICAgICAgY29sb3I6IFwiZGFyay51aS50eXBvZ3JhcGh5LmhlYWRpbmdcIixcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBzdmc6IHtcbiAgICAgIF9kYXJrOiB7XG4gICAgICAgIGZpbGw6IFwid2hpdGVcIixcbiAgICAgIH0sXG4gICAgfSxcbiAgICBkb25hdGVMaW5rOiB7XG4gICAgICBjb2xvcjogXCJ2YXIoLS1ueXBsLWNvbG9ycy11aS13aGl0ZSkgIWltcG9ydGFudFwiLFxuICAgICAgX2hvdmVyOiB7XG4gICAgICAgIGNvbG9yOiBcInZhcigtLW55cGwtY29sb3JzLXVpLXdoaXRlKSAhaW1wb3J0YW50XCIsXG4gICAgICB9LFxuICAgICAgX2Rhcms6IHtcbiAgICAgICAgYmdDb2xvcjogXCJicmFuZC5zZWNvbmRhcnlcIixcbiAgICAgICAgX2hvdmVyOiB7XG4gICAgICAgICAgYmdDb2xvcjogXCJicmFuZC5wcmltYXJ5XCIsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0sXG4gIH0sXG59O1xuXG5leHBvcnQgZGVmYXVsdCBIZWFkZXJVcHBlck5hdjtcbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFFNUIsTUFBTSxpQkFBaUI7QUFBQSxFQUNyQixPQUFPLENBQUMsWUFBWTtBQUFBLEVBQ3BCLFdBQVc7QUFBQSxJQUNULFFBQVE7QUFBQSxJQUNSLElBQUk7QUFBQSxNQUNGLFlBQVk7QUFBQSxNQUNaLFNBQVM7QUFBQSxNQUNULFFBQVE7QUFBQSxNQUNSLFlBQVk7QUFBQSxJQUNkO0FBQUEsSUFDQSxJQUFJO0FBQUEsTUFDRixVQUFVO0FBQUEsTUFDVixZQUFZO0FBQUEsTUFDWixhQUFhO0FBQUEsTUFDYixPQUFPO0FBQUEsUUFDTCxhQUFhO0FBQUEsTUFDZjtBQUFBLElBQ0Y7QUFBQSxJQUNBLEdBQUc7QUFBQSxNQUNELE9BQU87QUFBQSxNQUNQLFVBQVU7QUFBQSxNQUNWLGdCQUFnQjtBQUFBLE1BQ2hCLFFBQVE7QUFBQSxRQUNOLE9BQU87QUFBQSxRQUNQLGdCQUFnQjtBQUFBLE1BQ2xCO0FBQUEsTUFDQSxRQUFRO0FBQUEsTUFDUixPQUFPO0FBQUEsUUFDTCxPQUFPO0FBQUEsUUFDUCxRQUFRO0FBQUEsVUFDTixPQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxLQUFLO0FBQUEsTUFDSCxPQUFPO0FBQUEsUUFDTCxNQUFNO0FBQUEsTUFDUjtBQUFBLElBQ0Y7QUFBQSxJQUNBLFlBQVk7QUFBQSxNQUNWLE9BQU87QUFBQSxNQUNQLFFBQVE7QUFBQSxRQUNOLE9BQU87QUFBQSxNQUNUO0FBQUEsTUFDQSxPQUFPO0FBQUEsUUFDTCxTQUFTO0FBQUEsUUFDVCxRQUFRO0FBQUEsVUFDTixTQUFTO0FBQUEsUUFDWDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBRUEsZUFBZTsiLCJuYW1lcyI6W119