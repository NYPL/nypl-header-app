import { headerBlack, headerFocus } from "/theme/header.ts";
const HeaderMobileNavButton = {
  baseStyle: ({ isOpen }) => ({
    alignItems: "center",
    backgroundColor: isOpen ? headerBlack : "transparent",
    border: "none",
    borderRadius: "0",
    display: "flex",
    justifyContent: "center",
    svg: {
      fill: isOpen ? "ui.white" : "ui.black",
      marginLeft: "0"
    },
    _hover: {
      backgroundColor: isOpen ? headerBlack : "transparent",
      svg: {
        fill: isOpen ? "ui.white" : "ui.black"
      }
    },
    _focus: headerFocus,
    _dark: {
      backgroundColor: isOpen ? headerBlack : "transparent",
      svg: {
        fill: "dark.ui.typography.heading"
      }
    }
  })
};
export default HeaderMobileNavButton;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlck1vYmlsZU5hdkJ1dHRvbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBoZWFkZXJCbGFjaywgaGVhZGVyRm9jdXMgfSBmcm9tIFwiLi9oZWFkZXJcIjtcblxuY29uc3QgSGVhZGVyTW9iaWxlTmF2QnV0dG9uID0ge1xuICBiYXNlU3R5bGU6ICh7IGlzT3BlbiB9KSA9PiAoe1xuICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXG4gICAgYmFja2dyb3VuZENvbG9yOiBpc09wZW4gPyBoZWFkZXJCbGFjayA6IFwidHJhbnNwYXJlbnRcIixcbiAgICBib3JkZXI6IFwibm9uZVwiLFxuICAgIGJvcmRlclJhZGl1czogXCIwXCIsXG4gICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIsXG4gICAgc3ZnOiB7XG4gICAgICBmaWxsOiBpc09wZW4gPyBcInVpLndoaXRlXCIgOiBcInVpLmJsYWNrXCIsXG4gICAgICBtYXJnaW5MZWZ0OiBcIjBcIixcbiAgICB9LFxuICAgIF9ob3Zlcjoge1xuICAgICAgYmFja2dyb3VuZENvbG9yOiBpc09wZW4gPyBoZWFkZXJCbGFjayA6IFwidHJhbnNwYXJlbnRcIixcbiAgICAgIHN2Zzoge1xuICAgICAgICBmaWxsOiBpc09wZW4gPyBcInVpLndoaXRlXCIgOiBcInVpLmJsYWNrXCIsXG4gICAgICB9LFxuICAgIH0sXG4gICAgX2ZvY3VzOiBoZWFkZXJGb2N1cyxcbiAgICBfZGFyazoge1xuICAgICAgYmFja2dyb3VuZENvbG9yOiBpc09wZW4gPyBoZWFkZXJCbGFjayA6IFwidHJhbnNwYXJlbnRcIixcbiAgICAgIHN2Zzoge1xuICAgICAgICBmaWxsOiBcImRhcmsudWkudHlwb2dyYXBoeS5oZWFkaW5nXCIsXG4gICAgICB9LFxuICAgIH0sXG4gIH0pLFxufTtcblxuZXhwb3J0IGRlZmF1bHQgSGVhZGVyTW9iaWxlTmF2QnV0dG9uO1xuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLGFBQWEsbUJBQW1CO0FBRXpDLE1BQU0sd0JBQXdCO0FBQUEsRUFDNUIsV0FBVyxDQUFDLEVBQUUsT0FBTyxPQUFPO0FBQUEsSUFDMUIsWUFBWTtBQUFBLElBQ1osaUJBQWlCLFNBQVMsY0FBYztBQUFBLElBQ3hDLFFBQVE7QUFBQSxJQUNSLGNBQWM7QUFBQSxJQUNkLFNBQVM7QUFBQSxJQUNULGdCQUFnQjtBQUFBLElBQ2hCLEtBQUs7QUFBQSxNQUNILE1BQU0sU0FBUyxhQUFhO0FBQUEsTUFDNUIsWUFBWTtBQUFBLElBQ2Q7QUFBQSxJQUNBLFFBQVE7QUFBQSxNQUNOLGlCQUFpQixTQUFTLGNBQWM7QUFBQSxNQUN4QyxLQUFLO0FBQUEsUUFDSCxNQUFNLFNBQVMsYUFBYTtBQUFBLE1BQzlCO0FBQUEsSUFDRjtBQUFBLElBQ0EsUUFBUTtBQUFBLElBQ1IsT0FBTztBQUFBLE1BQ0wsaUJBQWlCLFNBQVMsY0FBYztBQUFBLE1BQ3hDLEtBQUs7QUFBQSxRQUNILE1BQU07QUFBQSxNQUNSO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLGVBQWU7IiwibmFtZXMiOltdfQ==