import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/Header/components/HeaderSearchButton.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchButton.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import FocusLock from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@chakra-ui_focus-lock.js?v=92ee0591";
import { Box, chakra, useStyleConfig } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@chakra-ui_react.js?v=2c813617";
import __vite__cjsImport5_react from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/react.js?v=f7bb76b7"; const useState = __vite__cjsImport5_react["useState"]; const useRef = __vite__cjsImport5_react["useRef"];
import HeaderSearchForm from "/components/Header/components/HeaderSearchForm.tsx";
import { Button, Icon, useCloseDropDown } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@nypl_design-system-react-components.js?v=f372bde6";
const HeaderSearchButton = _s(chakra(_c = _s(({
  isMobile = false
}) => {
  _s();
  const [isOpen, setIsOpen] = useState(false);
  const styles = useStyleConfig("HeaderSearchButton", {
    isOpen
  });
  const buttonText = isMobile ? null : isOpen ? "Close" : "Search";
  const labelText = isOpen ? "Close Search" : "Open Search";
  const ref = useRef(null);
  useCloseDropDown(setIsOpen, ref);
  return /* @__PURE__ */ jsxDEV(Box, { ref, children: /* @__PURE__ */ jsxDEV(FocusLock, { isDisabled: !isOpen, children: [
    /* @__PURE__ */ jsxDEV(Button, { "aria-haspopup": "true", "aria-label": labelText, "aria-expanded": isOpen ? true : null, buttonType: "text", id: "searchButton", onClick: () => {
      setIsOpen(!isOpen);
    }, __css: {
      ...styles,
      color: isOpen ? "var(--nypl-colors-ui-white) !important" : "ui.link.primary",
      border: "none !important",
      letterSpacing: 0,
      padding: "0px",
      paddingInlineEnd: "0px"
    }, children: /* @__PURE__ */ jsxDEV("span", { children: [
      buttonText,
      /* @__PURE__ */ jsxDEV(Icon, { align: isMobile ? "none" : "right", name: isOpen ? "close" : "actionSearch", size: isMobile ? "large" : "medium", title: labelText }, void 0, false, {
        fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchButton.tsx",
        lineNumber: 41,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchButton.tsx",
      lineNumber: 39,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchButton.tsx",
      lineNumber: 29,
      columnNumber: 11
    }, this),
    isOpen && /* @__PURE__ */ jsxDEV(HeaderSearchForm, { isMobile }, void 0, false, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchButton.tsx",
      lineNumber: 44,
      columnNumber: 22
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchButton.tsx",
    lineNumber: 28,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchButton.tsx",
    lineNumber: 27,
    columnNumber: 10
  }, this);
}, "uORRuor8gDIiyCmi/w925c+/YhQ=", false, function() {
  return [useStyleConfig, useCloseDropDown];
})), "uORRuor8gDIiyCmi/w925c+/YhQ=", false, function() {
  return [useStyleConfig, useCloseDropDown];
});
_c2 = HeaderSearchButton;
export default HeaderSearchButton;
var _c, _c2;
$RefreshReg$(_c, "HeaderSearchButton$chakra");
$RefreshReg$(_c2, "HeaderSearchButton");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderSearchButton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0RjOzs7Ozs7Ozs7Ozs7Ozs7O0FBdERkLE9BQU9BLGVBQWU7QUFDdEIsU0FBU0MsS0FBS0MsUUFBUUMsc0JBQXNCO0FBQzVDLFNBQVNDLFVBQVVDLGNBQWM7QUFFakMsT0FBT0Msc0JBQXNCO0FBQzdCLFNBQ0VDLFFBQ0FDLE1BQ0FDLHdCQUNLO0FBVVAsTUFBTUMscUJBQWtCQyxHQUFHVCxPQUFNVSxLQUFBRCxHQUMvQixDQUFDO0FBQUEsRUFBRUUsV0FBVztBQUErQixNQUFNO0FBQUFGLEtBQUE7QUFDakQsUUFBTSxDQUFDRyxRQUFRQyxTQUFTLElBQUlYLFNBQWtCLEtBQUs7QUFDbkQsUUFBTVksU0FBU2IsZUFBZSxzQkFBc0I7QUFBQSxJQUFFVztBQUFBQSxFQUFPLENBQUM7QUFDOUQsUUFBTUcsYUFBYUosV0FBVyxPQUFPQyxTQUFTLFVBQVU7QUFDeEQsUUFBTUksWUFBWUosU0FBUyxpQkFBaUI7QUFDNUMsUUFBTUssTUFBTWQsT0FBdUIsSUFBSTtBQUV2Q0ksbUJBQWlCTSxXQUFXSSxHQUFHO0FBRS9CLFNBQ0UsdUJBQUMsT0FBSSxLQUNILGlDQUFDLGFBQVUsWUFBWSxDQUFDTCxRQUN0QjtBQUFBLDJCQUFDLFVBQ0MsaUJBQWMsUUFDZCxjQUFZSSxXQUNaLGlCQUFlSixTQUFTLE9BQU8sTUFDL0IsWUFBVyxRQUNYLElBQUcsZ0JBQ0gsU0FBUyxNQUFNO0FBQ2JDLGdCQUFVLENBQUNELE1BQU07QUFBQSxJQUNuQixHQUNBLE9BQU87QUFBQSxNQUNMLEdBQUdFO0FBQUFBLE1BQ0hJLE9BQU9OLFNBQ0gsMkNBQ0E7QUFBQSxNQUNKTyxRQUFRO0FBQUEsTUFDUkMsZUFBZTtBQUFBLE1BQ2ZDLFNBQVM7QUFBQSxNQUNUQyxrQkFBa0I7QUFBQSxJQUNwQixHQUVBLGlDQUFDLFVBQ0VQO0FBQUFBO0FBQUFBLE1BQ0QsdUJBQUMsUUFDQyxPQUFPSixXQUFXLFNBQVMsU0FDM0IsTUFBTUMsU0FBUyxVQUFVLGdCQUN6QixNQUFNRCxXQUFXLFVBQVUsVUFDM0IsT0FBT0ssYUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSW1CO0FBQUEsU0FOckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBLEtBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2QkE7QUFBQSxJQUNDSixVQUFVLHVCQUFDLG9CQUFpQixZQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFDO0FBQUEsT0EvQmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQ0EsS0FqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtDQTtBQUVKLEdBQUM7QUFBQSxVQTVDZ0JYLGdCQUtmTSxnQkFBZ0I7QUFBQSxFQXdDcEIsR0FBQztBQUFBLFVBN0NrQk4sZ0JBS2ZNLGdCQUFnQjtBQUFBO0FBd0NsQmdCLE1BaERJZjtBQWtETixlQUFlQTtBQUFtQixJQUFBRSxJQUFBYTtBQUFBQyxhQUFBZCxJQUFBO0FBQUFjLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJGb2N1c0xvY2siLCJCb3giLCJjaGFrcmEiLCJ1c2VTdHlsZUNvbmZpZyIsInVzZVN0YXRlIiwidXNlUmVmIiwiSGVhZGVyU2VhcmNoRm9ybSIsIkJ1dHRvbiIsIkljb24iLCJ1c2VDbG9zZURyb3BEb3duIiwiSGVhZGVyU2VhcmNoQnV0dG9uIiwiX3MiLCJfYyIsImlzTW9iaWxlIiwiaXNPcGVuIiwic2V0SXNPcGVuIiwic3R5bGVzIiwiYnV0dG9uVGV4dCIsImxhYmVsVGV4dCIsInJlZiIsImNvbG9yIiwiYm9yZGVyIiwibGV0dGVyU3BhY2luZyIsInBhZGRpbmciLCJwYWRkaW5nSW5saW5lRW5kIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiSGVhZGVyU2VhcmNoQnV0dG9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgRm9jdXNMb2NrIGZyb20gXCJAY2hha3JhLXVpL2ZvY3VzLWxvY2tcIjtcbmltcG9ydCB7IEJveCwgY2hha3JhLCB1c2VTdHlsZUNvbmZpZyB9IGZyb20gXCJAY2hha3JhLXVpL3JlYWN0XCI7XG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlUmVmIH0gZnJvbSBcInJlYWN0XCI7XG5cbmltcG9ydCBIZWFkZXJTZWFyY2hGb3JtIGZyb20gXCIuL0hlYWRlclNlYXJjaEZvcm1cIjtcbmltcG9ydCB7XG4gIEJ1dHRvbixcbiAgSWNvbixcbiAgdXNlQ2xvc2VEcm9wRG93bixcbn0gZnJvbSBcIkBueXBsL2Rlc2lnbi1zeXN0ZW0tcmVhY3QtY29tcG9uZW50c1wiO1xuXG5leHBvcnQgaW50ZXJmYWNlIEhlYWRlclNlYXJjaEJ1dHRvblByb3BzIHtcbiAgaXNNb2JpbGU/OiBib29sZWFuO1xufVxuXG4vKipcbiAqIFRoaXMgaXMgdGhlIGJ1dHRvbiB0aGF0IHdpbGwgcmVuZGVyIHRoZSBzZWFyY2ggZm9ybSB3aGVuIGl0IGlzIGNsaWNrZWQgYW5kXG4gKiBrZWVwIGZvY3VzIHRyYXBwZWQgd2l0aGluIHRoZSBtZW51LlxuICovXG5jb25zdCBIZWFkZXJTZWFyY2hCdXR0b24gPSBjaGFrcmEoXG4gICh7IGlzTW9iaWxlID0gZmFsc2UgfTogSGVhZGVyU2VhcmNoQnV0dG9uUHJvcHMpID0+IHtcbiAgICBjb25zdCBbaXNPcGVuLCBzZXRJc09wZW5dID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICAgIGNvbnN0IHN0eWxlcyA9IHVzZVN0eWxlQ29uZmlnKFwiSGVhZGVyU2VhcmNoQnV0dG9uXCIsIHsgaXNPcGVuIH0pO1xuICAgIGNvbnN0IGJ1dHRvblRleHQgPSBpc01vYmlsZSA/IG51bGwgOiBpc09wZW4gPyBcIkNsb3NlXCIgOiBcIlNlYXJjaFwiO1xuICAgIGNvbnN0IGxhYmVsVGV4dCA9IGlzT3BlbiA/IFwiQ2xvc2UgU2VhcmNoXCIgOiBcIk9wZW4gU2VhcmNoXCI7XG4gICAgY29uc3QgcmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcblxuICAgIHVzZUNsb3NlRHJvcERvd24oc2V0SXNPcGVuLCByZWYpO1xuXG4gICAgcmV0dXJuIChcbiAgICAgIDxCb3ggcmVmPXtyZWZ9PlxuICAgICAgICA8Rm9jdXNMb2NrIGlzRGlzYWJsZWQ9eyFpc09wZW59PlxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIGFyaWEtaGFzcG9wdXA9XCJ0cnVlXCJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9e2xhYmVsVGV4dH1cbiAgICAgICAgICAgIGFyaWEtZXhwYW5kZWQ9e2lzT3BlbiA/IHRydWUgOiBudWxsfVxuICAgICAgICAgICAgYnV0dG9uVHlwZT1cInRleHRcIlxuICAgICAgICAgICAgaWQ9XCJzZWFyY2hCdXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICBzZXRJc09wZW4oIWlzT3Blbik7XG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgX19jc3M9e3tcbiAgICAgICAgICAgICAgLi4uc3R5bGVzLFxuICAgICAgICAgICAgICBjb2xvcjogaXNPcGVuXG4gICAgICAgICAgICAgICAgPyBcInZhcigtLW55cGwtY29sb3JzLXVpLXdoaXRlKSAhaW1wb3J0YW50XCJcbiAgICAgICAgICAgICAgICA6IFwidWkubGluay5wcmltYXJ5XCIsXG4gICAgICAgICAgICAgIGJvcmRlcjogXCJub25lICFpbXBvcnRhbnRcIixcbiAgICAgICAgICAgICAgbGV0dGVyU3BhY2luZzogMCxcbiAgICAgICAgICAgICAgcGFkZGluZzogXCIwcHhcIixcbiAgICAgICAgICAgICAgcGFkZGluZ0lubGluZUVuZDogXCIwcHhcIixcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgIHtidXR0b25UZXh0fVxuICAgICAgICAgICAgICA8SWNvblxuICAgICAgICAgICAgICAgIGFsaWduPXtpc01vYmlsZSA/IFwibm9uZVwiIDogXCJyaWdodFwifVxuICAgICAgICAgICAgICAgIG5hbWU9e2lzT3BlbiA/IFwiY2xvc2VcIiA6IFwiYWN0aW9uU2VhcmNoXCJ9XG4gICAgICAgICAgICAgICAgc2l6ZT17aXNNb2JpbGUgPyBcImxhcmdlXCIgOiBcIm1lZGl1bVwifVxuICAgICAgICAgICAgICAgIHRpdGxlPXtsYWJlbFRleHR9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAge2lzT3BlbiAmJiA8SGVhZGVyU2VhcmNoRm9ybSBpc01vYmlsZT17aXNNb2JpbGV9IC8+fVxuICAgICAgICA8L0ZvY3VzTG9jaz5cbiAgICAgIDwvQm94PlxuICAgICk7XG4gIH1cbik7XG5cbmV4cG9ydCBkZWZhdWx0IEhlYWRlclNlYXJjaEJ1dHRvbjtcbiJdLCJmaWxlIjoiL1VzZXJzL2NocmlzbXVsaG9sbGFuZC9TaXRlcy90ZXN0cy9ueXBsLWhlYWRlci1hcHAvc3JjL2NvbXBvbmVudHMvSGVhZGVyL2NvbXBvbmVudHMvSGVhZGVyU2VhcmNoQnV0dG9uLnRzeCJ9