import { headerLightBlue, headerBlue, headerFocus } from "/theme/header.ts";
const HeaderSearchForm = {
  parts: ["searchBtn", "form", "radio", "textInput"],
  baseStyle: {
    color: "ui.white",
    backgroundColor: headerBlue,
    left: "0px",
    minHeight: { base: "180px", mh: "235px" },
    position: "absolute",
    whiteSpace: "initial",
    width: "100%",
    zIndex: "99999",
    svg: {
      color: "ui.white",
      fill: "ui.white",
      marginTop: "0"
    },
    form: {
      margin: { mh: "45px auto 40px auto" },
      maxWidth: { mh: "1312px" },
      whiteSpace: "initial",
      "> div": {
        margin: "20px 15px",
        marginLeft: { mh: "m", lh: "140px" },
        marginRight: { mh: "m" }
      }
    },
    "#radio-group-search-type": {
      margin: { base: "0 20px 20px", mh: "0" }
    },
    textInput: {
      label: {
        color: "ui.white",
        fontSize: {
          base: "heading.callout",
          mh: "heading.secondary"
        }
      },
      input: {
        borderRadius: { mh: "5px" },
        color: "ui.black",
        minHeight: { base: "65px", mh: "60px" },
        paddingLeft: { base: "25px", mh: "15px" },
        _placeholder: {
          fontSize: { base: "20px" },
          fontStyle: "normal"
        },
        _focus: { ...headerFocus, borderRadius: "5px" },
        _hover: { ...headerFocus, borderRadius: "5px" },
        _dark: {
          color: "dark.ui.typography.body"
        }
      }
    },
    searchBtn: {
      alignSelf: "end",
      backgroundColor: "transparent",
      borderColor: "ui.white",
      borderRadius: "100px",
      borderWidth: "2px",
      height: { base: "65px", mh: "60px" },
      marginTop: "40px",
      marginEnd: "0",
      maxHeight: "65px",
      svg: {
        marginTop: "xs"
      },
      width: { base: "65px", mh: "60px" },
      _focus: { ...headerFocus, borderRadius: "100px" },
      _hover: {
        backgroundColor: "transparent",
        ...headerFocus,
        borderRadius: "100px"
      }
    },
    radio: {
      backgroundColor: "white",
      border: "1px solid white",
      _focus: { ...headerFocus, borderRadius: "100px" },
      _hover: { ...headerFocus, borderRadius: "100px" }
    },
    // Specifically target the radio buttons.
    ".chakra-radio": {
      alignItems: "center"
    },
    // Specifically target the radio labels.
    ".chakra-radio__label": {
      fontWeight: "medium"
    },
    mobileBtns: {
      alignItems: "center",
      backgroundColor: headerBlue,
      borderRadius: "0",
      display: "flex",
      fontSize: "16px",
      flex: "1",
      justifyContent: "center",
      padding: "25px 0",
      svg: {
        fill: headerLightBlue,
        marginLeft: "15px"
      },
      _hover: {
        backgroundColor: headerBlue
      },
      _focus: headerFocus
    },
    _dark: {
      bgColor: "section.research.secondary",
      color: "ui.white",
      label: {
        color: "ui.white"
      }
    }
  }
};
export default HeaderSearchForm;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlclNlYXJjaEZvcm0udHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgaGVhZGVyTGlnaHRCbHVlLCBoZWFkZXJCbHVlLCBoZWFkZXJGb2N1cyB9IGZyb20gXCIuL2hlYWRlclwiO1xuXG5jb25zdCBIZWFkZXJTZWFyY2hGb3JtID0ge1xuICBwYXJ0czogW1wic2VhcmNoQnRuXCIsIFwiZm9ybVwiLCBcInJhZGlvXCIsIFwidGV4dElucHV0XCJdLFxuICBiYXNlU3R5bGU6IHtcbiAgICBjb2xvcjogXCJ1aS53aGl0ZVwiLFxuICAgIGJhY2tncm91bmRDb2xvcjogaGVhZGVyQmx1ZSxcbiAgICBsZWZ0OiBcIjBweFwiLFxuICAgIG1pbkhlaWdodDogeyBiYXNlOiBcIjE4MHB4XCIsIG1oOiBcIjIzNXB4XCIgfSxcbiAgICBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxuICAgIHdoaXRlU3BhY2U6IFwiaW5pdGlhbFwiLFxuICAgIHdpZHRoOiBcIjEwMCVcIixcbiAgICB6SW5kZXg6IFwiOTk5OTlcIixcbiAgICBzdmc6IHtcbiAgICAgIGNvbG9yOiBcInVpLndoaXRlXCIsXG4gICAgICBmaWxsOiBcInVpLndoaXRlXCIsXG4gICAgICBtYXJnaW5Ub3A6IFwiMFwiLFxuICAgIH0sXG4gICAgZm9ybToge1xuICAgICAgbWFyZ2luOiB7IG1oOiBcIjQ1cHggYXV0byA0MHB4IGF1dG9cIiB9LFxuICAgICAgbWF4V2lkdGg6IHsgbWg6IFwiMTMxMnB4XCIgfSxcbiAgICAgIHdoaXRlU3BhY2U6IFwiaW5pdGlhbFwiLFxuICAgICAgXCI+IGRpdlwiOiB7XG4gICAgICAgIG1hcmdpbjogXCIyMHB4IDE1cHhcIixcbiAgICAgICAgbWFyZ2luTGVmdDogeyBtaDogXCJtXCIsIGxoOiBcIjE0MHB4XCIgfSxcbiAgICAgICAgbWFyZ2luUmlnaHQ6IHsgbWg6IFwibVwiIH0sXG4gICAgICB9LFxuICAgIH0sXG4gICAgXCIjcmFkaW8tZ3JvdXAtc2VhcmNoLXR5cGVcIjoge1xuICAgICAgbWFyZ2luOiB7IGJhc2U6IFwiMCAyMHB4IDIwcHhcIiwgbWg6IFwiMFwiIH0sXG4gICAgfSxcbiAgICB0ZXh0SW5wdXQ6IHtcbiAgICAgIGxhYmVsOiB7XG4gICAgICAgIGNvbG9yOiBcInVpLndoaXRlXCIsXG4gICAgICAgIGZvbnRTaXplOiB7XG4gICAgICAgICAgYmFzZTogXCJoZWFkaW5nLmNhbGxvdXRcIixcbiAgICAgICAgICBtaDogXCJoZWFkaW5nLnNlY29uZGFyeVwiLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIGlucHV0OiB7XG4gICAgICAgIGJvcmRlclJhZGl1czogeyBtaDogXCI1cHhcIiB9LFxuICAgICAgICBjb2xvcjogXCJ1aS5ibGFja1wiLFxuICAgICAgICBtaW5IZWlnaHQ6IHsgYmFzZTogXCI2NXB4XCIsIG1oOiBcIjYwcHhcIiB9LFxuICAgICAgICBwYWRkaW5nTGVmdDogeyBiYXNlOiBcIjI1cHhcIiwgbWg6IFwiMTVweFwiIH0sXG4gICAgICAgIF9wbGFjZWhvbGRlcjoge1xuICAgICAgICAgIGZvbnRTaXplOiB7IGJhc2U6IFwiMjBweFwiIH0sXG4gICAgICAgICAgZm9udFN0eWxlOiBcIm5vcm1hbFwiLFxuICAgICAgICB9LFxuICAgICAgICBfZm9jdXM6IHsgLi4uaGVhZGVyRm9jdXMsIGJvcmRlclJhZGl1czogXCI1cHhcIiB9LFxuICAgICAgICBfaG92ZXI6IHsgLi4uaGVhZGVyRm9jdXMsIGJvcmRlclJhZGl1czogXCI1cHhcIiB9LFxuICAgICAgICBfZGFyazoge1xuICAgICAgICAgIGNvbG9yOiBcImRhcmsudWkudHlwb2dyYXBoeS5ib2R5XCIsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0sXG4gICAgc2VhcmNoQnRuOiB7XG4gICAgICBhbGlnblNlbGY6IFwiZW5kXCIsXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwidHJhbnNwYXJlbnRcIixcbiAgICAgIGJvcmRlckNvbG9yOiBcInVpLndoaXRlXCIsXG4gICAgICBib3JkZXJSYWRpdXM6IFwiMTAwcHhcIixcbiAgICAgIGJvcmRlcldpZHRoOiBcIjJweFwiLFxuICAgICAgaGVpZ2h0OiB7IGJhc2U6IFwiNjVweFwiLCBtaDogXCI2MHB4XCIgfSxcbiAgICAgIG1hcmdpblRvcDogXCI0MHB4XCIsXG4gICAgICBtYXJnaW5FbmQ6IFwiMFwiLFxuICAgICAgbWF4SGVpZ2h0OiBcIjY1cHhcIixcbiAgICAgIHN2Zzoge1xuICAgICAgICBtYXJnaW5Ub3A6IFwieHNcIixcbiAgICAgIH0sXG4gICAgICB3aWR0aDogeyBiYXNlOiBcIjY1cHhcIiwgbWg6IFwiNjBweFwiIH0sXG4gICAgICBfZm9jdXM6IHsgLi4uaGVhZGVyRm9jdXMsIGJvcmRlclJhZGl1czogXCIxMDBweFwiIH0sXG4gICAgICBfaG92ZXI6IHtcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBcInRyYW5zcGFyZW50XCIsXG4gICAgICAgIC4uLmhlYWRlckZvY3VzLFxuICAgICAgICBib3JkZXJSYWRpdXM6IFwiMTAwcHhcIixcbiAgICAgIH0sXG4gICAgfSxcbiAgICByYWRpbzoge1xuICAgICAgYmFja2dyb3VuZENvbG9yOiBcIndoaXRlXCIsXG4gICAgICBib3JkZXI6IFwiMXB4IHNvbGlkIHdoaXRlXCIsXG4gICAgICBfZm9jdXM6IHsgLi4uaGVhZGVyRm9jdXMsIGJvcmRlclJhZGl1czogXCIxMDBweFwiIH0sXG4gICAgICBfaG92ZXI6IHsgLi4uaGVhZGVyRm9jdXMsIGJvcmRlclJhZGl1czogXCIxMDBweFwiIH0sXG4gICAgfSxcbiAgICAvLyBTcGVjaWZpY2FsbHkgdGFyZ2V0IHRoZSByYWRpbyBidXR0b25zLlxuICAgIFwiLmNoYWtyYS1yYWRpb1wiOiB7XG4gICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgIH0sXG4gICAgLy8gU3BlY2lmaWNhbGx5IHRhcmdldCB0aGUgcmFkaW8gbGFiZWxzLlxuICAgIFwiLmNoYWtyYS1yYWRpb19fbGFiZWxcIjoge1xuICAgICAgZm9udFdlaWdodDogXCJtZWRpdW1cIixcbiAgICB9LFxuICAgIG1vYmlsZUJ0bnM6IHtcbiAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6IGhlYWRlckJsdWUsXG4gICAgICBib3JkZXJSYWRpdXM6IFwiMFwiLFxuICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICBmb250U2l6ZTogXCIxNnB4XCIsXG4gICAgICBmbGV4OiBcIjFcIixcbiAgICAgIGp1c3RpZnlDb250ZW50OiBcImNlbnRlclwiLFxuICAgICAgcGFkZGluZzogXCIyNXB4IDBcIixcbiAgICAgIHN2Zzoge1xuICAgICAgICBmaWxsOiBoZWFkZXJMaWdodEJsdWUsXG4gICAgICAgIG1hcmdpbkxlZnQ6IFwiMTVweFwiLFxuICAgICAgfSxcbiAgICAgIF9ob3Zlcjoge1xuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGhlYWRlckJsdWUsXG4gICAgICB9LFxuICAgICAgX2ZvY3VzOiBoZWFkZXJGb2N1cyxcbiAgICB9LFxuICAgIF9kYXJrOiB7XG4gICAgICBiZ0NvbG9yOiBcInNlY3Rpb24ucmVzZWFyY2guc2Vjb25kYXJ5XCIsXG4gICAgICBjb2xvcjogXCJ1aS53aGl0ZVwiLFxuICAgICAgbGFiZWw6IHtcbiAgICAgICAgY29sb3I6IFwidWkud2hpdGVcIixcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbn07XG5cbmV4cG9ydCBkZWZhdWx0IEhlYWRlclNlYXJjaEZvcm07XG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsaUJBQWlCLFlBQVksbUJBQW1CO0FBRXpELE1BQU0sbUJBQW1CO0FBQUEsRUFDdkIsT0FBTyxDQUFDLGFBQWEsUUFBUSxTQUFTLFdBQVc7QUFBQSxFQUNqRCxXQUFXO0FBQUEsSUFDVCxPQUFPO0FBQUEsSUFDUCxpQkFBaUI7QUFBQSxJQUNqQixNQUFNO0FBQUEsSUFDTixXQUFXLEVBQUUsTUFBTSxTQUFTLElBQUksUUFBUTtBQUFBLElBQ3hDLFVBQVU7QUFBQSxJQUNWLFlBQVk7QUFBQSxJQUNaLE9BQU87QUFBQSxJQUNQLFFBQVE7QUFBQSxJQUNSLEtBQUs7QUFBQSxNQUNILE9BQU87QUFBQSxNQUNQLE1BQU07QUFBQSxNQUNOLFdBQVc7QUFBQSxJQUNiO0FBQUEsSUFDQSxNQUFNO0FBQUEsTUFDSixRQUFRLEVBQUUsSUFBSSxzQkFBc0I7QUFBQSxNQUNwQyxVQUFVLEVBQUUsSUFBSSxTQUFTO0FBQUEsTUFDekIsWUFBWTtBQUFBLE1BQ1osU0FBUztBQUFBLFFBQ1AsUUFBUTtBQUFBLFFBQ1IsWUFBWSxFQUFFLElBQUksS0FBSyxJQUFJLFFBQVE7QUFBQSxRQUNuQyxhQUFhLEVBQUUsSUFBSSxJQUFJO0FBQUEsTUFDekI7QUFBQSxJQUNGO0FBQUEsSUFDQSw0QkFBNEI7QUFBQSxNQUMxQixRQUFRLEVBQUUsTUFBTSxlQUFlLElBQUksSUFBSTtBQUFBLElBQ3pDO0FBQUEsSUFDQSxXQUFXO0FBQUEsTUFDVCxPQUFPO0FBQUEsUUFDTCxPQUFPO0FBQUEsUUFDUCxVQUFVO0FBQUEsVUFDUixNQUFNO0FBQUEsVUFDTixJQUFJO0FBQUEsUUFDTjtBQUFBLE1BQ0Y7QUFBQSxNQUNBLE9BQU87QUFBQSxRQUNMLGNBQWMsRUFBRSxJQUFJLE1BQU07QUFBQSxRQUMxQixPQUFPO0FBQUEsUUFDUCxXQUFXLEVBQUUsTUFBTSxRQUFRLElBQUksT0FBTztBQUFBLFFBQ3RDLGFBQWEsRUFBRSxNQUFNLFFBQVEsSUFBSSxPQUFPO0FBQUEsUUFDeEMsY0FBYztBQUFBLFVBQ1osVUFBVSxFQUFFLE1BQU0sT0FBTztBQUFBLFVBQ3pCLFdBQVc7QUFBQSxRQUNiO0FBQUEsUUFDQSxRQUFRLEVBQUUsR0FBRyxhQUFhLGNBQWMsTUFBTTtBQUFBLFFBQzlDLFFBQVEsRUFBRSxHQUFHLGFBQWEsY0FBYyxNQUFNO0FBQUEsUUFDOUMsT0FBTztBQUFBLFVBQ0wsT0FBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLElBQ0EsV0FBVztBQUFBLE1BQ1QsV0FBVztBQUFBLE1BQ1gsaUJBQWlCO0FBQUEsTUFDakIsYUFBYTtBQUFBLE1BQ2IsY0FBYztBQUFBLE1BQ2QsYUFBYTtBQUFBLE1BQ2IsUUFBUSxFQUFFLE1BQU0sUUFBUSxJQUFJLE9BQU87QUFBQSxNQUNuQyxXQUFXO0FBQUEsTUFDWCxXQUFXO0FBQUEsTUFDWCxXQUFXO0FBQUEsTUFDWCxLQUFLO0FBQUEsUUFDSCxXQUFXO0FBQUEsTUFDYjtBQUFBLE1BQ0EsT0FBTyxFQUFFLE1BQU0sUUFBUSxJQUFJLE9BQU87QUFBQSxNQUNsQyxRQUFRLEVBQUUsR0FBRyxhQUFhLGNBQWMsUUFBUTtBQUFBLE1BQ2hELFFBQVE7QUFBQSxRQUNOLGlCQUFpQjtBQUFBLFFBQ2pCLEdBQUc7QUFBQSxRQUNILGNBQWM7QUFBQSxNQUNoQjtBQUFBLElBQ0Y7QUFBQSxJQUNBLE9BQU87QUFBQSxNQUNMLGlCQUFpQjtBQUFBLE1BQ2pCLFFBQVE7QUFBQSxNQUNSLFFBQVEsRUFBRSxHQUFHLGFBQWEsY0FBYyxRQUFRO0FBQUEsTUFDaEQsUUFBUSxFQUFFLEdBQUcsYUFBYSxjQUFjLFFBQVE7QUFBQSxJQUNsRDtBQUFBO0FBQUEsSUFFQSxpQkFBaUI7QUFBQSxNQUNmLFlBQVk7QUFBQSxJQUNkO0FBQUE7QUFBQSxJQUVBLHdCQUF3QjtBQUFBLE1BQ3RCLFlBQVk7QUFBQSxJQUNkO0FBQUEsSUFDQSxZQUFZO0FBQUEsTUFDVixZQUFZO0FBQUEsTUFDWixpQkFBaUI7QUFBQSxNQUNqQixjQUFjO0FBQUEsTUFDZCxTQUFTO0FBQUEsTUFDVCxVQUFVO0FBQUEsTUFDVixNQUFNO0FBQUEsTUFDTixnQkFBZ0I7QUFBQSxNQUNoQixTQUFTO0FBQUEsTUFDVCxLQUFLO0FBQUEsUUFDSCxNQUFNO0FBQUEsUUFDTixZQUFZO0FBQUEsTUFDZDtBQUFBLE1BQ0EsUUFBUTtBQUFBLFFBQ04saUJBQWlCO0FBQUEsTUFDbkI7QUFBQSxNQUNBLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQSxPQUFPO0FBQUEsTUFDTCxTQUFTO0FBQUEsTUFDVCxPQUFPO0FBQUEsTUFDUCxPQUFPO0FBQUEsUUFDTCxPQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxlQUFlOyIsIm5hbWVzIjpbXX0=