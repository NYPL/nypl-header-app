import { headerBlack, headerDarkBlue, headerFocus } from "/theme/header.ts";
const HeaderLoginButton = {
  baseStyle: ({ isOpen }) => ({
    alignItems: { base: "center" },
    bg: {
      base: isOpen ? headerBlack : "ui.white",
      mh: isOpen ? headerDarkBlue : "ui.white"
    },
    borderRadius: "none",
    color: isOpen ? "ui.white" : "ui.black",
    display: "flex",
    fontFamily: "body",
    fontSize: "desktop.body.body2",
    fontWeight: "medium",
    justifyContent: "center",
    minHeight: { mh: "auto" },
    paddingY: { mh: "10px" },
    svg: {
      fill: isOpen ? "ui.white" : null,
      marginLeft: { base: "0px", mh: "5px" },
      marginTop: { base: "0" }
    },
    textDecoration: "none",
    textTransform: "inherit",
    _hover: {
      backgroundColor: {
        base: isOpen ? headerBlack : "transparent",
        mh: isOpen ? headerDarkBlue : "transparent"
      },
      color: isOpen ? "ui.white" : "initial",
      svg: {
        fill: isOpen ? "ui.white" : "ui.black"
      },
      textDecoration: "none"
    },
    _focus: headerFocus,
    _dark: {
      bg: {
        base: isOpen ? headerBlack : "transparent",
        mh: isOpen ? headerDarkBlue : "transparent"
      },
      color: "dark.ui.typography.heading",
      svg: {
        fill: isOpen ? "dark.ui.typography.heading" : null
      },
      _hover: {
        svg: {
          fill: "dark.ui.typography.heading"
        }
      }
    }
  })
};
export default HeaderLoginButton;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlckxvZ2luQnV0dG9uLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGhlYWRlckJsYWNrLCBoZWFkZXJEYXJrQmx1ZSwgaGVhZGVyRm9jdXMgfSBmcm9tIFwiLi9oZWFkZXJcIjtcblxuY29uc3QgSGVhZGVyTG9naW5CdXR0b24gPSB7XG4gIGJhc2VTdHlsZTogKHsgaXNPcGVuIH0pID0+ICh7XG4gICAgYWxpZ25JdGVtczogeyBiYXNlOiBcImNlbnRlclwiIH0sXG4gICAgYmc6IHtcbiAgICAgIGJhc2U6IGlzT3BlbiA/IGhlYWRlckJsYWNrIDogXCJ1aS53aGl0ZVwiLFxuICAgICAgbWg6IGlzT3BlbiA/IGhlYWRlckRhcmtCbHVlIDogXCJ1aS53aGl0ZVwiLFxuICAgIH0sXG4gICAgYm9yZGVyUmFkaXVzOiBcIm5vbmVcIixcbiAgICBjb2xvcjogaXNPcGVuID8gXCJ1aS53aGl0ZVwiIDogXCJ1aS5ibGFja1wiLFxuICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgIGZvbnRGYW1pbHk6IFwiYm9keVwiLFxuICAgIGZvbnRTaXplOiBcImRlc2t0b3AuYm9keS5ib2R5MlwiLFxuICAgIGZvbnRXZWlnaHQ6IFwibWVkaXVtXCIsXG4gICAganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIsXG4gICAgbWluSGVpZ2h0OiB7IG1oOiBcImF1dG9cIiB9LFxuICAgIHBhZGRpbmdZOiB7IG1oOiBcIjEwcHhcIiB9LFxuICAgIHN2Zzoge1xuICAgICAgZmlsbDogaXNPcGVuID8gXCJ1aS53aGl0ZVwiIDogbnVsbCxcbiAgICAgIG1hcmdpbkxlZnQ6IHsgYmFzZTogXCIwcHhcIiwgbWg6IFwiNXB4XCIgfSxcbiAgICAgIG1hcmdpblRvcDogeyBiYXNlOiBcIjBcIiB9LFxuICAgIH0sXG4gICAgdGV4dERlY29yYXRpb246IFwibm9uZVwiLFxuICAgIHRleHRUcmFuc2Zvcm06IFwiaW5oZXJpdFwiLFxuICAgIF9ob3Zlcjoge1xuICAgICAgYmFja2dyb3VuZENvbG9yOiB7XG4gICAgICAgIGJhc2U6IGlzT3BlbiA/IGhlYWRlckJsYWNrIDogXCJ0cmFuc3BhcmVudFwiLFxuICAgICAgICBtaDogaXNPcGVuID8gaGVhZGVyRGFya0JsdWUgOiBcInRyYW5zcGFyZW50XCIsXG4gICAgICB9LFxuICAgICAgY29sb3I6IGlzT3BlbiA/IFwidWkud2hpdGVcIiA6IFwiaW5pdGlhbFwiLFxuICAgICAgc3ZnOiB7XG4gICAgICAgIGZpbGw6IGlzT3BlbiA/IFwidWkud2hpdGVcIiA6IFwidWkuYmxhY2tcIixcbiAgICAgIH0sXG4gICAgICB0ZXh0RGVjb3JhdGlvbjogXCJub25lXCIsXG4gICAgfSxcbiAgICBfZm9jdXM6IGhlYWRlckZvY3VzLFxuICAgIF9kYXJrOiB7XG4gICAgICBiZzoge1xuICAgICAgICBiYXNlOiBpc09wZW4gPyBoZWFkZXJCbGFjayA6IFwidHJhbnNwYXJlbnRcIixcbiAgICAgICAgbWg6IGlzT3BlbiA/IGhlYWRlckRhcmtCbHVlIDogXCJ0cmFuc3BhcmVudFwiLFxuICAgICAgfSxcbiAgICAgIGNvbG9yOiBcImRhcmsudWkudHlwb2dyYXBoeS5oZWFkaW5nXCIsXG4gICAgICBzdmc6IHtcbiAgICAgICAgZmlsbDogaXNPcGVuID8gXCJkYXJrLnVpLnR5cG9ncmFwaHkuaGVhZGluZ1wiIDogbnVsbCxcbiAgICAgIH0sXG4gICAgICBfaG92ZXI6IHtcbiAgICAgICAgc3ZnOiB7XG4gICAgICAgICAgZmlsbDogXCJkYXJrLnVpLnR5cG9ncmFwaHkuaGVhZGluZ1wiLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9LFxuICB9KSxcbn07XG5cbmV4cG9ydCBkZWZhdWx0IEhlYWRlckxvZ2luQnV0dG9uO1xuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLGFBQWEsZ0JBQWdCLG1CQUFtQjtBQUV6RCxNQUFNLG9CQUFvQjtBQUFBLEVBQ3hCLFdBQVcsQ0FBQyxFQUFFLE9BQU8sT0FBTztBQUFBLElBQzFCLFlBQVksRUFBRSxNQUFNLFNBQVM7QUFBQSxJQUM3QixJQUFJO0FBQUEsTUFDRixNQUFNLFNBQVMsY0FBYztBQUFBLE1BQzdCLElBQUksU0FBUyxpQkFBaUI7QUFBQSxJQUNoQztBQUFBLElBQ0EsY0FBYztBQUFBLElBQ2QsT0FBTyxTQUFTLGFBQWE7QUFBQSxJQUM3QixTQUFTO0FBQUEsSUFDVCxZQUFZO0FBQUEsSUFDWixVQUFVO0FBQUEsSUFDVixZQUFZO0FBQUEsSUFDWixnQkFBZ0I7QUFBQSxJQUNoQixXQUFXLEVBQUUsSUFBSSxPQUFPO0FBQUEsSUFDeEIsVUFBVSxFQUFFLElBQUksT0FBTztBQUFBLElBQ3ZCLEtBQUs7QUFBQSxNQUNILE1BQU0sU0FBUyxhQUFhO0FBQUEsTUFDNUIsWUFBWSxFQUFFLE1BQU0sT0FBTyxJQUFJLE1BQU07QUFBQSxNQUNyQyxXQUFXLEVBQUUsTUFBTSxJQUFJO0FBQUEsSUFDekI7QUFBQSxJQUNBLGdCQUFnQjtBQUFBLElBQ2hCLGVBQWU7QUFBQSxJQUNmLFFBQVE7QUFBQSxNQUNOLGlCQUFpQjtBQUFBLFFBQ2YsTUFBTSxTQUFTLGNBQWM7QUFBQSxRQUM3QixJQUFJLFNBQVMsaUJBQWlCO0FBQUEsTUFDaEM7QUFBQSxNQUNBLE9BQU8sU0FBUyxhQUFhO0FBQUEsTUFDN0IsS0FBSztBQUFBLFFBQ0gsTUFBTSxTQUFTLGFBQWE7QUFBQSxNQUM5QjtBQUFBLE1BQ0EsZ0JBQWdCO0FBQUEsSUFDbEI7QUFBQSxJQUNBLFFBQVE7QUFBQSxJQUNSLE9BQU87QUFBQSxNQUNMLElBQUk7QUFBQSxRQUNGLE1BQU0sU0FBUyxjQUFjO0FBQUEsUUFDN0IsSUFBSSxTQUFTLGlCQUFpQjtBQUFBLE1BQ2hDO0FBQUEsTUFDQSxPQUFPO0FBQUEsTUFDUCxLQUFLO0FBQUEsUUFDSCxNQUFNLFNBQVMsK0JBQStCO0FBQUEsTUFDaEQ7QUFBQSxNQUNBLFFBQVE7QUFBQSxRQUNOLEtBQUs7QUFBQSxVQUNILE1BQU07QUFBQSxRQUNSO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxlQUFlOyIsIm5hbWVzIjpbXX0=