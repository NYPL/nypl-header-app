import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/header/HeaderApp.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/chrismulholland/Sites/tests/nypl-header-app/src/header/HeaderApp.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { DSProvider } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@nypl_design-system-react-components.js?v=f372bde6";
import Header from "/components/Header/Header.tsx";
import theme from "/theme/index.ts";
const HeaderApp = ({
  isTestMode = false
}) => {
  return /* @__PURE__ */ jsxDEV(DSProvider, { resetCSS: false, disableGlobalStyle: true, theme, children: /* @__PURE__ */ jsxDEV(Header, { fetchSitewideAlerts: !isTestMode, isProduction: !isTestMode }, void 0, false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/header/HeaderApp.tsx",
    lineNumber: 8,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/header/HeaderApp.tsx",
    lineNumber: 7,
    columnNumber: 10
  }, this);
};
_c = HeaderApp;
export default HeaderApp;
var _c;
$RefreshReg$(_c, "HeaderApp");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chrismulholland/Sites/tests/nypl-header-app/src/header/HeaderApp.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBT007QUFQTiwyQkFBMkI7QUFBQTtBQUFBLElBQXNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2pFLE9BQU9BLFlBQVk7QUFDbkIsT0FBT0MsV0FBVztBQUVsQixNQUFNQyxZQUFpQkEsQ0FBQztBQUFBLEVBQUVDLGFBQWE7QUFBTSxNQUFXO0FBQ3RELFNBQ0UsdUJBQUMsY0FBVyxVQUFVLE9BQU8sb0JBQWtCLE1BQUMsT0FDOUMsaUNBQUMsVUFBTyxxQkFBcUIsQ0FBQ0EsWUFBWSxjQUFjLENBQUNBLGNBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBb0UsS0FEdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRUo7QUFBRUMsS0FOSUY7QUFRTixlQUFlQTtBQUFVLElBQUFFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJIZWFkZXIiLCJ0aGVtZSIsIkhlYWRlckFwcCIsImlzVGVzdE1vZGUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkhlYWRlckFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRFNQcm92aWRlciB9IGZyb20gXCJAbnlwbC9kZXNpZ24tc3lzdGVtLXJlYWN0LWNvbXBvbmVudHNcIjtcbmltcG9ydCBIZWFkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvSGVhZGVyL0hlYWRlclwiO1xuaW1wb3J0IHRoZW1lIGZyb20gXCIuLi90aGVtZVwiO1xuXG5jb25zdCBIZWFkZXJBcHA6IGFueSA9ICh7IGlzVGVzdE1vZGUgPSBmYWxzZSB9KTogYW55ID0+IHtcbiAgcmV0dXJuIChcbiAgICA8RFNQcm92aWRlciByZXNldENTUz17ZmFsc2V9IGRpc2FibGVHbG9iYWxTdHlsZSB0aGVtZT17dGhlbWV9PlxuICAgICAgPEhlYWRlciBmZXRjaFNpdGV3aWRlQWxlcnRzPXshaXNUZXN0TW9kZX0gaXNQcm9kdWN0aW9uPXshaXNUZXN0TW9kZX0gLz5cbiAgICA8L0RTUHJvdmlkZXI+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBIZWFkZXJBcHA7XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaHJpc211bGhvbGxhbmQvU2l0ZXMvdGVzdHMvbnlwbC1oZWFkZXItYXBwL3NyYy9oZWFkZXIvSGVhZGVyQXBwLnRzeCJ9