import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import __vite__cjsImport1_reactDom from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/react-dom.js?v=8d2ed4c6"; const ReactDOM = __vite__cjsImport1_reactDom.__esModule ? __vite__cjsImport1_reactDom.default : __vite__cjsImport1_reactDom;
import HeaderApp from "/header/HeaderApp.tsx";
ReactDOM.render(/* @__PURE__ */ jsxDEV(HeaderApp, {}, void 0, false, {
  fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/header/localRender.tsx",
  lineNumber: 4,
  columnNumber: 17
}, this), document.getElementById("root"));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS0U7QUFKRixPQUFPQSxjQUFjO0FBQ3JCLE9BQU9DLGVBQWU7QUFFdEJELFNBQVNFLE9BQ1AsdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BQVUsR0FDVkMsU0FBU0MsZUFBZSxNQUFNLENBQ2hDIiwibmFtZXMiOlsiUmVhY3RET00iLCJIZWFkZXJBcHAiLCJyZW5kZXIiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIl0sInNvdXJjZXMiOlsibG9jYWxSZW5kZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCBSZWFjdERPTSBmcm9tICdyZWFjdC1kb20nXG5pbXBvcnQgSGVhZGVyQXBwIGZyb20gJy4vSGVhZGVyQXBwJ1xuXG5SZWFjdERPTS5yZW5kZXIoXG4gIDxIZWFkZXJBcHAgLz4sXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyb290JykgYXMgYW55XG4pO1xuIl0sImZpbGUiOiIvVXNlcnMvY2hyaXNtdWxob2xsYW5kL1NpdGVzL3Rlc3RzL255cGwtaGVhZGVyLWFwcC9zcmMvaGVhZGVyL2xvY2FsUmVuZGVyLnRzeCJ9