export const headerBlack = "#2b2b2b";
export const headerBlue = "#1B7FA7";
export const headerDarkBlue = "#135772";
export const headerFocusColor = "#0F465C";
export const headerLightBlue = "#78CCED";
export const headerLightBlueIcon = "#1DA1D4";
export const headerRed = "#ED1C24";
export const headerRedDarkMode = "dark.ui.error.primary";
export const headerRedDonate = "#E32B31";
export const headerYellow = "#FEE34A";
export const headerYellowDark = "#403B2D";
export const headerFocus = {
  borderRadius: "none",
  outlineColor: `${headerDarkBlue} !important`,
  outlineOffset: "0 !important",
  outlineStyle: "solid !important",
  outlineWidth: "0.25em !important"
};
const Header = {
  parts: ["container", "horizontalRule", "logo", "navContainer"],
  baseStyle: {
    fontFamily: "body",
    fontSize: "text.default",
    fontWeight: "text.default",
    "& *, & ::before, & ::after": {
      borderWidth: "0px",
      borderStyle: "solid",
      boxSizing: "border-box"
    },
    "& > nav li": { marginBottom: "0 !important" },
    "& > nav a": {
      _focus: {
        boxShadow: "none",
        outline: "2px solid",
        outlineOffset: "2px",
        outlineColor: "ui.focus",
        zIndex: "9999",
        _dark: {
          outlineColor: "dark.ui.focus"
        }
      }
    },
    a: {
      _visited: {
        color: "ui.typography.body"
      }
    },
    button: {
      cursor: "pointer"
    },
    container: {
      paddingX: { base: "8px", mh: "16px" },
      paddingY: { mh: "16px" },
      maxWidth: "1280px",
      minHeight: { mh: "122x" },
      margin: "0 auto"
    },
    navContainer: {
      height: { mh: "80px", lh: "97px" },
      gap: { mh: "s", lh: "35px" }
    },
    horizontalRule: {
      bg: "brand.primary",
      marginTop: "0",
      marginBottom: "0",
      _dark: {
        backgroundColor: "dark.brand.primary"
      }
    },
    logo: {
      lineHeight: "0",
      svg: {
        height: { base: "40px", mh: "74px", lh: "97px" }
      },
      _focus: headerFocus
    }
  }
};
export default Header;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgaGVhZGVyQmxhY2sgPSBcIiMyYjJiMmJcIjtcbmV4cG9ydCBjb25zdCBoZWFkZXJCbHVlID0gXCIjMUI3RkE3XCI7XG5leHBvcnQgY29uc3QgaGVhZGVyRGFya0JsdWUgPSBcIiMxMzU3NzJcIjtcbmV4cG9ydCBjb25zdCBoZWFkZXJGb2N1c0NvbG9yID0gXCIjMEY0NjVDXCI7XG5leHBvcnQgY29uc3QgaGVhZGVyTGlnaHRCbHVlID0gXCIjNzhDQ0VEXCI7XG5leHBvcnQgY29uc3QgaGVhZGVyTGlnaHRCbHVlSWNvbiA9IFwiIzFEQTFENFwiO1xuZXhwb3J0IGNvbnN0IGhlYWRlclJlZCA9IFwiI0VEMUMyNFwiO1xuZXhwb3J0IGNvbnN0IGhlYWRlclJlZERhcmtNb2RlID0gXCJkYXJrLnVpLmVycm9yLnByaW1hcnlcIjtcbmV4cG9ydCBjb25zdCBoZWFkZXJSZWREb25hdGUgPSBcIiNFMzJCMzFcIjtcbmV4cG9ydCBjb25zdCBoZWFkZXJZZWxsb3cgPSBcIiNGRUUzNEFcIjtcbmV4cG9ydCBjb25zdCBoZWFkZXJZZWxsb3dEYXJrID0gXCIjNDAzQjJEXCI7XG5leHBvcnQgY29uc3QgaGVhZGVyRm9jdXMgPSB7XG4gIGJvcmRlclJhZGl1czogXCJub25lXCIsXG4gIG91dGxpbmVDb2xvcjogYCR7aGVhZGVyRGFya0JsdWV9ICFpbXBvcnRhbnRgLFxuICBvdXRsaW5lT2Zmc2V0OiBcIjAgIWltcG9ydGFudFwiLFxuICBvdXRsaW5lU3R5bGU6IFwic29saWQgIWltcG9ydGFudFwiLFxuICBvdXRsaW5lV2lkdGg6IFwiMC4yNWVtICFpbXBvcnRhbnRcIixcbn07XG5cbmNvbnN0IEhlYWRlciA9IHtcbiAgcGFydHM6IFtcImNvbnRhaW5lclwiLCBcImhvcml6b250YWxSdWxlXCIsIFwibG9nb1wiLCBcIm5hdkNvbnRhaW5lclwiXSxcbiAgYmFzZVN0eWxlOiB7XG4gICAgZm9udEZhbWlseTogXCJib2R5XCIsXG4gICAgZm9udFNpemU6IFwidGV4dC5kZWZhdWx0XCIsXG4gICAgZm9udFdlaWdodDogXCJ0ZXh0LmRlZmF1bHRcIixcbiAgICBcIiYgKiwgJiA6OmJlZm9yZSwgJiA6OmFmdGVyXCI6IHtcbiAgICAgIGJvcmRlcldpZHRoOiBcIjBweFwiLFxuICAgICAgYm9yZGVyU3R5bGU6IFwic29saWRcIixcbiAgICAgIGJveFNpemluZzogXCJib3JkZXItYm94XCIsXG4gICAgfSxcbiAgICBcIiYgPiBuYXYgbGlcIjogeyBtYXJnaW5Cb3R0b206IFwiMCAhaW1wb3J0YW50XCIgfSxcbiAgICBcIiYgPiBuYXYgYVwiOiB7XG4gICAgICBfZm9jdXM6IHtcbiAgICAgICAgYm94U2hhZG93OiBcIm5vbmVcIixcbiAgICAgICAgb3V0bGluZTogXCIycHggc29saWRcIixcbiAgICAgICAgb3V0bGluZU9mZnNldDogXCIycHhcIixcbiAgICAgICAgb3V0bGluZUNvbG9yOiBcInVpLmZvY3VzXCIsXG4gICAgICAgIHpJbmRleDogXCI5OTk5XCIsXG4gICAgICAgIF9kYXJrOiB7XG4gICAgICAgICAgb3V0bGluZUNvbG9yOiBcImRhcmsudWkuZm9jdXNcIixcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhOiB7XG4gICAgICBfdmlzaXRlZDoge1xuICAgICAgICBjb2xvcjogXCJ1aS50eXBvZ3JhcGh5LmJvZHlcIixcbiAgICAgIH0sXG4gICAgfSxcbiAgICBidXR0b246IHtcbiAgICAgIGN1cnNvcjogXCJwb2ludGVyXCIsXG4gICAgfSxcbiAgICBjb250YWluZXI6IHtcbiAgICAgIHBhZGRpbmdYOiB7IGJhc2U6IFwiOHB4XCIsIG1oOiBcIjE2cHhcIiB9LFxuICAgICAgcGFkZGluZ1k6IHsgbWg6IFwiMTZweFwiIH0sXG4gICAgICBtYXhXaWR0aDogXCIxMjgwcHhcIixcbiAgICAgIG1pbkhlaWdodDogeyBtaDogXCIxMjJ4XCIgfSxcbiAgICAgIG1hcmdpbjogXCIwIGF1dG9cIixcbiAgICB9LFxuICAgIG5hdkNvbnRhaW5lcjoge1xuICAgICAgaGVpZ2h0OiB7IG1oOiBcIjgwcHhcIiwgbGg6IFwiOTdweFwiIH0sXG4gICAgICBnYXA6IHsgbWg6IFwic1wiLCBsaDogXCIzNXB4XCIgfSxcbiAgICB9LFxuICAgIGhvcml6b250YWxSdWxlOiB7XG4gICAgICBiZzogXCJicmFuZC5wcmltYXJ5XCIsXG4gICAgICBtYXJnaW5Ub3A6IFwiMFwiLFxuICAgICAgbWFyZ2luQm90dG9tOiBcIjBcIixcbiAgICAgIF9kYXJrOiB7XG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogXCJkYXJrLmJyYW5kLnByaW1hcnlcIixcbiAgICAgIH0sXG4gICAgfSxcbiAgICBsb2dvOiB7XG4gICAgICBsaW5lSGVpZ2h0OiBcIjBcIixcbiAgICAgIHN2Zzoge1xuICAgICAgICBoZWlnaHQ6IHsgYmFzZTogXCI0MHB4XCIsIG1oOiBcIjc0cHhcIiwgbGg6IFwiOTdweFwiIH0sXG4gICAgICB9LFxuICAgICAgX2ZvY3VzOiBoZWFkZXJGb2N1cyxcbiAgICB9LFxuICB9LFxufTtcblxuZXhwb3J0IGRlZmF1bHQgSGVhZGVyO1xuIl0sIm1hcHBpbmdzIjoiQUFBTyxhQUFNLGNBQWM7QUFDcEIsYUFBTSxhQUFhO0FBQ25CLGFBQU0saUJBQWlCO0FBQ3ZCLGFBQU0sbUJBQW1CO0FBQ3pCLGFBQU0sa0JBQWtCO0FBQ3hCLGFBQU0sc0JBQXNCO0FBQzVCLGFBQU0sWUFBWTtBQUNsQixhQUFNLG9CQUFvQjtBQUMxQixhQUFNLGtCQUFrQjtBQUN4QixhQUFNLGVBQWU7QUFDckIsYUFBTSxtQkFBbUI7QUFDekIsYUFBTSxjQUFjO0FBQUEsRUFDekIsY0FBYztBQUFBLEVBQ2QsY0FBYyxHQUFHLGNBQWM7QUFBQSxFQUMvQixlQUFlO0FBQUEsRUFDZixjQUFjO0FBQUEsRUFDZCxjQUFjO0FBQ2hCO0FBRUEsTUFBTSxTQUFTO0FBQUEsRUFDYixPQUFPLENBQUMsYUFBYSxrQkFBa0IsUUFBUSxjQUFjO0FBQUEsRUFDN0QsV0FBVztBQUFBLElBQ1QsWUFBWTtBQUFBLElBQ1osVUFBVTtBQUFBLElBQ1YsWUFBWTtBQUFBLElBQ1osOEJBQThCO0FBQUEsTUFDNUIsYUFBYTtBQUFBLE1BQ2IsYUFBYTtBQUFBLE1BQ2IsV0FBVztBQUFBLElBQ2I7QUFBQSxJQUNBLGNBQWMsRUFBRSxjQUFjLGVBQWU7QUFBQSxJQUM3QyxhQUFhO0FBQUEsTUFDWCxRQUFRO0FBQUEsUUFDTixXQUFXO0FBQUEsUUFDWCxTQUFTO0FBQUEsUUFDVCxlQUFlO0FBQUEsUUFDZixjQUFjO0FBQUEsUUFDZCxRQUFRO0FBQUEsUUFDUixPQUFPO0FBQUEsVUFDTCxjQUFjO0FBQUEsUUFDaEI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLElBQ0EsR0FBRztBQUFBLE1BQ0QsVUFBVTtBQUFBLFFBQ1IsT0FBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUEsSUFDQSxRQUFRO0FBQUEsTUFDTixRQUFRO0FBQUEsSUFDVjtBQUFBLElBQ0EsV0FBVztBQUFBLE1BQ1QsVUFBVSxFQUFFLE1BQU0sT0FBTyxJQUFJLE9BQU87QUFBQSxNQUNwQyxVQUFVLEVBQUUsSUFBSSxPQUFPO0FBQUEsTUFDdkIsVUFBVTtBQUFBLE1BQ1YsV0FBVyxFQUFFLElBQUksT0FBTztBQUFBLE1BQ3hCLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQSxjQUFjO0FBQUEsTUFDWixRQUFRLEVBQUUsSUFBSSxRQUFRLElBQUksT0FBTztBQUFBLE1BQ2pDLEtBQUssRUFBRSxJQUFJLEtBQUssSUFBSSxPQUFPO0FBQUEsSUFDN0I7QUFBQSxJQUNBLGdCQUFnQjtBQUFBLE1BQ2QsSUFBSTtBQUFBLE1BQ0osV0FBVztBQUFBLE1BQ1gsY0FBYztBQUFBLE1BQ2QsT0FBTztBQUFBLFFBQ0wsaUJBQWlCO0FBQUEsTUFDbkI7QUFBQSxJQUNGO0FBQUEsSUFDQSxNQUFNO0FBQUEsTUFDSixZQUFZO0FBQUEsTUFDWixLQUFLO0FBQUEsUUFDSCxRQUFRLEVBQUUsTUFBTSxRQUFRLElBQUksUUFBUSxJQUFJLE9BQU87QUFBQSxNQUNqRDtBQUFBLE1BQ0EsUUFBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxlQUFlOyIsIm5hbWVzIjpbXX0=