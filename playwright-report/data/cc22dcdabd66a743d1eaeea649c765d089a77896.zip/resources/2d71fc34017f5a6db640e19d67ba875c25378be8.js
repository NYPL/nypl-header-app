import { headerYellow } from "/theme/header.ts";
const SitewideAlerts = {
  baseStyle: {
    backgroundColor: headerYellow,
    borderBottom: { base: "1px solid", mh: "none" },
    fontSize: "text.default",
    fontWeight: "regular",
    lineHeight: "1.1rem",
    minHeight: { base: "85px", mh: "65px" },
    paddingX: "s",
    ul: {
      marginBottom: "0",
      // Target any anchor and paragraph HTML passed in from
      // the API response in `alert.description`.
      a: {
        textDecoration: "underline"
      },
      p: {
        marginBottom: "0",
        marginTop: "0"
      },
      _dark: {
        color: "dark.ui.typography.heading",
        a: {
          color: "dark.ui.typography.heading",
          _hover: {
            color: "dark.ui.typography.heading"
          }
        }
      }
    },
    _dark: {
      backgroundColor: "dark.ui.bg.active",
      borderBottom: "1px solid",
      borderColor: "dark.ui.status.primary",
      color: "dark.ui.typography.heading"
    }
  }
};
export default SitewideAlerts;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlclNpdGV3aWRlQWxlcnRzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGhlYWRlclllbGxvdyB9IGZyb20gXCIuL2hlYWRlclwiO1xuXG5jb25zdCBTaXRld2lkZUFsZXJ0cyA9IHtcbiAgYmFzZVN0eWxlOiB7XG4gICAgYmFja2dyb3VuZENvbG9yOiBoZWFkZXJZZWxsb3csXG4gICAgYm9yZGVyQm90dG9tOiB7IGJhc2U6IFwiMXB4IHNvbGlkXCIsIG1oOiBcIm5vbmVcIiB9LFxuICAgIGZvbnRTaXplOiBcInRleHQuZGVmYXVsdFwiLFxuICAgIGZvbnRXZWlnaHQ6IFwicmVndWxhclwiLFxuICAgIGxpbmVIZWlnaHQ6IFwiMS4xcmVtXCIsXG4gICAgbWluSGVpZ2h0OiB7IGJhc2U6IFwiODVweFwiLCBtaDogXCI2NXB4XCIgfSxcbiAgICBwYWRkaW5nWDogXCJzXCIsXG4gICAgdWw6IHtcbiAgICAgIG1hcmdpbkJvdHRvbTogXCIwXCIsXG4gICAgICAvLyBUYXJnZXQgYW55IGFuY2hvciBhbmQgcGFyYWdyYXBoIEhUTUwgcGFzc2VkIGluIGZyb21cbiAgICAgIC8vIHRoZSBBUEkgcmVzcG9uc2UgaW4gYGFsZXJ0LmRlc2NyaXB0aW9uYC5cbiAgICAgIGE6IHtcbiAgICAgICAgdGV4dERlY29yYXRpb246IFwidW5kZXJsaW5lXCIsXG4gICAgICB9LFxuICAgICAgcDoge1xuICAgICAgICBtYXJnaW5Cb3R0b206IFwiMFwiLFxuICAgICAgICBtYXJnaW5Ub3A6IFwiMFwiLFxuICAgICAgfSxcbiAgICAgIF9kYXJrOiB7XG4gICAgICAgIGNvbG9yOiBcImRhcmsudWkudHlwb2dyYXBoeS5oZWFkaW5nXCIsXG4gICAgICAgIGE6IHtcbiAgICAgICAgICBjb2xvcjogXCJkYXJrLnVpLnR5cG9ncmFwaHkuaGVhZGluZ1wiLFxuICAgICAgICAgIF9ob3Zlcjoge1xuICAgICAgICAgICAgY29sb3I6IFwiZGFyay51aS50eXBvZ3JhcGh5LmhlYWRpbmdcIixcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9LFxuICAgIF9kYXJrOiB7XG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiZGFyay51aS5iZy5hY3RpdmVcIixcbiAgICAgIGJvcmRlckJvdHRvbTogXCIxcHggc29saWRcIixcbiAgICAgIGJvcmRlckNvbG9yOiBcImRhcmsudWkuc3RhdHVzLnByaW1hcnlcIixcbiAgICAgIGNvbG9yOiBcImRhcmsudWkudHlwb2dyYXBoeS5oZWFkaW5nXCIsXG4gICAgfSxcbiAgfSxcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFNpdGV3aWRlQWxlcnRzO1xuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLG9CQUFvQjtBQUU3QixNQUFNLGlCQUFpQjtBQUFBLEVBQ3JCLFdBQVc7QUFBQSxJQUNULGlCQUFpQjtBQUFBLElBQ2pCLGNBQWMsRUFBRSxNQUFNLGFBQWEsSUFBSSxPQUFPO0FBQUEsSUFDOUMsVUFBVTtBQUFBLElBQ1YsWUFBWTtBQUFBLElBQ1osWUFBWTtBQUFBLElBQ1osV0FBVyxFQUFFLE1BQU0sUUFBUSxJQUFJLE9BQU87QUFBQSxJQUN0QyxVQUFVO0FBQUEsSUFDVixJQUFJO0FBQUEsTUFDRixjQUFjO0FBQUE7QUFBQTtBQUFBLE1BR2QsR0FBRztBQUFBLFFBQ0QsZ0JBQWdCO0FBQUEsTUFDbEI7QUFBQSxNQUNBLEdBQUc7QUFBQSxRQUNELGNBQWM7QUFBQSxRQUNkLFdBQVc7QUFBQSxNQUNiO0FBQUEsTUFDQSxPQUFPO0FBQUEsUUFDTCxPQUFPO0FBQUEsUUFDUCxHQUFHO0FBQUEsVUFDRCxPQUFPO0FBQUEsVUFDUCxRQUFRO0FBQUEsWUFDTixPQUFPO0FBQUEsVUFDVDtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLElBQ0EsT0FBTztBQUFBLE1BQ0wsaUJBQWlCO0FBQUEsTUFDakIsY0FBYztBQUFBLE1BQ2QsYUFBYTtBQUFBLE1BQ2IsT0FBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxlQUFlOyIsIm5hbWVzIjpbXX0=