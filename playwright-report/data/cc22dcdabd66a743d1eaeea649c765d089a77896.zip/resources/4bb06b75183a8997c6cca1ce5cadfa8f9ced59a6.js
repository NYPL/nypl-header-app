import { headerFocus } from "/theme/header.ts";
const HeaderMobileIconNav = {
  baseStyle: {
    button: {
      minHeight: "60px",
      minWidth: "60px"
    },
    "> a": {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      minHeight: "60px",
      minWidth: "60px",
      _focus: headerFocus
    },
    _dark: {
      svg: {
        fill: "dark.ui.typography.heading"
      }
    }
  }
};
export default HeaderMobileIconNav;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlck1vYmlsZUljb25OYXYudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgaGVhZGVyRm9jdXMgfSBmcm9tIFwiLi9oZWFkZXJcIjtcblxuY29uc3QgSGVhZGVyTW9iaWxlSWNvbk5hdiA9IHtcbiAgYmFzZVN0eWxlOiB7XG4gICAgYnV0dG9uOiB7XG4gICAgICBtaW5IZWlnaHQ6IFwiNjBweFwiLFxuICAgICAgbWluV2lkdGg6IFwiNjBweFwiLFxuICAgIH0sXG4gICAgXCI+IGFcIjoge1xuICAgICAgZGlzcGxheTogXCJmbGV4XCIsXG4gICAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxuICAgICAganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIsXG4gICAgICBtaW5IZWlnaHQ6IFwiNjBweFwiLFxuICAgICAgbWluV2lkdGg6IFwiNjBweFwiLFxuICAgICAgX2ZvY3VzOiBoZWFkZXJGb2N1cyxcbiAgICB9LFxuICAgIF9kYXJrOiB7XG4gICAgICBzdmc6IHtcbiAgICAgICAgZmlsbDogXCJkYXJrLnVpLnR5cG9ncmFwaHkuaGVhZGluZ1wiLFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxufTtcblxuZXhwb3J0IGRlZmF1bHQgSGVhZGVyTW9iaWxlSWNvbk5hdjtcbiJdLCJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFFNUIsTUFBTSxzQkFBc0I7QUFBQSxFQUMxQixXQUFXO0FBQUEsSUFDVCxRQUFRO0FBQUEsTUFDTixXQUFXO0FBQUEsTUFDWCxVQUFVO0FBQUEsSUFDWjtBQUFBLElBQ0EsT0FBTztBQUFBLE1BQ0wsU0FBUztBQUFBLE1BQ1QsWUFBWTtBQUFBLE1BQ1osZ0JBQWdCO0FBQUEsTUFDaEIsV0FBVztBQUFBLE1BQ1gsVUFBVTtBQUFBLE1BQ1YsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBLE9BQU87QUFBQSxNQUNMLEtBQUs7QUFBQSxRQUNILE1BQU07QUFBQSxNQUNSO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLGVBQWU7IiwibmFtZXMiOltdfQ==