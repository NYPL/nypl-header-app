import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f7bb76b7"; const jsxRuntime = __vite__cjsImport0_react_jsxDevRuntime
export const Fragment = jsxRuntime.Fragment
export const jsxDEV = jsxRuntime.jsxDEV