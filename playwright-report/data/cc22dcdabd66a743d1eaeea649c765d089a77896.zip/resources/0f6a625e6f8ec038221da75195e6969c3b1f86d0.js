import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/Header/components/HeaderUpperNav.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderUpperNav.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Box, chakra, useMultiStyleConfig } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@chakra-ui_react.js?v=2c813617";
import HeaderLoginButton from "/components/Header/components/HeaderLoginButton.tsx";
import { upperNavLinks } from "/components/Header/utils/headerUtils.ts";
import { List, Link } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@nypl_design-system-react-components.js?v=f372bde6";
const HeaderUpperNav = _s(chakra(_c = _s(() => {
  _s();
  const styles = useMultiStyleConfig("HeaderUpperNav", {});
  return /* @__PURE__ */ jsxDEV(Box, { as: "nav", "aria-label": "Header top links", __css: styles, children: /* @__PURE__ */ jsxDEV(List, { id: "header-nav-upper", inline: true, listItems: [/* @__PURE__ */ jsxDEV(HeaderLoginButton, {}, "login", false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderUpperNav.tsx",
    lineNumber: 17,
    columnNumber: 54
  }, this), /* @__PURE__ */ jsxDEV(Link, { href: upperNavLinks.locations.href, children: upperNavLinks.locations.text }, "locationsLink", false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderUpperNav.tsx",
    lineNumber: 17,
    columnNumber: 89
  }, this), /* @__PURE__ */ jsxDEV(Link, { href: upperNavLinks.libraryCard.href, children: upperNavLinks.libraryCard.text }, "libraryCardLink", false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderUpperNav.tsx",
    lineNumber: 19,
    columnNumber: 20
  }, this), /* @__PURE__ */ jsxDEV(Link, { href: upperNavLinks.emailUpdates.href, children: upperNavLinks.emailUpdates.text }, "emailUpdatesLink", false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderUpperNav.tsx",
    lineNumber: 21,
    columnNumber: 20
  }, this), /* @__PURE__ */ jsxDEV(Link, { href: upperNavLinks.donate.href, type: "buttonCallout", __css: styles.donateLink, children: upperNavLinks.donate.text }, "donateLink", false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderUpperNav.tsx",
    lineNumber: 23,
    columnNumber: 20
  }, this), /* @__PURE__ */ jsxDEV(Link, { href: upperNavLinks.shop.href, children: upperNavLinks.shop.text }, "shopLink", false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderUpperNav.tsx",
    lineNumber: 25,
    columnNumber: 20
  }, this)], noStyling: true, type: "ul" }, void 0, false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderUpperNav.tsx",
    lineNumber: 17,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderUpperNav.tsx",
    lineNumber: 16,
    columnNumber: 10
  }, this);
}, "4weJZXnSi/kojZCmc0wy6twR2LQ=", false, function() {
  return [useMultiStyleConfig];
})), "4weJZXnSi/kojZCmc0wy6twR2LQ=", false, function() {
  return [useMultiStyleConfig];
});
_c2 = HeaderUpperNav;
export default HeaderUpperNav;
var _c, _c2;
$RefreshReg$(_c, "HeaderUpperNav$chakra");
$RefreshReg$(_c2, "HeaderUpperNav");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderUpperNav.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJVOzs7Ozs7Ozs7Ozs7Ozs7O0FBckJWLFNBQVNBLEtBQUtDLFFBQVFDLDJCQUEyQjtBQUdqRCxPQUFPQyx1QkFBdUI7QUFDOUIsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLE1BQU1DLFlBQWtCO0FBT2pDLE1BQU1DLGlCQUFjQyxHQUFHUCxPQUFNUSxLQUFBRCxHQUFDLE1BQU07QUFBQUEsS0FBQTtBQUNsQyxRQUFNRSxTQUFTUixvQkFBb0Isa0JBQWtCLENBQUMsQ0FBQztBQUV2RCxTQUNFLHVCQUFDLE9BQUksSUFBRyxPQUFNLGNBQVcsb0JBQW1CLE9BQU9RLFFBQ2pELGlDQUFDLFFBQ0MsSUFBRyxvQkFDSCxRQUFNLE1BQ04sV0FBVyxDQUNULHVCQUFDLHVCQUFzQixTQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQThCLEdBQzlCLHVCQUFDLFFBQUssTUFBTU4sY0FBY08sVUFBVUMsTUFDakNSLHdCQUFjTyxVQUFVRSxRQURtQixpQkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBLEdBQ0EsdUJBQUMsUUFBSyxNQUFNVCxjQUFjVSxZQUFZRixNQUNuQ1Isd0JBQWNVLFlBQVlELFFBRG1CLG1CQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUEsR0FDQSx1QkFBQyxRQUFLLE1BQU1ULGNBQWNXLGFBQWFILE1BQ3BDUix3QkFBY1csYUFBYUYsUUFEbUIsb0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQSxHQUNBLHVCQUFDLFFBQ0MsTUFBTVQsY0FBY1ksT0FBT0osTUFFM0IsTUFBSyxpQkFDTCxPQUFPRixPQUFPTyxZQUViYix3QkFBY1ksT0FBT0gsUUFKbEIsY0FGTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0EsR0FDQSx1QkFBQyxRQUFLLE1BQU1ULGNBQWNjLEtBQUtOLE1BQzVCUix3QkFBY2MsS0FBS0wsUUFEbUIsWUFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBLENBQU8sR0FFVCxXQUFTLE1BQ1QsTUFBSyxRQTNCUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMkJXLEtBNUJiO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4QkE7QUFFSixHQUFDO0FBQUEsVUFuQ2dCWCxtQkFBbUI7QUFBQSxFQW1DbkMsR0FBQztBQUFBLFVBbkNlQSxtQkFBbUI7QUFBQTtBQW1DakNpQixNQXBDR1o7QUFzQ04sZUFBZUE7QUFBZSxJQUFBRSxJQUFBVTtBQUFBQyxhQUFBWCxJQUFBO0FBQUFXLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJCb3giLCJjaGFrcmEiLCJ1c2VNdWx0aVN0eWxlQ29uZmlnIiwiSGVhZGVyTG9naW5CdXR0b24iLCJ1cHBlck5hdkxpbmtzIiwiTGlzdCIsIkxpbmsiLCJIZWFkZXJVcHBlck5hdiIsIl9zIiwiX2MiLCJzdHlsZXMiLCJsb2NhdGlvbnMiLCJocmVmIiwidGV4dCIsImxpYnJhcnlDYXJkIiwiZW1haWxVcGRhdGVzIiwiZG9uYXRlIiwiZG9uYXRlTGluayIsInNob3AiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJIZWFkZXJVcHBlck5hdi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQm94LCBjaGFrcmEsIHVzZU11bHRpU3R5bGVDb25maWcgfSBmcm9tIFwiQGNoYWtyYS11aS9yZWFjdFwiO1xuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuXG5pbXBvcnQgSGVhZGVyTG9naW5CdXR0b24gZnJvbSBcIi4vSGVhZGVyTG9naW5CdXR0b25cIjtcbmltcG9ydCB7IHVwcGVyTmF2TGlua3MgfSBmcm9tIFwiLi4vdXRpbHMvaGVhZGVyVXRpbHNcIjtcbmltcG9ydCB7IExpc3QsIExpbmssIEljb24gfSBmcm9tIFwiQG55cGwvZGVzaWduLXN5c3RlbS1yZWFjdC1jb21wb25lbnRzXCI7XG5cbi8qKlxuICogVGhpcyByZW5kZXJzIHRoZSBuYXZpZ2F0aW9uYWwgbGlzdCBvZiBsaW5rcyBmb3IgbG9nZ2luZyBpbiwgc3Vic2NyaWJpbmdcbiAqIHRvIHRoZSBlbWFpbCBzZXJ2aWNlLCBnb2luZyB0byB0aGUgTG9jYXRpb25zIHBhZ2UsIGdldHRpbmcgYSBMaWJyYXJ5IGNhcmQsXG4gKiBkb25hdGluZywgYW5kIHNob3BwaW5nIGF0IE5ZUEwuXG4gKi9cbmNvbnN0IEhlYWRlclVwcGVyTmF2ID0gY2hha3JhKCgpID0+IHtcbiAgY29uc3Qgc3R5bGVzID0gdXNlTXVsdGlTdHlsZUNvbmZpZyhcIkhlYWRlclVwcGVyTmF2XCIsIHt9KTtcblxuICByZXR1cm4gKFxuICAgIDxCb3ggYXM9XCJuYXZcIiBhcmlhLWxhYmVsPVwiSGVhZGVyIHRvcCBsaW5rc1wiIF9fY3NzPXtzdHlsZXN9PlxuICAgICAgPExpc3RcbiAgICAgICAgaWQ9XCJoZWFkZXItbmF2LXVwcGVyXCJcbiAgICAgICAgaW5saW5lXG4gICAgICAgIGxpc3RJdGVtcz17W1xuICAgICAgICAgIDxIZWFkZXJMb2dpbkJ1dHRvbiBrZXk9XCJsb2dpblwiIC8+LFxuICAgICAgICAgIDxMaW5rIGhyZWY9e3VwcGVyTmF2TGlua3MubG9jYXRpb25zLmhyZWZ9IGtleT1cImxvY2F0aW9uc0xpbmtcIj5cbiAgICAgICAgICAgIHt1cHBlck5hdkxpbmtzLmxvY2F0aW9ucy50ZXh0fVxuICAgICAgICAgIDwvTGluaz4sXG4gICAgICAgICAgPExpbmsgaHJlZj17dXBwZXJOYXZMaW5rcy5saWJyYXJ5Q2FyZC5ocmVmfSBrZXk9XCJsaWJyYXJ5Q2FyZExpbmtcIj5cbiAgICAgICAgICAgIHt1cHBlck5hdkxpbmtzLmxpYnJhcnlDYXJkLnRleHR9XG4gICAgICAgICAgPC9MaW5rPixcbiAgICAgICAgICA8TGluayBocmVmPXt1cHBlck5hdkxpbmtzLmVtYWlsVXBkYXRlcy5ocmVmfSBrZXk9XCJlbWFpbFVwZGF0ZXNMaW5rXCI+XG4gICAgICAgICAgICB7dXBwZXJOYXZMaW5rcy5lbWFpbFVwZGF0ZXMudGV4dH1cbiAgICAgICAgICA8L0xpbms+LFxuICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICBocmVmPXt1cHBlck5hdkxpbmtzLmRvbmF0ZS5ocmVmfVxuICAgICAgICAgICAga2V5PVwiZG9uYXRlTGlua1wiXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uQ2FsbG91dFwiXG4gICAgICAgICAgICBfX2Nzcz17c3R5bGVzLmRvbmF0ZUxpbmt9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge3VwcGVyTmF2TGlua3MuZG9uYXRlLnRleHR9XG4gICAgICAgICAgPC9MaW5rPixcbiAgICAgICAgICA8TGluayBocmVmPXt1cHBlck5hdkxpbmtzLnNob3AuaHJlZn0ga2V5PVwic2hvcExpbmtcIj5cbiAgICAgICAgICAgIHt1cHBlck5hdkxpbmtzLnNob3AudGV4dH1cbiAgICAgICAgICA8L0xpbms+LFxuICAgICAgICBdfVxuICAgICAgICBub1N0eWxpbmdcbiAgICAgICAgdHlwZT1cInVsXCJcbiAgICAgIC8+XG4gICAgPC9Cb3g+XG4gICk7XG59KTtcblxuZXhwb3J0IGRlZmF1bHQgSGVhZGVyVXBwZXJOYXY7XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaHJpc211bGhvbGxhbmQvU2l0ZXMvdGVzdHMvbnlwbC1oZWFkZXItYXBwL3NyYy9jb21wb25lbnRzL0hlYWRlci9jb21wb25lbnRzL0hlYWRlclVwcGVyTmF2LnRzeCJ9