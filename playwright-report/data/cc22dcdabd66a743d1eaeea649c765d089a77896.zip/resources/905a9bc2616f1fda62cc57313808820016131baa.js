import {
  require_react_dom
} from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/chunk-HAIV5P5B.js?v=a76f6c0d";
import "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/chunk-OU2QLVNP.js?v=a76f6c0d";
import "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/chunk-ROME4SDB.js?v=a76f6c0d";
export default require_react_dom();
//# sourceMappingURL=react-dom.js.map
