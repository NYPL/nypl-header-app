import { headerFocus, headerRed, headerRedDarkMode } from "/theme/header.ts";
const linkFocusHoverStyles = {
  borderBottom: "3px solid",
  color: headerRed,
  paddingBottom: "2px",
  textDecoration: "none",
  _dark: {
    color: headerRedDarkMode
  }
};
const HeaderLowerNav = {
  baseStyle: {
    ul: {
      alignItems: "center",
      marginBottom: "0",
      marginLeft: "auto",
      whiteSpace: "nowrap"
    },
    li: {
      marginEnd: { mh: "s", xl: "m" },
      _last: {
        marginRight: "0"
      }
    },
    "li > a": {
      color: "ui.black",
      fontSize: {
        base: "var(--nypl-fontSizes-desktop-subtitle-subtitle2) !important",
        lh: "desktop.subtitle.subtTitle1"
      },
      fontWeight: "medium",
      textDecoration: "none",
      _hover: linkFocusHoverStyles,
      _focus: {
        ...headerFocus,
        ...linkFocusHoverStyles
      },
      _dark: {
        color: "dark.ui.typography.heading",
        _hover: linkFocusHoverStyles,
        _focus: {
          ...headerFocus,
          ...linkFocusHoverStyles
        }
      }
    }
  }
};
export default HeaderLowerNav;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlckxvd2VyTmF2LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGhlYWRlckZvY3VzLCBoZWFkZXJSZWQsIGhlYWRlclJlZERhcmtNb2RlIH0gZnJvbSBcIi4vaGVhZGVyXCI7XG5cbmNvbnN0IGxpbmtGb2N1c0hvdmVyU3R5bGVzID0ge1xuICBib3JkZXJCb3R0b206IFwiM3B4IHNvbGlkXCIsXG4gIGNvbG9yOiBoZWFkZXJSZWQsXG4gIHBhZGRpbmdCb3R0b206IFwiMnB4XCIsXG4gIHRleHREZWNvcmF0aW9uOiBcIm5vbmVcIixcbiAgX2Rhcms6IHtcbiAgICBjb2xvcjogaGVhZGVyUmVkRGFya01vZGUsXG4gIH0sXG59O1xuXG5jb25zdCBIZWFkZXJMb3dlck5hdiA9IHtcbiAgYmFzZVN0eWxlOiB7XG4gICAgdWw6IHtcbiAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXG4gICAgICBtYXJnaW5Cb3R0b206IFwiMFwiLFxuICAgICAgbWFyZ2luTGVmdDogXCJhdXRvXCIsXG4gICAgICB3aGl0ZVNwYWNlOiBcIm5vd3JhcFwiLFxuICAgIH0sXG4gICAgbGk6IHtcbiAgICAgIG1hcmdpbkVuZDogeyBtaDogXCJzXCIsIHhsOiBcIm1cIiB9LFxuICAgICAgX2xhc3Q6IHtcbiAgICAgICAgbWFyZ2luUmlnaHQ6IFwiMFwiLFxuICAgICAgfSxcbiAgICB9LFxuICAgIFwibGkgPiBhXCI6IHtcbiAgICAgIGNvbG9yOiBcInVpLmJsYWNrXCIsXG4gICAgICBmb250U2l6ZToge1xuICAgICAgICBiYXNlOiBcInZhcigtLW55cGwtZm9udFNpemVzLWRlc2t0b3Atc3VidGl0bGUtc3VidGl0bGUyKSAhaW1wb3J0YW50XCIsXG4gICAgICAgIGxoOiBcImRlc2t0b3Auc3VidGl0bGUuc3VidFRpdGxlMVwiLFxuICAgICAgfSxcbiAgICAgIGZvbnRXZWlnaHQ6IFwibWVkaXVtXCIsXG4gICAgICB0ZXh0RGVjb3JhdGlvbjogXCJub25lXCIsXG4gICAgICBfaG92ZXI6IGxpbmtGb2N1c0hvdmVyU3R5bGVzLFxuICAgICAgX2ZvY3VzOiB7XG4gICAgICAgIC4uLmhlYWRlckZvY3VzLFxuICAgICAgICAuLi5saW5rRm9jdXNIb3ZlclN0eWxlcyxcbiAgICAgIH0sXG4gICAgICBfZGFyazoge1xuICAgICAgICBjb2xvcjogXCJkYXJrLnVpLnR5cG9ncmFwaHkuaGVhZGluZ1wiLFxuICAgICAgICBfaG92ZXI6IGxpbmtGb2N1c0hvdmVyU3R5bGVzLFxuICAgICAgICBfZm9jdXM6IHtcbiAgICAgICAgICAuLi5oZWFkZXJGb2N1cyxcbiAgICAgICAgICAuLi5saW5rRm9jdXNIb3ZlclN0eWxlcyxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbn07XG5cbmV4cG9ydCBkZWZhdWx0IEhlYWRlckxvd2VyTmF2O1xuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLGFBQWEsV0FBVyx5QkFBeUI7QUFFMUQsTUFBTSx1QkFBdUI7QUFBQSxFQUMzQixjQUFjO0FBQUEsRUFDZCxPQUFPO0FBQUEsRUFDUCxlQUFlO0FBQUEsRUFDZixnQkFBZ0I7QUFBQSxFQUNoQixPQUFPO0FBQUEsSUFDTCxPQUFPO0FBQUEsRUFDVDtBQUNGO0FBRUEsTUFBTSxpQkFBaUI7QUFBQSxFQUNyQixXQUFXO0FBQUEsSUFDVCxJQUFJO0FBQUEsTUFDRixZQUFZO0FBQUEsTUFDWixjQUFjO0FBQUEsTUFDZCxZQUFZO0FBQUEsTUFDWixZQUFZO0FBQUEsSUFDZDtBQUFBLElBQ0EsSUFBSTtBQUFBLE1BQ0YsV0FBVyxFQUFFLElBQUksS0FBSyxJQUFJLElBQUk7QUFBQSxNQUM5QixPQUFPO0FBQUEsUUFDTCxhQUFhO0FBQUEsTUFDZjtBQUFBLElBQ0Y7QUFBQSxJQUNBLFVBQVU7QUFBQSxNQUNSLE9BQU87QUFBQSxNQUNQLFVBQVU7QUFBQSxRQUNSLE1BQU07QUFBQSxRQUNOLElBQUk7QUFBQSxNQUNOO0FBQUEsTUFDQSxZQUFZO0FBQUEsTUFDWixnQkFBZ0I7QUFBQSxNQUNoQixRQUFRO0FBQUEsTUFDUixRQUFRO0FBQUEsUUFDTixHQUFHO0FBQUEsUUFDSCxHQUFHO0FBQUEsTUFDTDtBQUFBLE1BQ0EsT0FBTztBQUFBLFFBQ0wsT0FBTztBQUFBLFFBQ1AsUUFBUTtBQUFBLFFBQ1IsUUFBUTtBQUFBLFVBQ04sR0FBRztBQUFBLFVBQ0gsR0FBRztBQUFBLFFBQ0w7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLGVBQWU7IiwibmFtZXMiOltdfQ==