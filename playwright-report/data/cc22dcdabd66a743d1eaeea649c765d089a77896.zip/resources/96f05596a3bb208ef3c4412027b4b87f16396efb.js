import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/Header/components/HeaderLogin.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLogin.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/react.js?v=f7bb76b7"; const useContext = __vite__cjsImport3_react["useContext"];
import { chakra, useMultiStyleConfig, VStack } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@chakra-ui_react.js?v=2c813617";
import { getLoginLinks } from "/components/Header/utils/headerUtils.ts";
import { HeaderContext } from "/components/Header/context/headerContext.tsx";
import { List, Link, Icon } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@nypl_design-system-react-components.js?v=f372bde6";
const HeaderLogin = _s(chakra(_c = _s(({
  catalogRef,
  isMobile
}) => {
  _s();
  const {
    isProduction
  } = useContext(HeaderContext);
  const {
    catalogLink,
    researchLink
  } = getLoginLinks("", isProduction);
  const styles = useMultiStyleConfig("HeaderLogin", {
    patronName: ""
  });
  return /* @__PURE__ */ jsxDEV(VStack, { __css: styles, children: /* @__PURE__ */ jsxDEV(List, { listItems: [/* @__PURE__ */ jsxDEV(Link, { href: catalogLink, ref: catalogRef, type: "button", children: [
    /* @__PURE__ */ jsxDEV(Icon, { align: "left", color: "ui.white", name: "actionIdentity", size: isMobile ? "xlarge" : "large", title: "Go to the Catalog", sx: isMobile ? {
      height: "1.6rem",
      width: "1.6rem"
    } : {} }, void 0, false, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLogin.tsx",
      lineNumber: 34,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("span", { children: "Go To The Catalog" }, void 0, false, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLogin.tsx",
      lineNumber: 38,
      columnNumber: 13
    }, this)
  ] }, "logInCatalog", true, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLogin.tsx",
    lineNumber: 33,
    columnNumber: 25
  }, this), /* @__PURE__ */ jsxDEV(Link, { href: researchLink, type: "button", children: [
    /* @__PURE__ */ jsxDEV(Icon, { align: "left", color: "ui.white", name: "building", size: isMobile ? "xlarge" : "medium", title: "Go to the Research Catalog", sx: isMobile ? {} : {
      width: "1.6rem",
      height: "1.6rem"
    } }, void 0, false, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLogin.tsx",
      lineNumber: 40,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("span", { children: "Go To The Research Catalog" }, void 0, false, {
      fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLogin.tsx",
      lineNumber: 44,
      columnNumber: 13
    }, this)
  ] }, "logInResearch", true, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLogin.tsx",
    lineNumber: 39,
    columnNumber: 20
  }, this)], noStyling: true, type: "ul" }, void 0, false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLogin.tsx",
    lineNumber: 33,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLogin.tsx",
    lineNumber: 32,
    columnNumber: 10
  }, this);
}, "wFO7ixy1+oA/i02Kiua4879wT/s=", false, function() {
  return [useMultiStyleConfig];
})), "wFO7ixy1+oA/i02Kiua4879wT/s=", false, function() {
  return [useMultiStyleConfig];
});
_c2 = HeaderLogin;
export default HeaderLogin;
var _c, _c2;
$RefreshReg$(_c, "HeaderLogin$chakra");
$RefreshReg$(_c2, "HeaderLogin");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLogin.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0NZOzs7Ozs7Ozs7Ozs7Ozs7O0FBbENaLFNBQWdCQSxrQkFBa0I7QUFDbEMsU0FBU0MsUUFBUUMscUJBQXFCQyxjQUFjO0FBRXBELFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0MsTUFBTUMsTUFBTUMsWUFBWTtBQVlqQyxNQUFNQyxjQUFXQyxHQUFHVCxPQUFNVSxLQUFBRCxHQUFDLENBQUM7QUFBQSxFQUFFRTtBQUFBQSxFQUFZQztBQUEyQixNQUFNO0FBQUFILEtBQUE7QUFDekUsUUFBTTtBQUFBLElBQUVJO0FBQUFBLEVBQWEsSUFBSWQsV0FBV0ssYUFBYTtBQUNqRCxRQUFNO0FBQUEsSUFBRVU7QUFBQUEsSUFBYUM7QUFBQUEsRUFBYSxJQUFJWixjQUFjLElBQUlVLFlBQVk7QUFDcEUsUUFBTUcsU0FBU2Ysb0JBQW9CLGVBQWU7QUFBQSxJQUNoRGdCLFlBQVk7QUFBQSxFQUNkLENBQUM7QUFFRCxTQUNFLHVCQUFDLFVBQU8sT0FBT0QsUUFDYixpQ0FBQyxRQUNDLFdBQVcsQ0FDVCx1QkFBQyxRQUNDLE1BQU1GLGFBRU4sS0FBS0gsWUFDTCxNQUFLLFVBRUw7QUFBQSwyQkFBQyxRQUNDLE9BQU0sUUFDTixPQUFNLFlBQ04sTUFBSyxrQkFDTCxNQUFNQyxXQUFXLFdBQVcsU0FDNUIsT0FBTSxxQkFDTixJQUFJQSxXQUFXO0FBQUEsTUFBRU0sUUFBUTtBQUFBLE1BQVVDLE9BQU87QUFBQSxJQUFTLElBQUksQ0FBQyxLQU4xRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTTREO0FBQUEsSUFFNUQsdUJBQUMsVUFBSyxpQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVCO0FBQUEsT0FabkIsZ0JBRk47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWVBLEdBQ0EsdUJBQUMsUUFBSyxNQUFNSixjQUFrQyxNQUFLLFVBQ2pEO0FBQUEsMkJBQUMsUUFDQyxPQUFNLFFBQ04sT0FBTSxZQUNOLE1BQUssWUFDTCxNQUFNSCxXQUFXLFdBQVcsVUFDNUIsT0FBTSw4QkFDTixJQUFJQSxXQUFXLENBQUMsSUFBSTtBQUFBLE1BQUVPLE9BQU87QUFBQSxNQUFVRCxRQUFRO0FBQUEsSUFBUyxLQU4xRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTTREO0FBQUEsSUFFNUQsdUJBQUMsVUFBSywwQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdDO0FBQUEsT0FUSixpQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVVBLENBQU8sR0FFVCxXQUFTLE1BQ1QsTUFBSyxRQS9CUDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0JXLEtBaENiO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQ0E7QUFFSixHQUFDO0FBQUEsVUF6Q2dCakIsbUJBQW1CO0FBQUEsRUF5Q25DLEdBQUM7QUFBQSxVQXpDZUEsbUJBQW1CO0FBQUE7QUF5Q2pDbUIsTUE1Q0daO0FBOENOLGVBQWVBO0FBQVksSUFBQUUsSUFBQVU7QUFBQUMsYUFBQVgsSUFBQTtBQUFBVyxhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlQ29udGV4dCIsImNoYWtyYSIsInVzZU11bHRpU3R5bGVDb25maWciLCJWU3RhY2siLCJnZXRMb2dpbkxpbmtzIiwiSGVhZGVyQ29udGV4dCIsIkxpc3QiLCJMaW5rIiwiSWNvbiIsIkhlYWRlckxvZ2luIiwiX3MiLCJfYyIsImNhdGFsb2dSZWYiLCJpc01vYmlsZSIsImlzUHJvZHVjdGlvbiIsImNhdGFsb2dMaW5rIiwicmVzZWFyY2hMaW5rIiwic3R5bGVzIiwicGF0cm9uTmFtZSIsImhlaWdodCIsIndpZHRoIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiSGVhZGVyTG9naW4udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VDb250ZXh0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBjaGFrcmEsIHVzZU11bHRpU3R5bGVDb25maWcsIFZTdGFjayB9IGZyb20gXCJAY2hha3JhLXVpL3JlYWN0XCI7XG5cbmltcG9ydCB7IGdldExvZ2luTGlua3MgfSBmcm9tIFwiLi4vdXRpbHMvaGVhZGVyVXRpbHNcIjtcbmltcG9ydCB7IEhlYWRlckNvbnRleHQgfSBmcm9tIFwiLi4vY29udGV4dC9oZWFkZXJDb250ZXh0XCI7XG5pbXBvcnQgeyBMaXN0LCBMaW5rLCBJY29uIH0gZnJvbSBcIkBueXBsL2Rlc2lnbi1zeXN0ZW0tcmVhY3QtY29tcG9uZW50c1wiO1xuXG5leHBvcnQgaW50ZXJmYWNlIEhlYWRlckxvZ2luUHJvcHMge1xuICBjYXRhbG9nUmVmPzogUmVhY3QuUmVmT2JqZWN0PEhUTUxEaXZFbGVtZW50ICYgSFRNTEFuY2hvckVsZW1lbnQ+O1xuICBpc01vYmlsZT86IGJvb2xlYW47XG59XG5cbi8qKlxuICogVGhlIGNvbnRlbnQgb2YgdGhlIGxvZ2luIGRyb3Bkb3duIG1lbnUuIEluaXRpYWxseSwgdGhpcyByZW5kZXJzIGxpbmtzIHRvIGxvZ1xuICogaW4gYW5kIGxvZyBvdXQuIFdoZW4gdGhlIHBhdHJvbiBpcyBsb2dnZWQgaW4sIGl0IHdpbGwgYWxzbyBkaXNwbGF5IHRoZSBwYXRyb24nc1xuICogbmFtZSwgbGlua3MgdG8gdGhlIGNhdGFsb2dzLCBhbmQgYSBsb2cgb3V0IGxpbmsuXG4gKi9cbmNvbnN0IEhlYWRlckxvZ2luID0gY2hha3JhKCh7IGNhdGFsb2dSZWYsIGlzTW9iaWxlIH06IEhlYWRlckxvZ2luUHJvcHMpID0+IHtcbiAgY29uc3QgeyBpc1Byb2R1Y3Rpb24gfSA9IHVzZUNvbnRleHQoSGVhZGVyQ29udGV4dCk7XG4gIGNvbnN0IHsgY2F0YWxvZ0xpbmssIHJlc2VhcmNoTGluayB9ID0gZ2V0TG9naW5MaW5rcyhcIlwiLCBpc1Byb2R1Y3Rpb24pO1xuICBjb25zdCBzdHlsZXMgPSB1c2VNdWx0aVN0eWxlQ29uZmlnKFwiSGVhZGVyTG9naW5cIiwge1xuICAgIHBhdHJvbk5hbWU6IFwiXCIsXG4gIH0pO1xuXG4gIHJldHVybiAoXG4gICAgPFZTdGFjayBfX2Nzcz17c3R5bGVzfT5cbiAgICAgIDxMaXN0XG4gICAgICAgIGxpc3RJdGVtcz17W1xuICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICBocmVmPXtjYXRhbG9nTGlua31cbiAgICAgICAgICAgIGtleT1cImxvZ0luQ2F0YWxvZ1wiXG4gICAgICAgICAgICByZWY9e2NhdGFsb2dSZWZ9XG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8SWNvblxuICAgICAgICAgICAgICBhbGlnbj1cImxlZnRcIlxuICAgICAgICAgICAgICBjb2xvcj1cInVpLndoaXRlXCJcbiAgICAgICAgICAgICAgbmFtZT1cImFjdGlvbklkZW50aXR5XCJcbiAgICAgICAgICAgICAgc2l6ZT17aXNNb2JpbGUgPyBcInhsYXJnZVwiIDogXCJsYXJnZVwifVxuICAgICAgICAgICAgICB0aXRsZT1cIkdvIHRvIHRoZSBDYXRhbG9nXCJcbiAgICAgICAgICAgICAgc3g9e2lzTW9iaWxlID8geyBoZWlnaHQ6IFwiMS42cmVtXCIsIHdpZHRoOiBcIjEuNnJlbVwiIH0gOiB7fX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8c3Bhbj5HbyBUbyBUaGUgQ2F0YWxvZzwvc3Bhbj5cbiAgICAgICAgICA8L0xpbms+LFxuICAgICAgICAgIDxMaW5rIGhyZWY9e3Jlc2VhcmNoTGlua30ga2V5PVwibG9nSW5SZXNlYXJjaFwiIHR5cGU9XCJidXR0b25cIj5cbiAgICAgICAgICAgIDxJY29uXG4gICAgICAgICAgICAgIGFsaWduPVwibGVmdFwiXG4gICAgICAgICAgICAgIGNvbG9yPVwidWkud2hpdGVcIlxuICAgICAgICAgICAgICBuYW1lPVwiYnVpbGRpbmdcIlxuICAgICAgICAgICAgICBzaXplPXtpc01vYmlsZSA/IFwieGxhcmdlXCIgOiBcIm1lZGl1bVwifVxuICAgICAgICAgICAgICB0aXRsZT1cIkdvIHRvIHRoZSBSZXNlYXJjaCBDYXRhbG9nXCJcbiAgICAgICAgICAgICAgc3g9e2lzTW9iaWxlID8ge30gOiB7IHdpZHRoOiBcIjEuNnJlbVwiLCBoZWlnaHQ6IFwiMS42cmVtXCIgfX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8c3Bhbj5HbyBUbyBUaGUgUmVzZWFyY2ggQ2F0YWxvZzwvc3Bhbj5cbiAgICAgICAgICA8L0xpbms+LFxuICAgICAgICBdfVxuICAgICAgICBub1N0eWxpbmdcbiAgICAgICAgdHlwZT1cInVsXCJcbiAgICAgIC8+XG4gICAgPC9WU3RhY2s+XG4gICk7XG59KTtcblxuZXhwb3J0IGRlZmF1bHQgSGVhZGVyTG9naW47XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaHJpc211bGhvbGxhbmQvU2l0ZXMvdGVzdHMvbnlwbC1oZWFkZXItYXBwL3NyYy9jb21wb25lbnRzL0hlYWRlci9jb21wb25lbnRzL0hlYWRlckxvZ2luLnRzeCJ9