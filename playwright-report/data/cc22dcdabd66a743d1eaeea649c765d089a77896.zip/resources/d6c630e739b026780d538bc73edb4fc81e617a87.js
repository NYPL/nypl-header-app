import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/components/Header/components/HeaderLowerNav.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLowerNav.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Box, chakra, useStyleConfig } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@chakra-ui_react.js?v=2c813617";
import HeaderSearchButton from "/components/Header/components/HeaderSearchButton.tsx";
import { siteNavLinks } from "/components/Header/utils/headerUtils.ts";
import { Link, List } from "/@fs/Users/chrismulholland/Sites/tests/nypl-header-app/node_modules/.vite/deps/@nypl_design-system-react-components.js?v=f372bde6";
const HeaderLowerNav = _s(chakra(_c = _s(() => {
  _s();
  const styles = useStyleConfig("HeaderLowerNav");
  const listItems = siteNavLinks.map(({
    href,
    text
  }) => /* @__PURE__ */ jsxDEV(Link, { href, children: text }, text, false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLowerNav.tsx",
    lineNumber: 17,
    columnNumber: 9
  }, this));
  return /* @__PURE__ */ jsxDEV(Box, { as: "nav", "aria-label": "Header bottom links", __css: styles, children: /* @__PURE__ */ jsxDEV(List, { id: "header-nav-lower", inline: true, listItems: [...listItems, /* @__PURE__ */ jsxDEV(HeaderSearchButton, {}, "search", false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLowerNav.tsx",
    lineNumber: 21,
    columnNumber: 68
  }, this)], noStyling: true, type: "ul" }, void 0, false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLowerNav.tsx",
    lineNumber: 21,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLowerNav.tsx",
    lineNumber: 20,
    columnNumber: 10
  }, this);
}, "iefmmX9LVM7kdyggYlA/rYvyEAM=", false, function() {
  return [useStyleConfig];
})), "iefmmX9LVM7kdyggYlA/rYvyEAM=", false, function() {
  return [useStyleConfig];
});
_c2 = HeaderLowerNav;
export default HeaderLowerNav;
var _c, _c2;
$RefreshReg$(_c, "HeaderLowerNav$chakra");
$RefreshReg$(_c2, "HeaderLowerNav");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/chrismulholland/Sites/tests/nypl-header-app/src/components/Header/components/HeaderLowerNav.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYUk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFiSixTQUFTQSxLQUFLQyxRQUFRQyxzQkFBc0I7QUFFNUMsT0FBT0Msd0JBQXdCO0FBQy9CLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxNQUFNQyxZQUFZO0FBTTNCLE1BQU1DLGlCQUFjQyxHQUFHUCxPQUFNUSxLQUFBRCxHQUFDLE1BQU07QUFBQUEsS0FBQTtBQUNsQyxRQUFNRSxTQUFTUixlQUFlLGdCQUFnQjtBQUM5QyxRQUFNUyxZQUFZUCxhQUFhUSxJQUFJLENBQUM7QUFBQSxJQUFFQztBQUFBQSxJQUFNQztBQUFBQSxFQUFLLE1BQy9DLHVCQUFDLFFBQUssTUFDSEEsa0JBRG9CQSxNQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUEsQ0FDRDtBQUVELFNBQ0UsdUJBQUMsT0FBSSxJQUFHLE9BQU0sY0FBVyx1QkFBc0IsT0FBT0osUUFDcEQsaUNBQUMsUUFDQyxJQUFHLG9CQUNILFFBQU0sTUFDTixXQUFXLENBQUMsR0FBR0MsV0FBVyx1QkFBQyx3QkFBdUIsVUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFnQyxDQUFHLEdBQzdELFdBQVMsTUFDVCxNQUFLLFFBTFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtXLEtBTmI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBO0FBRUosR0FBQztBQUFBLFVBbEJnQlQsY0FBYztBQUFBLEVBa0I5QixHQUFDO0FBQUEsVUFsQmVBLGNBQWM7QUFBQTtBQWtCNUJhLE1BbkJHUjtBQXFCTixlQUFlQTtBQUFlLElBQUFFLElBQUFNO0FBQUFDLGFBQUFQLElBQUE7QUFBQU8sYUFBQUQsS0FBQSIsIm5hbWVzIjpbIkJveCIsImNoYWtyYSIsInVzZVN0eWxlQ29uZmlnIiwiSGVhZGVyU2VhcmNoQnV0dG9uIiwic2l0ZU5hdkxpbmtzIiwiTGluayIsIkxpc3QiLCJIZWFkZXJMb3dlck5hdiIsIl9zIiwiX2MiLCJzdHlsZXMiLCJsaXN0SXRlbXMiLCJtYXAiLCJocmVmIiwidGV4dCIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkhlYWRlckxvd2VyTmF2LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCb3gsIGNoYWtyYSwgdXNlU3R5bGVDb25maWcgfSBmcm9tIFwiQGNoYWtyYS11aS9yZWFjdFwiO1xuXG5pbXBvcnQgSGVhZGVyU2VhcmNoQnV0dG9uIGZyb20gXCIuL0hlYWRlclNlYXJjaEJ1dHRvblwiO1xuaW1wb3J0IHsgc2l0ZU5hdkxpbmtzIH0gZnJvbSBcIi4uL3V0aWxzL2hlYWRlclV0aWxzXCI7XG5pbXBvcnQgeyBMaW5rLCBMaXN0IH0gZnJvbSBcIkBueXBsL2Rlc2lnbi1zeXN0ZW0tcmVhY3QtY29tcG9uZW50c1wiO1xuXG4vKipcbiAqIFRoaXMgY29tcG9uZW50IHJlbmRlcnMgdGhlIG5hdmlnYXRpb25hbCBsaXN0IG9mIGxpbmtzIHVzZWQgdG9cbiAqIG5hdmlnYXRlIHRvIGRpZmZlcmVudCBsYW5kaW5nIHBhZ2VzIG9uIE5ZUEwub3JnLlxuICovXG5jb25zdCBIZWFkZXJMb3dlck5hdiA9IGNoYWtyYSgoKSA9PiB7XG4gIGNvbnN0IHN0eWxlcyA9IHVzZVN0eWxlQ29uZmlnKFwiSGVhZGVyTG93ZXJOYXZcIik7XG4gIGNvbnN0IGxpc3RJdGVtcyA9IHNpdGVOYXZMaW5rcy5tYXAoKHsgaHJlZiwgdGV4dCB9KSA9PiAoXG4gICAgPExpbmsgaHJlZj17aHJlZn0ga2V5PXt0ZXh0fT5cbiAgICAgIHt0ZXh0fVxuICAgIDwvTGluaz5cbiAgKSk7XG5cbiAgcmV0dXJuIChcbiAgICA8Qm94IGFzPVwibmF2XCIgYXJpYS1sYWJlbD1cIkhlYWRlciBib3R0b20gbGlua3NcIiBfX2Nzcz17c3R5bGVzfT5cbiAgICAgIDxMaXN0XG4gICAgICAgIGlkPVwiaGVhZGVyLW5hdi1sb3dlclwiXG4gICAgICAgIGlubGluZVxuICAgICAgICBsaXN0SXRlbXM9e1suLi5saXN0SXRlbXMsIDxIZWFkZXJTZWFyY2hCdXR0b24ga2V5PVwic2VhcmNoXCIgLz5dfVxuICAgICAgICBub1N0eWxpbmdcbiAgICAgICAgdHlwZT1cInVsXCJcbiAgICAgIC8+XG4gICAgPC9Cb3g+XG4gICk7XG59KTtcblxuZXhwb3J0IGRlZmF1bHQgSGVhZGVyTG93ZXJOYXY7XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jaHJpc211bGhvbGxhbmQvU2l0ZXMvdGVzdHMvbnlwbC1oZWFkZXItYXBwL3NyYy9jb21wb25lbnRzL0hlYWRlci9jb21wb25lbnRzL0hlYWRlckxvd2VyTmF2LnRzeCJ9